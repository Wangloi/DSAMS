<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Campus center (reference for map UI only)
    |--------------------------------------------------------------------------
    |
    | Set CAMPUS_LATITUDE and CAMPUS_LONGITUDE in .env to your school's real
    | coordinates. Event geofence lat/lng in the database must also be real GPS
    | points captured at each venue (use "Use device GPS" on the admin map).
    |
    */

    'campus_name' => (string) env('CAMPUS_NAME', "St. Rita's College of Balingasag"),
    'campus_latitude' => (float) env('CAMPUS_LATITUDE', 8.743070),
    'campus_longitude' => (float) env('CAMPUS_LONGITUDE', 124.774500),
    'campus_radius_m' => (int) env('CAMPUS_RADIUS_M', 300),

    'gymnasium_name' => (string) env('GYM_NAME', "SRCB Gymnasium"),
    'gymnasium_latitude' => (float) env('GYM_LATITUDE', 8.742800),
    'gymnasium_longitude' => (float) env('GYM_LONGITUDE', 124.774200),
    'gymnasium_radius_m' => (int) env('GYM_RADIUS_M', 50),

    'max_accuracy_m' => (float) env('MAX_GEOFENCE_ACCURACY_M', 5000),

];
