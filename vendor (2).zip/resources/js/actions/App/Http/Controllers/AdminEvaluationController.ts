import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminEvaluationController::index
 * @see app/Http/Controllers/AdminEvaluationController.php:192
 * @route '/admin/evaluation'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/evaluation',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminEvaluationController::index
 * @see app/Http/Controllers/AdminEvaluationController.php:192
 * @route '/admin/evaluation'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEvaluationController::index
 * @see app/Http/Controllers/AdminEvaluationController.php:192
 * @route '/admin/evaluation'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminEvaluationController::index
 * @see app/Http/Controllers/AdminEvaluationController.php:192
 * @route '/admin/evaluation'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminEvaluationController::index
 * @see app/Http/Controllers/AdminEvaluationController.php:192
 * @route '/admin/evaluation'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminEvaluationController::index
 * @see app/Http/Controllers/AdminEvaluationController.php:192
 * @route '/admin/evaluation'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminEvaluationController::index
 * @see app/Http/Controllers/AdminEvaluationController.php:192
 * @route '/admin/evaluation'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AdminEvaluationController::show
 * @see app/Http/Controllers/AdminEvaluationController.php:26
 * @route '/admin/evaluation/{evaluation}'
 */
export const show = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/evaluation/{evaluation}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminEvaluationController::show
 * @see app/Http/Controllers/AdminEvaluationController.php:26
 * @route '/admin/evaluation/{evaluation}'
 */
show.url = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { evaluation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { evaluation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    evaluation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        evaluation: typeof args.evaluation === 'object'
                ? args.evaluation.id
                : args.evaluation,
                }

    return show.definition.url
            .replace('{evaluation}', parsedArgs.evaluation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEvaluationController::show
 * @see app/Http/Controllers/AdminEvaluationController.php:26
 * @route '/admin/evaluation/{evaluation}'
 */
show.get = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminEvaluationController::show
 * @see app/Http/Controllers/AdminEvaluationController.php:26
 * @route '/admin/evaluation/{evaluation}'
 */
show.head = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminEvaluationController::show
 * @see app/Http/Controllers/AdminEvaluationController.php:26
 * @route '/admin/evaluation/{evaluation}'
 */
    const showForm = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminEvaluationController::show
 * @see app/Http/Controllers/AdminEvaluationController.php:26
 * @route '/admin/evaluation/{evaluation}'
 */
        showForm.get = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminEvaluationController::show
 * @see app/Http/Controllers/AdminEvaluationController.php:26
 * @route '/admin/evaluation/{evaluation}'
 */
        showForm.head = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\AdminEvaluationController::autoGenerate
 * @see app/Http/Controllers/AdminEvaluationController.php:641
 * @route '/admin/evaluation/auto-generate'
 */
export const autoGenerate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: autoGenerate.url(options),
    method: 'post',
})

autoGenerate.definition = {
    methods: ["post"],
    url: '/admin/evaluation/auto-generate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminEvaluationController::autoGenerate
 * @see app/Http/Controllers/AdminEvaluationController.php:641
 * @route '/admin/evaluation/auto-generate'
 */
autoGenerate.url = (options?: RouteQueryOptions) => {
    return autoGenerate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEvaluationController::autoGenerate
 * @see app/Http/Controllers/AdminEvaluationController.php:641
 * @route '/admin/evaluation/auto-generate'
 */
autoGenerate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: autoGenerate.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminEvaluationController::autoGenerate
 * @see app/Http/Controllers/AdminEvaluationController.php:641
 * @route '/admin/evaluation/auto-generate'
 */
    const autoGenerateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: autoGenerate.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminEvaluationController::autoGenerate
 * @see app/Http/Controllers/AdminEvaluationController.php:641
 * @route '/admin/evaluation/auto-generate'
 */
        autoGenerateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: autoGenerate.url(options),
            method: 'post',
        })
    
    autoGenerate.form = autoGenerateForm
/**
* @see \App\Http\Controllers\AdminEvaluationController::store
 * @see app/Http/Controllers/AdminEvaluationController.php:388
 * @route '/admin/evaluation'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/evaluation',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminEvaluationController::store
 * @see app/Http/Controllers/AdminEvaluationController.php:388
 * @route '/admin/evaluation'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEvaluationController::store
 * @see app/Http/Controllers/AdminEvaluationController.php:388
 * @route '/admin/evaluation'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminEvaluationController::store
 * @see app/Http/Controllers/AdminEvaluationController.php:388
 * @route '/admin/evaluation'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminEvaluationController::store
 * @see app/Http/Controllers/AdminEvaluationController.php:388
 * @route '/admin/evaluation'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AdminEvaluationController::update
 * @see app/Http/Controllers/AdminEvaluationController.php:434
 * @route '/admin/evaluation/{evaluation}'
 */
export const update = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/evaluation/{evaluation}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AdminEvaluationController::update
 * @see app/Http/Controllers/AdminEvaluationController.php:434
 * @route '/admin/evaluation/{evaluation}'
 */
update.url = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { evaluation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { evaluation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    evaluation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        evaluation: typeof args.evaluation === 'object'
                ? args.evaluation.id
                : args.evaluation,
                }

    return update.definition.url
            .replace('{evaluation}', parsedArgs.evaluation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEvaluationController::update
 * @see app/Http/Controllers/AdminEvaluationController.php:434
 * @route '/admin/evaluation/{evaluation}'
 */
update.put = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AdminEvaluationController::update
 * @see app/Http/Controllers/AdminEvaluationController.php:434
 * @route '/admin/evaluation/{evaluation}'
 */
    const updateForm = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminEvaluationController::update
 * @see app/Http/Controllers/AdminEvaluationController.php:434
 * @route '/admin/evaluation/{evaluation}'
 */
        updateForm.put = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\AdminEvaluationController::destroy
 * @see app/Http/Controllers/AdminEvaluationController.php:581
 * @route '/admin/evaluation/{evaluation}/delete'
 */
export const destroy = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: destroy.url(args, options),
    method: 'post',
})

destroy.definition = {
    methods: ["post"],
    url: '/admin/evaluation/{evaluation}/delete',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminEvaluationController::destroy
 * @see app/Http/Controllers/AdminEvaluationController.php:581
 * @route '/admin/evaluation/{evaluation}/delete'
 */
destroy.url = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { evaluation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { evaluation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    evaluation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        evaluation: typeof args.evaluation === 'object'
                ? args.evaluation.id
                : args.evaluation,
                }

    return destroy.definition.url
            .replace('{evaluation}', parsedArgs.evaluation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEvaluationController::destroy
 * @see app/Http/Controllers/AdminEvaluationController.php:581
 * @route '/admin/evaluation/{evaluation}/delete'
 */
destroy.post = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: destroy.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminEvaluationController::destroy
 * @see app/Http/Controllers/AdminEvaluationController.php:581
 * @route '/admin/evaluation/{evaluation}/delete'
 */
    const destroyForm = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminEvaluationController::destroy
 * @see app/Http/Controllers/AdminEvaluationController.php:581
 * @route '/admin/evaluation/{evaluation}/delete'
 */
        destroyForm.post = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, options),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\AdminEvaluationController::archive
 * @see app/Http/Controllers/AdminEvaluationController.php:601
 * @route '/admin/evaluation/{evaluation}/archive'
 */
export const archive = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: archive.url(args, options),
    method: 'put',
})

archive.definition = {
    methods: ["put"],
    url: '/admin/evaluation/{evaluation}/archive',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AdminEvaluationController::archive
 * @see app/Http/Controllers/AdminEvaluationController.php:601
 * @route '/admin/evaluation/{evaluation}/archive'
 */
archive.url = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { evaluation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { evaluation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    evaluation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        evaluation: typeof args.evaluation === 'object'
                ? args.evaluation.id
                : args.evaluation,
                }

    return archive.definition.url
            .replace('{evaluation}', parsedArgs.evaluation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEvaluationController::archive
 * @see app/Http/Controllers/AdminEvaluationController.php:601
 * @route '/admin/evaluation/{evaluation}/archive'
 */
archive.put = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: archive.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AdminEvaluationController::archive
 * @see app/Http/Controllers/AdminEvaluationController.php:601
 * @route '/admin/evaluation/{evaluation}/archive'
 */
    const archiveForm = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: archive.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminEvaluationController::archive
 * @see app/Http/Controllers/AdminEvaluationController.php:601
 * @route '/admin/evaluation/{evaluation}/archive'
 */
        archiveForm.put = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: archive.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    archive.form = archiveForm
/**
* @see \App\Http\Controllers\AdminEvaluationController::unarchive
 * @see app/Http/Controllers/AdminEvaluationController.php:621
 * @route '/admin/evaluation/{evaluation}/unarchive'
 */
export const unarchive = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: unarchive.url(args, options),
    method: 'put',
})

unarchive.definition = {
    methods: ["put"],
    url: '/admin/evaluation/{evaluation}/unarchive',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AdminEvaluationController::unarchive
 * @see app/Http/Controllers/AdminEvaluationController.php:621
 * @route '/admin/evaluation/{evaluation}/unarchive'
 */
unarchive.url = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { evaluation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { evaluation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    evaluation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        evaluation: typeof args.evaluation === 'object'
                ? args.evaluation.id
                : args.evaluation,
                }

    return unarchive.definition.url
            .replace('{evaluation}', parsedArgs.evaluation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEvaluationController::unarchive
 * @see app/Http/Controllers/AdminEvaluationController.php:621
 * @route '/admin/evaluation/{evaluation}/unarchive'
 */
unarchive.put = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: unarchive.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AdminEvaluationController::unarchive
 * @see app/Http/Controllers/AdminEvaluationController.php:621
 * @route '/admin/evaluation/{evaluation}/unarchive'
 */
    const unarchiveForm = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unarchive.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminEvaluationController::unarchive
 * @see app/Http/Controllers/AdminEvaluationController.php:621
 * @route '/admin/evaluation/{evaluation}/unarchive'
 */
        unarchiveForm.put = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unarchive.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    unarchive.form = unarchiveForm
/**
* @see \App\Http\Controllers\AdminEvaluationController::publish
 * @see app/Http/Controllers/AdminEvaluationController.php:478
 * @route '/admin/evaluation/{evaluation}/publish'
 */
export const publish = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: publish.url(args, options),
    method: 'post',
})

publish.definition = {
    methods: ["post"],
    url: '/admin/evaluation/{evaluation}/publish',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminEvaluationController::publish
 * @see app/Http/Controllers/AdminEvaluationController.php:478
 * @route '/admin/evaluation/{evaluation}/publish'
 */
publish.url = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { evaluation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { evaluation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    evaluation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        evaluation: typeof args.evaluation === 'object'
                ? args.evaluation.id
                : args.evaluation,
                }

    return publish.definition.url
            .replace('{evaluation}', parsedArgs.evaluation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEvaluationController::publish
 * @see app/Http/Controllers/AdminEvaluationController.php:478
 * @route '/admin/evaluation/{evaluation}/publish'
 */
publish.post = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: publish.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminEvaluationController::publish
 * @see app/Http/Controllers/AdminEvaluationController.php:478
 * @route '/admin/evaluation/{evaluation}/publish'
 */
    const publishForm = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: publish.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminEvaluationController::publish
 * @see app/Http/Controllers/AdminEvaluationController.php:478
 * @route '/admin/evaluation/{evaluation}/publish'
 */
        publishForm.post = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: publish.url(args, options),
            method: 'post',
        })
    
    publish.form = publishForm
/**
* @see \App\Http\Controllers\AdminEvaluationController::unpublish
 * @see app/Http/Controllers/AdminEvaluationController.php:517
 * @route '/admin/evaluation/{evaluation}/unpublish'
 */
export const unpublish = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unpublish.url(args, options),
    method: 'post',
})

unpublish.definition = {
    methods: ["post"],
    url: '/admin/evaluation/{evaluation}/unpublish',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminEvaluationController::unpublish
 * @see app/Http/Controllers/AdminEvaluationController.php:517
 * @route '/admin/evaluation/{evaluation}/unpublish'
 */
unpublish.url = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { evaluation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { evaluation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    evaluation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        evaluation: typeof args.evaluation === 'object'
                ? args.evaluation.id
                : args.evaluation,
                }

    return unpublish.definition.url
            .replace('{evaluation}', parsedArgs.evaluation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEvaluationController::unpublish
 * @see app/Http/Controllers/AdminEvaluationController.php:517
 * @route '/admin/evaluation/{evaluation}/unpublish'
 */
unpublish.post = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unpublish.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminEvaluationController::unpublish
 * @see app/Http/Controllers/AdminEvaluationController.php:517
 * @route '/admin/evaluation/{evaluation}/unpublish'
 */
    const unpublishForm = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unpublish.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminEvaluationController::unpublish
 * @see app/Http/Controllers/AdminEvaluationController.php:517
 * @route '/admin/evaluation/{evaluation}/unpublish'
 */
        unpublishForm.post = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unpublish.url(args, options),
            method: 'post',
        })
    
    unpublish.form = unpublishForm
/**
* @see \App\Http\Controllers\AdminEvaluationController::approveNextActivity
 * @see app/Http/Controllers/AdminEvaluationController.php:537
 * @route '/admin/evaluation/{evaluation}/approve-program'
 */
export const approveNextActivity = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approveNextActivity.url(args, options),
    method: 'post',
})

approveNextActivity.definition = {
    methods: ["post"],
    url: '/admin/evaluation/{evaluation}/approve-program',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminEvaluationController::approveNextActivity
 * @see app/Http/Controllers/AdminEvaluationController.php:537
 * @route '/admin/evaluation/{evaluation}/approve-program'
 */
approveNextActivity.url = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { evaluation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { evaluation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    evaluation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        evaluation: typeof args.evaluation === 'object'
                ? args.evaluation.id
                : args.evaluation,
                }

    return approveNextActivity.definition.url
            .replace('{evaluation}', parsedArgs.evaluation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEvaluationController::approveNextActivity
 * @see app/Http/Controllers/AdminEvaluationController.php:537
 * @route '/admin/evaluation/{evaluation}/approve-program'
 */
approveNextActivity.post = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approveNextActivity.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminEvaluationController::approveNextActivity
 * @see app/Http/Controllers/AdminEvaluationController.php:537
 * @route '/admin/evaluation/{evaluation}/approve-program'
 */
    const approveNextActivityForm = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approveNextActivity.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminEvaluationController::approveNextActivity
 * @see app/Http/Controllers/AdminEvaluationController.php:537
 * @route '/admin/evaluation/{evaluation}/approve-program'
 */
        approveNextActivityForm.post = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approveNextActivity.url(args, options),
            method: 'post',
        })
    
    approveNextActivity.form = approveNextActivityForm
/**
* @see \App\Http\Controllers\AdminEvaluationController::metrics
 * @see app/Http/Controllers/AdminEvaluationController.php:64
 * @route '/admin/evaluation/{evaluation}/metrics'
 */
export const metrics = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: metrics.url(args, options),
    method: 'get',
})

metrics.definition = {
    methods: ["get","head"],
    url: '/admin/evaluation/{evaluation}/metrics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminEvaluationController::metrics
 * @see app/Http/Controllers/AdminEvaluationController.php:64
 * @route '/admin/evaluation/{evaluation}/metrics'
 */
metrics.url = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { evaluation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { evaluation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    evaluation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        evaluation: typeof args.evaluation === 'object'
                ? args.evaluation.id
                : args.evaluation,
                }

    return metrics.definition.url
            .replace('{evaluation}', parsedArgs.evaluation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEvaluationController::metrics
 * @see app/Http/Controllers/AdminEvaluationController.php:64
 * @route '/admin/evaluation/{evaluation}/metrics'
 */
metrics.get = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: metrics.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminEvaluationController::metrics
 * @see app/Http/Controllers/AdminEvaluationController.php:64
 * @route '/admin/evaluation/{evaluation}/metrics'
 */
metrics.head = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: metrics.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminEvaluationController::metrics
 * @see app/Http/Controllers/AdminEvaluationController.php:64
 * @route '/admin/evaluation/{evaluation}/metrics'
 */
    const metricsForm = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: metrics.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminEvaluationController::metrics
 * @see app/Http/Controllers/AdminEvaluationController.php:64
 * @route '/admin/evaluation/{evaluation}/metrics'
 */
        metricsForm.get = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: metrics.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminEvaluationController::metrics
 * @see app/Http/Controllers/AdminEvaluationController.php:64
 * @route '/admin/evaluation/{evaluation}/metrics'
 */
        metricsForm.head = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: metrics.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    metrics.form = metricsForm
const AdminEvaluationController = { index, show, autoGenerate, store, update, destroy, archive, unarchive, publish, unpublish, approveNextActivity, metrics }

export default AdminEvaluationController