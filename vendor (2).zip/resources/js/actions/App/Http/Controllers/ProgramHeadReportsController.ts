import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ProgramHeadReportsController::index
 * @see app/Http/Controllers/ProgramHeadReportsController.php:15
 * @route '/program-head/reports'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/program-head/reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProgramHeadReportsController::index
 * @see app/Http/Controllers/ProgramHeadReportsController.php:15
 * @route '/program-head/reports'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramHeadReportsController::index
 * @see app/Http/Controllers/ProgramHeadReportsController.php:15
 * @route '/program-head/reports'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProgramHeadReportsController::index
 * @see app/Http/Controllers/ProgramHeadReportsController.php:15
 * @route '/program-head/reports'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProgramHeadReportsController::index
 * @see app/Http/Controllers/ProgramHeadReportsController.php:15
 * @route '/program-head/reports'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProgramHeadReportsController::index
 * @see app/Http/Controllers/ProgramHeadReportsController.php:15
 * @route '/program-head/reports'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProgramHeadReportsController::index
 * @see app/Http/Controllers/ProgramHeadReportsController.php:15
 * @route '/program-head/reports'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ProgramHeadReportsController::print
 * @see app/Http/Controllers/ProgramHeadReportsController.php:94
 * @route '/program-head/reports/print'
 */
export const print = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(options),
    method: 'get',
})

print.definition = {
    methods: ["get","head"],
    url: '/program-head/reports/print',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProgramHeadReportsController::print
 * @see app/Http/Controllers/ProgramHeadReportsController.php:94
 * @route '/program-head/reports/print'
 */
print.url = (options?: RouteQueryOptions) => {
    return print.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramHeadReportsController::print
 * @see app/Http/Controllers/ProgramHeadReportsController.php:94
 * @route '/program-head/reports/print'
 */
print.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProgramHeadReportsController::print
 * @see app/Http/Controllers/ProgramHeadReportsController.php:94
 * @route '/program-head/reports/print'
 */
print.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: print.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProgramHeadReportsController::print
 * @see app/Http/Controllers/ProgramHeadReportsController.php:94
 * @route '/program-head/reports/print'
 */
    const printForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: print.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProgramHeadReportsController::print
 * @see app/Http/Controllers/ProgramHeadReportsController.php:94
 * @route '/program-head/reports/print'
 */
        printForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: print.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProgramHeadReportsController::print
 * @see app/Http/Controllers/ProgramHeadReportsController.php:94
 * @route '/program-head/reports/print'
 */
        printForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: print.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    print.form = printForm
/**
* @see \App\Http\Controllers\ProgramHeadReportsController::exportCsv
 * @see app/Http/Controllers/ProgramHeadReportsController.php:63
 * @route '/program-head/reports/export/csv'
 */
export const exportCsv = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportCsv.url(options),
    method: 'get',
})

exportCsv.definition = {
    methods: ["get","head"],
    url: '/program-head/reports/export/csv',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProgramHeadReportsController::exportCsv
 * @see app/Http/Controllers/ProgramHeadReportsController.php:63
 * @route '/program-head/reports/export/csv'
 */
exportCsv.url = (options?: RouteQueryOptions) => {
    return exportCsv.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramHeadReportsController::exportCsv
 * @see app/Http/Controllers/ProgramHeadReportsController.php:63
 * @route '/program-head/reports/export/csv'
 */
exportCsv.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportCsv.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProgramHeadReportsController::exportCsv
 * @see app/Http/Controllers/ProgramHeadReportsController.php:63
 * @route '/program-head/reports/export/csv'
 */
exportCsv.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportCsv.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProgramHeadReportsController::exportCsv
 * @see app/Http/Controllers/ProgramHeadReportsController.php:63
 * @route '/program-head/reports/export/csv'
 */
    const exportCsvForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportCsv.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProgramHeadReportsController::exportCsv
 * @see app/Http/Controllers/ProgramHeadReportsController.php:63
 * @route '/program-head/reports/export/csv'
 */
        exportCsvForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportCsv.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProgramHeadReportsController::exportCsv
 * @see app/Http/Controllers/ProgramHeadReportsController.php:63
 * @route '/program-head/reports/export/csv'
 */
        exportCsvForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportCsv.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportCsv.form = exportCsvForm
const ProgramHeadReportsController = { index, print, exportCsv }

export default ProgramHeadReportsController