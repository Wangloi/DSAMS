import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminLoginController::login
 * @see app/Http/Controllers/AdminLoginController.php:11
 * @route '/admin-login'
 */
export const login = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

login.definition = {
    methods: ["post"],
    url: '/admin-login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminLoginController::login
 * @see app/Http/Controllers/AdminLoginController.php:11
 * @route '/admin-login'
 */
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminLoginController::login
 * @see app/Http/Controllers/AdminLoginController.php:11
 * @route '/admin-login'
 */
login.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminLoginController::login
 * @see app/Http/Controllers/AdminLoginController.php:11
 * @route '/admin-login'
 */
    const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: login.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminLoginController::login
 * @see app/Http/Controllers/AdminLoginController.php:11
 * @route '/admin-login'
 */
        loginForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: login.url(options),
            method: 'post',
        })
    
    login.form = loginForm
const AdminLoginController = { login }

export default AdminLoginController