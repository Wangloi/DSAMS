import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::index
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:18
 * @route '/admin/incidents-violations'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/incidents-violations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::index
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:18
 * @route '/admin/incidents-violations'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::index
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:18
 * @route '/admin/incidents-violations'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::index
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:18
 * @route '/admin/incidents-violations'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::index
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:18
 * @route '/admin/incidents-violations'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::index
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:18
 * @route '/admin/incidents-violations'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::index
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:18
 * @route '/admin/incidents-violations'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::show
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:220
 * @route '/admin/incidents-violations/{incident}'
 */
export const show = (args: { incident: string | number } | [incident: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/incidents-violations/{incident}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::show
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:220
 * @route '/admin/incidents-violations/{incident}'
 */
show.url = (args: { incident: string | number } | [incident: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { incident: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    incident: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        incident: args.incident,
                }

    return show.definition.url
            .replace('{incident}', parsedArgs.incident.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::show
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:220
 * @route '/admin/incidents-violations/{incident}'
 */
show.get = (args: { incident: string | number } | [incident: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::show
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:220
 * @route '/admin/incidents-violations/{incident}'
 */
show.head = (args: { incident: string | number } | [incident: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::show
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:220
 * @route '/admin/incidents-violations/{incident}'
 */
    const showForm = (args: { incident: string | number } | [incident: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::show
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:220
 * @route '/admin/incidents-violations/{incident}'
 */
        showForm.get = (args: { incident: string | number } | [incident: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::show
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:220
 * @route '/admin/incidents-violations/{incident}'
 */
        showForm.head = (args: { incident: string | number } | [incident: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::store
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:106
 * @route '/admin/incidents-violations'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/incidents-violations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::store
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:106
 * @route '/admin/incidents-violations'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::store
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:106
 * @route '/admin/incidents-violations'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::store
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:106
 * @route '/admin/incidents-violations'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::store
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:106
 * @route '/admin/incidents-violations'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::update
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:151
 * @route '/admin/incidents-violations/{incident}'
 */
export const update = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","post"],
    url: '/admin/incidents-violations/{incident}',
} satisfies RouteDefinition<["put","post"]>

/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::update
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:151
 * @route '/admin/incidents-violations/{incident}'
 */
update.url = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { incident: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { incident: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    incident: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        incident: typeof args.incident === 'object'
                ? args.incident.id
                : args.incident,
                }

    return update.definition.url
            .replace('{incident}', parsedArgs.incident.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::update
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:151
 * @route '/admin/incidents-violations/{incident}'
 */
update.put = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::update
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:151
 * @route '/admin/incidents-violations/{incident}'
 */
update.post = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::update
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:151
 * @route '/admin/incidents-violations/{incident}'
 */
    const updateForm = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::update
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:151
 * @route '/admin/incidents-violations/{incident}'
 */
        updateForm.put = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::update
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:151
 * @route '/admin/incidents-violations/{incident}'
 */
        updateForm.post = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, options),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::destroy
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:208
 * @route '/admin/incidents-violations/{incident}'
 */
export const destroy = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/incidents-violations/{incident}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::destroy
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:208
 * @route '/admin/incidents-violations/{incident}'
 */
destroy.url = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { incident: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { incident: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    incident: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        incident: typeof args.incident === 'object'
                ? args.incident.id
                : args.incident,
                }

    return destroy.definition.url
            .replace('{incident}', parsedArgs.incident.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::destroy
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:208
 * @route '/admin/incidents-violations/{incident}'
 */
destroy.delete = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::destroy
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:208
 * @route '/admin/incidents-violations/{incident}'
 */
    const destroyForm = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::destroy
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:208
 * @route '/admin/incidents-violations/{incident}'
 */
        destroyForm.delete = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::archive
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:561
 * @route '/admin/incidents-violations/{incident}/archive'
 */
export const archive = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: archive.url(args, options),
    method: 'put',
})

archive.definition = {
    methods: ["put","post"],
    url: '/admin/incidents-violations/{incident}/archive',
} satisfies RouteDefinition<["put","post"]>

/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::archive
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:561
 * @route '/admin/incidents-violations/{incident}/archive'
 */
archive.url = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { incident: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { incident: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    incident: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        incident: typeof args.incident === 'object'
                ? args.incident.id
                : args.incident,
                }

    return archive.definition.url
            .replace('{incident}', parsedArgs.incident.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::archive
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:561
 * @route '/admin/incidents-violations/{incident}/archive'
 */
archive.put = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: archive.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::archive
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:561
 * @route '/admin/incidents-violations/{incident}/archive'
 */
archive.post = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: archive.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::archive
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:561
 * @route '/admin/incidents-violations/{incident}/archive'
 */
    const archiveForm = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: archive.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::archive
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:561
 * @route '/admin/incidents-violations/{incident}/archive'
 */
        archiveForm.put = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: archive.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::archive
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:561
 * @route '/admin/incidents-violations/{incident}/archive'
 */
        archiveForm.post = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: archive.url(args, options),
            method: 'post',
        })
    
    archive.form = archiveForm
/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::unarchive
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:583
 * @route '/admin/incidents-violations/{incident}/unarchive'
 */
export const unarchive = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: unarchive.url(args, options),
    method: 'put',
})

unarchive.definition = {
    methods: ["put"],
    url: '/admin/incidents-violations/{incident}/unarchive',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::unarchive
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:583
 * @route '/admin/incidents-violations/{incident}/unarchive'
 */
unarchive.url = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { incident: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { incident: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    incident: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        incident: typeof args.incident === 'object'
                ? args.incident.id
                : args.incident,
                }

    return unarchive.definition.url
            .replace('{incident}', parsedArgs.incident.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::unarchive
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:583
 * @route '/admin/incidents-violations/{incident}/unarchive'
 */
unarchive.put = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: unarchive.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::unarchive
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:583
 * @route '/admin/incidents-violations/{incident}/unarchive'
 */
    const unarchiveForm = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unarchive.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::unarchive
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:583
 * @route '/admin/incidents-violations/{incident}/unarchive'
 */
        unarchiveForm.put = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unarchive.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    unarchive.form = unarchiveForm
/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::storeDisciplinaryAction
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:598
 * @route '/admin/incidents-violations/{incident}/disciplinary-action'
 */
export const storeDisciplinaryAction = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeDisciplinaryAction.url(args, options),
    method: 'post',
})

storeDisciplinaryAction.definition = {
    methods: ["post"],
    url: '/admin/incidents-violations/{incident}/disciplinary-action',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::storeDisciplinaryAction
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:598
 * @route '/admin/incidents-violations/{incident}/disciplinary-action'
 */
storeDisciplinaryAction.url = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { incident: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { incident: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    incident: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        incident: typeof args.incident === 'object'
                ? args.incident.id
                : args.incident,
                }

    return storeDisciplinaryAction.definition.url
            .replace('{incident}', parsedArgs.incident.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::storeDisciplinaryAction
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:598
 * @route '/admin/incidents-violations/{incident}/disciplinary-action'
 */
storeDisciplinaryAction.post = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeDisciplinaryAction.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::storeDisciplinaryAction
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:598
 * @route '/admin/incidents-violations/{incident}/disciplinary-action'
 */
    const storeDisciplinaryActionForm = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeDisciplinaryAction.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::storeDisciplinaryAction
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:598
 * @route '/admin/incidents-violations/{incident}/disciplinary-action'
 */
        storeDisciplinaryActionForm.post = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeDisciplinaryAction.url(args, options),
            method: 'post',
        })
    
    storeDisciplinaryAction.form = storeDisciplinaryActionForm
/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::reviewDisciplinaryAction
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:630
 * @route '/admin/disciplinary-action/{action}/review'
 */
export const reviewDisciplinaryAction = (args: { action: number | { id: number } } | [action: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reviewDisciplinaryAction.url(args, options),
    method: 'post',
})

reviewDisciplinaryAction.definition = {
    methods: ["post"],
    url: '/admin/disciplinary-action/{action}/review',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::reviewDisciplinaryAction
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:630
 * @route '/admin/disciplinary-action/{action}/review'
 */
reviewDisciplinaryAction.url = (args: { action: number | { id: number } } | [action: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { action: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { action: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    action: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        action: typeof args.action === 'object'
                ? args.action.id
                : args.action,
                }

    return reviewDisciplinaryAction.definition.url
            .replace('{action}', parsedArgs.action.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::reviewDisciplinaryAction
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:630
 * @route '/admin/disciplinary-action/{action}/review'
 */
reviewDisciplinaryAction.post = (args: { action: number | { id: number } } | [action: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reviewDisciplinaryAction.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::reviewDisciplinaryAction
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:630
 * @route '/admin/disciplinary-action/{action}/review'
 */
    const reviewDisciplinaryActionForm = (args: { action: number | { id: number } } | [action: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reviewDisciplinaryAction.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminIncidentsViolationsController::reviewDisciplinaryAction
 * @see app/Http/Controllers/AdminIncidentsViolationsController.php:630
 * @route '/admin/disciplinary-action/{action}/review'
 */
        reviewDisciplinaryActionForm.post = (args: { action: number | { id: number } } | [action: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reviewDisciplinaryAction.url(args, options),
            method: 'post',
        })
    
    reviewDisciplinaryAction.form = reviewDisciplinaryActionForm
const AdminIncidentsViolationsController = { index, show, store, update, destroy, archive, unarchive, storeDisciplinaryAction, reviewDisciplinaryAction }

export default AdminIncidentsViolationsController