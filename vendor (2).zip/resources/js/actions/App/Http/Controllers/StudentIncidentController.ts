import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\StudentIncidentController::store
 * @see app/Http/Controllers/StudentIncidentController.php:19
 * @route '/student/incidents'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/student/incidents',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StudentIncidentController::store
 * @see app/Http/Controllers/StudentIncidentController.php:19
 * @route '/student/incidents'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentIncidentController::store
 * @see app/Http/Controllers/StudentIncidentController.php:19
 * @route '/student/incidents'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StudentIncidentController::store
 * @see app/Http/Controllers/StudentIncidentController.php:19
 * @route '/student/incidents'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StudentIncidentController::store
 * @see app/Http/Controllers/StudentIncidentController.php:19
 * @route '/student/incidents'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const StudentIncidentController = { store }

export default StudentIncidentController