import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\StudentAdmissionSlipController::store
 * @see app/Http/Controllers/StudentAdmissionSlipController.php:17
 * @route '/student/admission-slip'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/student/admission-slip',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StudentAdmissionSlipController::store
 * @see app/Http/Controllers/StudentAdmissionSlipController.php:17
 * @route '/student/admission-slip'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentAdmissionSlipController::store
 * @see app/Http/Controllers/StudentAdmissionSlipController.php:17
 * @route '/student/admission-slip'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StudentAdmissionSlipController::store
 * @see app/Http/Controllers/StudentAdmissionSlipController.php:17
 * @route '/student/admission-slip'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StudentAdmissionSlipController::store
 * @see app/Http/Controllers/StudentAdmissionSlipController.php:17
 * @route '/student/admission-slip'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const StudentAdmissionSlipController = { store }

export default StudentAdmissionSlipController