import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AuthStatusController::loginBlock
 * @see app/Http/Controllers/AuthStatusController.php:10
 * @route '/api/auth/status/login-block'
 */
export const loginBlock = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: loginBlock.url(options),
    method: 'get',
})

loginBlock.definition = {
    methods: ["get","head"],
    url: '/api/auth/status/login-block',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AuthStatusController::loginBlock
 * @see app/Http/Controllers/AuthStatusController.php:10
 * @route '/api/auth/status/login-block'
 */
loginBlock.url = (options?: RouteQueryOptions) => {
    return loginBlock.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AuthStatusController::loginBlock
 * @see app/Http/Controllers/AuthStatusController.php:10
 * @route '/api/auth/status/login-block'
 */
loginBlock.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: loginBlock.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AuthStatusController::loginBlock
 * @see app/Http/Controllers/AuthStatusController.php:10
 * @route '/api/auth/status/login-block'
 */
loginBlock.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: loginBlock.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AuthStatusController::loginBlock
 * @see app/Http/Controllers/AuthStatusController.php:10
 * @route '/api/auth/status/login-block'
 */
    const loginBlockForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: loginBlock.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AuthStatusController::loginBlock
 * @see app/Http/Controllers/AuthStatusController.php:10
 * @route '/api/auth/status/login-block'
 */
        loginBlockForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: loginBlock.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AuthStatusController::loginBlock
 * @see app/Http/Controllers/AuthStatusController.php:10
 * @route '/api/auth/status/login-block'
 */
        loginBlockForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: loginBlock.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    loginBlock.form = loginBlockForm
/**
* @see \App\Http\Controllers\AuthStatusController::scannerBlock
 * @see app/Http/Controllers/AuthStatusController.php:27
 * @route '/api/auth/status/scanner-block'
 */
export const scannerBlock = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: scannerBlock.url(options),
    method: 'get',
})

scannerBlock.definition = {
    methods: ["get","head"],
    url: '/api/auth/status/scanner-block',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AuthStatusController::scannerBlock
 * @see app/Http/Controllers/AuthStatusController.php:27
 * @route '/api/auth/status/scanner-block'
 */
scannerBlock.url = (options?: RouteQueryOptions) => {
    return scannerBlock.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AuthStatusController::scannerBlock
 * @see app/Http/Controllers/AuthStatusController.php:27
 * @route '/api/auth/status/scanner-block'
 */
scannerBlock.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: scannerBlock.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AuthStatusController::scannerBlock
 * @see app/Http/Controllers/AuthStatusController.php:27
 * @route '/api/auth/status/scanner-block'
 */
scannerBlock.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: scannerBlock.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AuthStatusController::scannerBlock
 * @see app/Http/Controllers/AuthStatusController.php:27
 * @route '/api/auth/status/scanner-block'
 */
    const scannerBlockForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: scannerBlock.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AuthStatusController::scannerBlock
 * @see app/Http/Controllers/AuthStatusController.php:27
 * @route '/api/auth/status/scanner-block'
 */
        scannerBlockForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: scannerBlock.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AuthStatusController::scannerBlock
 * @see app/Http/Controllers/AuthStatusController.php:27
 * @route '/api/auth/status/scanner-block'
 */
        scannerBlockForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: scannerBlock.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    scannerBlock.form = scannerBlockForm
const AuthStatusController = { loginBlock, scannerBlock }

export default AuthStatusController