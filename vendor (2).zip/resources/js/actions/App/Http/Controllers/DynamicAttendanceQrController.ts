import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DynamicAttendanceQrController::show
 * @see app/Http/Controllers/DynamicAttendanceQrController.php:20
 * @route '/admin/attendance/{event}/dynamic-qr'
 */
export const show = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/attendance/{event}/dynamic-qr',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DynamicAttendanceQrController::show
 * @see app/Http/Controllers/DynamicAttendanceQrController.php:20
 * @route '/admin/attendance/{event}/dynamic-qr'
 */
show.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return show.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DynamicAttendanceQrController::show
 * @see app/Http/Controllers/DynamicAttendanceQrController.php:20
 * @route '/admin/attendance/{event}/dynamic-qr'
 */
show.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DynamicAttendanceQrController::show
 * @see app/Http/Controllers/DynamicAttendanceQrController.php:20
 * @route '/admin/attendance/{event}/dynamic-qr'
 */
show.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DynamicAttendanceQrController::show
 * @see app/Http/Controllers/DynamicAttendanceQrController.php:20
 * @route '/admin/attendance/{event}/dynamic-qr'
 */
    const showForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DynamicAttendanceQrController::show
 * @see app/Http/Controllers/DynamicAttendanceQrController.php:20
 * @route '/admin/attendance/{event}/dynamic-qr'
 */
        showForm.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DynamicAttendanceQrController::show
 * @see app/Http/Controllers/DynamicAttendanceQrController.php:20
 * @route '/admin/attendance/{event}/dynamic-qr'
 */
        showForm.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\DynamicAttendanceQrController::token
 * @see app/Http/Controllers/DynamicAttendanceQrController.php:39
 * @route '/admin/attendance/{event}/dynamic-qr/token'
 */
export const token = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: token.url(args, options),
    method: 'get',
})

token.definition = {
    methods: ["get","head"],
    url: '/admin/attendance/{event}/dynamic-qr/token',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DynamicAttendanceQrController::token
 * @see app/Http/Controllers/DynamicAttendanceQrController.php:39
 * @route '/admin/attendance/{event}/dynamic-qr/token'
 */
token.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return token.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DynamicAttendanceQrController::token
 * @see app/Http/Controllers/DynamicAttendanceQrController.php:39
 * @route '/admin/attendance/{event}/dynamic-qr/token'
 */
token.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: token.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DynamicAttendanceQrController::token
 * @see app/Http/Controllers/DynamicAttendanceQrController.php:39
 * @route '/admin/attendance/{event}/dynamic-qr/token'
 */
token.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: token.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DynamicAttendanceQrController::token
 * @see app/Http/Controllers/DynamicAttendanceQrController.php:39
 * @route '/admin/attendance/{event}/dynamic-qr/token'
 */
    const tokenForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: token.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DynamicAttendanceQrController::token
 * @see app/Http/Controllers/DynamicAttendanceQrController.php:39
 * @route '/admin/attendance/{event}/dynamic-qr/token'
 */
        tokenForm.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: token.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DynamicAttendanceQrController::token
 * @see app/Http/Controllers/DynamicAttendanceQrController.php:39
 * @route '/admin/attendance/{event}/dynamic-qr/token'
 */
        tokenForm.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: token.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    token.form = tokenForm
const DynamicAttendanceQrController = { show, token }

export default DynamicAttendanceQrController