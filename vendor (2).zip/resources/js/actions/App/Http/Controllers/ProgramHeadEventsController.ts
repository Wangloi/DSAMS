import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ProgramHeadEventsController::index
 * @see app/Http/Controllers/ProgramHeadEventsController.php:11
 * @route '/program-head/calendar-events'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/program-head/calendar-events',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProgramHeadEventsController::index
 * @see app/Http/Controllers/ProgramHeadEventsController.php:11
 * @route '/program-head/calendar-events'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramHeadEventsController::index
 * @see app/Http/Controllers/ProgramHeadEventsController.php:11
 * @route '/program-head/calendar-events'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProgramHeadEventsController::index
 * @see app/Http/Controllers/ProgramHeadEventsController.php:11
 * @route '/program-head/calendar-events'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProgramHeadEventsController::index
 * @see app/Http/Controllers/ProgramHeadEventsController.php:11
 * @route '/program-head/calendar-events'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProgramHeadEventsController::index
 * @see app/Http/Controllers/ProgramHeadEventsController.php:11
 * @route '/program-head/calendar-events'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProgramHeadEventsController::index
 * @see app/Http/Controllers/ProgramHeadEventsController.php:11
 * @route '/program-head/calendar-events'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const ProgramHeadEventsController = { index }

export default ProgramHeadEventsController