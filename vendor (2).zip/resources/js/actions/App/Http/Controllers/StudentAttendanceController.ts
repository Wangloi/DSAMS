import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\StudentAttendanceController::scannerPortal
 * @see app/Http/Controllers/StudentAttendanceController.php:317
 * @route '/student/attendance/scanner-portal/{event}'
 */
export const scannerPortal = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: scannerPortal.url(args, options),
    method: 'get',
})

scannerPortal.definition = {
    methods: ["get","head"],
    url: '/student/attendance/scanner-portal/{event}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StudentAttendanceController::scannerPortal
 * @see app/Http/Controllers/StudentAttendanceController.php:317
 * @route '/student/attendance/scanner-portal/{event}'
 */
scannerPortal.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return scannerPortal.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentAttendanceController::scannerPortal
 * @see app/Http/Controllers/StudentAttendanceController.php:317
 * @route '/student/attendance/scanner-portal/{event}'
 */
scannerPortal.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: scannerPortal.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StudentAttendanceController::scannerPortal
 * @see app/Http/Controllers/StudentAttendanceController.php:317
 * @route '/student/attendance/scanner-portal/{event}'
 */
scannerPortal.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: scannerPortal.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StudentAttendanceController::scannerPortal
 * @see app/Http/Controllers/StudentAttendanceController.php:317
 * @route '/student/attendance/scanner-portal/{event}'
 */
    const scannerPortalForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: scannerPortal.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StudentAttendanceController::scannerPortal
 * @see app/Http/Controllers/StudentAttendanceController.php:317
 * @route '/student/attendance/scanner-portal/{event}'
 */
        scannerPortalForm.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: scannerPortal.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StudentAttendanceController::scannerPortal
 * @see app/Http/Controllers/StudentAttendanceController.php:317
 * @route '/student/attendance/scanner-portal/{event}'
 */
        scannerPortalForm.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: scannerPortal.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    scannerPortal.form = scannerPortalForm
/**
* @see \App\Http\Controllers\StudentAttendanceController::scanAttendance
 * @see app/Http/Controllers/StudentAttendanceController.php:378
 * @route '/student/attendance/{event}/scan'
 */
export const scanAttendance = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: scanAttendance.url(args, options),
    method: 'post',
})

scanAttendance.definition = {
    methods: ["post"],
    url: '/student/attendance/{event}/scan',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StudentAttendanceController::scanAttendance
 * @see app/Http/Controllers/StudentAttendanceController.php:378
 * @route '/student/attendance/{event}/scan'
 */
scanAttendance.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return scanAttendance.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentAttendanceController::scanAttendance
 * @see app/Http/Controllers/StudentAttendanceController.php:378
 * @route '/student/attendance/{event}/scan'
 */
scanAttendance.post = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: scanAttendance.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StudentAttendanceController::scanAttendance
 * @see app/Http/Controllers/StudentAttendanceController.php:378
 * @route '/student/attendance/{event}/scan'
 */
    const scanAttendanceForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: scanAttendance.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StudentAttendanceController::scanAttendance
 * @see app/Http/Controllers/StudentAttendanceController.php:378
 * @route '/student/attendance/{event}/scan'
 */
        scanAttendanceForm.post = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: scanAttendance.url(args, options),
            method: 'post',
        })
    
    scanAttendance.form = scanAttendanceForm
/**
* @see \App\Http\Controllers\StudentAttendanceController::dynamicQrScan
 * @see app/Http/Controllers/StudentAttendanceController.php:621
 * @route '/student/attendance/{event}/dynamic-qr-scan'
 */
export const dynamicQrScan = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: dynamicQrScan.url(args, options),
    method: 'post',
})

dynamicQrScan.definition = {
    methods: ["post"],
    url: '/student/attendance/{event}/dynamic-qr-scan',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StudentAttendanceController::dynamicQrScan
 * @see app/Http/Controllers/StudentAttendanceController.php:621
 * @route '/student/attendance/{event}/dynamic-qr-scan'
 */
dynamicQrScan.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return dynamicQrScan.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentAttendanceController::dynamicQrScan
 * @see app/Http/Controllers/StudentAttendanceController.php:621
 * @route '/student/attendance/{event}/dynamic-qr-scan'
 */
dynamicQrScan.post = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: dynamicQrScan.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StudentAttendanceController::dynamicQrScan
 * @see app/Http/Controllers/StudentAttendanceController.php:621
 * @route '/student/attendance/{event}/dynamic-qr-scan'
 */
    const dynamicQrScanForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: dynamicQrScan.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StudentAttendanceController::dynamicQrScan
 * @see app/Http/Controllers/StudentAttendanceController.php:621
 * @route '/student/attendance/{event}/dynamic-qr-scan'
 */
        dynamicQrScanForm.post = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: dynamicQrScan.url(args, options),
            method: 'post',
        })
    
    dynamicQrScan.form = dynamicQrScanForm
const StudentAttendanceController = { scannerPortal, scanAttendance, dynamicQrScan }

export default StudentAttendanceController