import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\StudentEventsController::logs
 * @see app/Http/Controllers/StudentEventsController.php:16
 * @route '/student/events/{event}/logs'
 */
export const logs = (args: { event: string | number } | [event: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logs.url(args, options),
    method: 'get',
})

logs.definition = {
    methods: ["get","head"],
    url: '/student/events/{event}/logs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StudentEventsController::logs
 * @see app/Http/Controllers/StudentEventsController.php:16
 * @route '/student/events/{event}/logs'
 */
logs.url = (args: { event: string | number } | [event: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: args.event,
                }

    return logs.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentEventsController::logs
 * @see app/Http/Controllers/StudentEventsController.php:16
 * @route '/student/events/{event}/logs'
 */
logs.get = (args: { event: string | number } | [event: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logs.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StudentEventsController::logs
 * @see app/Http/Controllers/StudentEventsController.php:16
 * @route '/student/events/{event}/logs'
 */
logs.head = (args: { event: string | number } | [event: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: logs.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StudentEventsController::logs
 * @see app/Http/Controllers/StudentEventsController.php:16
 * @route '/student/events/{event}/logs'
 */
    const logsForm = (args: { event: string | number } | [event: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: logs.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StudentEventsController::logs
 * @see app/Http/Controllers/StudentEventsController.php:16
 * @route '/student/events/{event}/logs'
 */
        logsForm.get = (args: { event: string | number } | [event: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: logs.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StudentEventsController::logs
 * @see app/Http/Controllers/StudentEventsController.php:16
 * @route '/student/events/{event}/logs'
 */
        logsForm.head = (args: { event: string | number } | [event: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: logs.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    logs.form = logsForm
const StudentEventsController = { logs }

export default StudentEventsController