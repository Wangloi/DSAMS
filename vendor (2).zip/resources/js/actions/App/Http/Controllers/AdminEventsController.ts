import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminEventsController::index
 * @see app/Http/Controllers/AdminEventsController.php:20
 * @route '/admin/events'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/events',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminEventsController::index
 * @see app/Http/Controllers/AdminEventsController.php:20
 * @route '/admin/events'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEventsController::index
 * @see app/Http/Controllers/AdminEventsController.php:20
 * @route '/admin/events'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminEventsController::index
 * @see app/Http/Controllers/AdminEventsController.php:20
 * @route '/admin/events'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminEventsController::index
 * @see app/Http/Controllers/AdminEventsController.php:20
 * @route '/admin/events'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminEventsController::index
 * @see app/Http/Controllers/AdminEventsController.php:20
 * @route '/admin/events'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminEventsController::index
 * @see app/Http/Controllers/AdminEventsController.php:20
 * @route '/admin/events'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AdminEventsController::store
 * @see app/Http/Controllers/AdminEventsController.php:97
 * @route '/admin/events'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/events',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminEventsController::store
 * @see app/Http/Controllers/AdminEventsController.php:97
 * @route '/admin/events'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEventsController::store
 * @see app/Http/Controllers/AdminEventsController.php:97
 * @route '/admin/events'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminEventsController::store
 * @see app/Http/Controllers/AdminEventsController.php:97
 * @route '/admin/events'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminEventsController::store
 * @see app/Http/Controllers/AdminEventsController.php:97
 * @route '/admin/events'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AdminEventsController::create
 * @see app/Http/Controllers/AdminEventsController.php:86
 * @route '/admin/events/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/events/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminEventsController::create
 * @see app/Http/Controllers/AdminEventsController.php:86
 * @route '/admin/events/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEventsController::create
 * @see app/Http/Controllers/AdminEventsController.php:86
 * @route '/admin/events/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminEventsController::create
 * @see app/Http/Controllers/AdminEventsController.php:86
 * @route '/admin/events/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminEventsController::create
 * @see app/Http/Controllers/AdminEventsController.php:86
 * @route '/admin/events/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminEventsController::create
 * @see app/Http/Controllers/AdminEventsController.php:86
 * @route '/admin/events/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminEventsController::create
 * @see app/Http/Controllers/AdminEventsController.php:86
 * @route '/admin/events/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\AdminEventsController::show
 * @see app/Http/Controllers/AdminEventsController.php:151
 * @route '/admin/events/{event}'
 */
export const show = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/events/{event}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminEventsController::show
 * @see app/Http/Controllers/AdminEventsController.php:151
 * @route '/admin/events/{event}'
 */
show.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return show.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEventsController::show
 * @see app/Http/Controllers/AdminEventsController.php:151
 * @route '/admin/events/{event}'
 */
show.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminEventsController::show
 * @see app/Http/Controllers/AdminEventsController.php:151
 * @route '/admin/events/{event}'
 */
show.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminEventsController::show
 * @see app/Http/Controllers/AdminEventsController.php:151
 * @route '/admin/events/{event}'
 */
    const showForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminEventsController::show
 * @see app/Http/Controllers/AdminEventsController.php:151
 * @route '/admin/events/{event}'
 */
        showForm.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminEventsController::show
 * @see app/Http/Controllers/AdminEventsController.php:151
 * @route '/admin/events/{event}'
 */
        showForm.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\AdminEventsController::edit
 * @see app/Http/Controllers/AdminEventsController.php:161
 * @route '/admin/events/{event}/edit'
 */
export const edit = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/events/{event}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminEventsController::edit
 * @see app/Http/Controllers/AdminEventsController.php:161
 * @route '/admin/events/{event}/edit'
 */
edit.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return edit.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEventsController::edit
 * @see app/Http/Controllers/AdminEventsController.php:161
 * @route '/admin/events/{event}/edit'
 */
edit.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminEventsController::edit
 * @see app/Http/Controllers/AdminEventsController.php:161
 * @route '/admin/events/{event}/edit'
 */
edit.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminEventsController::edit
 * @see app/Http/Controllers/AdminEventsController.php:161
 * @route '/admin/events/{event}/edit'
 */
    const editForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminEventsController::edit
 * @see app/Http/Controllers/AdminEventsController.php:161
 * @route '/admin/events/{event}/edit'
 */
        editForm.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminEventsController::edit
 * @see app/Http/Controllers/AdminEventsController.php:161
 * @route '/admin/events/{event}/edit'
 */
        editForm.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\AdminEventsController::update
 * @see app/Http/Controllers/AdminEventsController.php:170
 * @route '/admin/events/{event}'
 */
export const update = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/events/{event}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AdminEventsController::update
 * @see app/Http/Controllers/AdminEventsController.php:170
 * @route '/admin/events/{event}'
 */
update.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return update.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEventsController::update
 * @see app/Http/Controllers/AdminEventsController.php:170
 * @route '/admin/events/{event}'
 */
update.put = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AdminEventsController::update
 * @see app/Http/Controllers/AdminEventsController.php:170
 * @route '/admin/events/{event}'
 */
    const updateForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminEventsController::update
 * @see app/Http/Controllers/AdminEventsController.php:170
 * @route '/admin/events/{event}'
 */
        updateForm.put = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\AdminEventsController::destroy
 * @see app/Http/Controllers/AdminEventsController.php:229
 * @route '/admin/events/{event}'
 */
export const destroy = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/events/{event}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AdminEventsController::destroy
 * @see app/Http/Controllers/AdminEventsController.php:229
 * @route '/admin/events/{event}'
 */
destroy.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return destroy.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEventsController::destroy
 * @see app/Http/Controllers/AdminEventsController.php:229
 * @route '/admin/events/{event}'
 */
destroy.delete = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\AdminEventsController::destroy
 * @see app/Http/Controllers/AdminEventsController.php:229
 * @route '/admin/events/{event}'
 */
    const destroyForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminEventsController::destroy
 * @see app/Http/Controllers/AdminEventsController.php:229
 * @route '/admin/events/{event}'
 */
        destroyForm.delete = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\AdminEventsController::archive
 * @see app/Http/Controllers/AdminEventsController.php:241
 * @route '/admin/events/{event}/archive'
 */
export const archive = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: archive.url(args, options),
    method: 'put',
})

archive.definition = {
    methods: ["put"],
    url: '/admin/events/{event}/archive',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AdminEventsController::archive
 * @see app/Http/Controllers/AdminEventsController.php:241
 * @route '/admin/events/{event}/archive'
 */
archive.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return archive.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEventsController::archive
 * @see app/Http/Controllers/AdminEventsController.php:241
 * @route '/admin/events/{event}/archive'
 */
archive.put = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: archive.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AdminEventsController::archive
 * @see app/Http/Controllers/AdminEventsController.php:241
 * @route '/admin/events/{event}/archive'
 */
    const archiveForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: archive.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminEventsController::archive
 * @see app/Http/Controllers/AdminEventsController.php:241
 * @route '/admin/events/{event}/archive'
 */
        archiveForm.put = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: archive.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    archive.form = archiveForm
/**
* @see \App\Http\Controllers\AdminEventsController::unarchive
 * @see app/Http/Controllers/AdminEventsController.php:248
 * @route '/admin/events/{event}/unarchive'
 */
export const unarchive = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: unarchive.url(args, options),
    method: 'put',
})

unarchive.definition = {
    methods: ["put"],
    url: '/admin/events/{event}/unarchive',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AdminEventsController::unarchive
 * @see app/Http/Controllers/AdminEventsController.php:248
 * @route '/admin/events/{event}/unarchive'
 */
unarchive.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return unarchive.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEventsController::unarchive
 * @see app/Http/Controllers/AdminEventsController.php:248
 * @route '/admin/events/{event}/unarchive'
 */
unarchive.put = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: unarchive.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AdminEventsController::unarchive
 * @see app/Http/Controllers/AdminEventsController.php:248
 * @route '/admin/events/{event}/unarchive'
 */
    const unarchiveForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unarchive.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminEventsController::unarchive
 * @see app/Http/Controllers/AdminEventsController.php:248
 * @route '/admin/events/{event}/unarchive'
 */
        unarchiveForm.put = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unarchive.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    unarchive.form = unarchiveForm
/**
* @see \App\Http\Controllers\AdminEventsController::qrCode
 * @see app/Http/Controllers/AdminEventsController.php:255
 * @route '/admin/events/{event}/qr-code'
 */
export const qrCode = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: qrCode.url(args, options),
    method: 'get',
})

qrCode.definition = {
    methods: ["get","head"],
    url: '/admin/events/{event}/qr-code',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminEventsController::qrCode
 * @see app/Http/Controllers/AdminEventsController.php:255
 * @route '/admin/events/{event}/qr-code'
 */
qrCode.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return qrCode.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEventsController::qrCode
 * @see app/Http/Controllers/AdminEventsController.php:255
 * @route '/admin/events/{event}/qr-code'
 */
qrCode.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: qrCode.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminEventsController::qrCode
 * @see app/Http/Controllers/AdminEventsController.php:255
 * @route '/admin/events/{event}/qr-code'
 */
qrCode.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: qrCode.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminEventsController::qrCode
 * @see app/Http/Controllers/AdminEventsController.php:255
 * @route '/admin/events/{event}/qr-code'
 */
    const qrCodeForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: qrCode.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminEventsController::qrCode
 * @see app/Http/Controllers/AdminEventsController.php:255
 * @route '/admin/events/{event}/qr-code'
 */
        qrCodeForm.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: qrCode.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminEventsController::qrCode
 * @see app/Http/Controllers/AdminEventsController.php:255
 * @route '/admin/events/{event}/qr-code'
 */
        qrCodeForm.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: qrCode.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    qrCode.form = qrCodeForm
/**
* @see \App\Http\Controllers\AdminEventsController::participantMonitoring
 * @see app/Http/Controllers/AdminEventsController.php:313
 * @route '/admin/events/{event}/participant-monitoring'
 */
export const participantMonitoring = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: participantMonitoring.url(args, options),
    method: 'get',
})

participantMonitoring.definition = {
    methods: ["get","head"],
    url: '/admin/events/{event}/participant-monitoring',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminEventsController::participantMonitoring
 * @see app/Http/Controllers/AdminEventsController.php:313
 * @route '/admin/events/{event}/participant-monitoring'
 */
participantMonitoring.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return participantMonitoring.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEventsController::participantMonitoring
 * @see app/Http/Controllers/AdminEventsController.php:313
 * @route '/admin/events/{event}/participant-monitoring'
 */
participantMonitoring.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: participantMonitoring.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminEventsController::participantMonitoring
 * @see app/Http/Controllers/AdminEventsController.php:313
 * @route '/admin/events/{event}/participant-monitoring'
 */
participantMonitoring.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: participantMonitoring.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminEventsController::participantMonitoring
 * @see app/Http/Controllers/AdminEventsController.php:313
 * @route '/admin/events/{event}/participant-monitoring'
 */
    const participantMonitoringForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: participantMonitoring.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminEventsController::participantMonitoring
 * @see app/Http/Controllers/AdminEventsController.php:313
 * @route '/admin/events/{event}/participant-monitoring'
 */
        participantMonitoringForm.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: participantMonitoring.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminEventsController::participantMonitoring
 * @see app/Http/Controllers/AdminEventsController.php:313
 * @route '/admin/events/{event}/participant-monitoring'
 */
        participantMonitoringForm.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: participantMonitoring.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    participantMonitoring.form = participantMonitoringForm
/**
* @see \App\Http\Controllers\AdminEventsController::attendanceAssignment
 * @see app/Http/Controllers/AdminEventsController.php:328
 * @route '/admin/events/{event}/attendance-assignment'
 */
export const attendanceAssignment = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: attendanceAssignment.url(args, options),
    method: 'get',
})

attendanceAssignment.definition = {
    methods: ["get","head"],
    url: '/admin/events/{event}/attendance-assignment',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminEventsController::attendanceAssignment
 * @see app/Http/Controllers/AdminEventsController.php:328
 * @route '/admin/events/{event}/attendance-assignment'
 */
attendanceAssignment.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return attendanceAssignment.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEventsController::attendanceAssignment
 * @see app/Http/Controllers/AdminEventsController.php:328
 * @route '/admin/events/{event}/attendance-assignment'
 */
attendanceAssignment.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: attendanceAssignment.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminEventsController::attendanceAssignment
 * @see app/Http/Controllers/AdminEventsController.php:328
 * @route '/admin/events/{event}/attendance-assignment'
 */
attendanceAssignment.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: attendanceAssignment.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminEventsController::attendanceAssignment
 * @see app/Http/Controllers/AdminEventsController.php:328
 * @route '/admin/events/{event}/attendance-assignment'
 */
    const attendanceAssignmentForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: attendanceAssignment.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminEventsController::attendanceAssignment
 * @see app/Http/Controllers/AdminEventsController.php:328
 * @route '/admin/events/{event}/attendance-assignment'
 */
        attendanceAssignmentForm.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: attendanceAssignment.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminEventsController::attendanceAssignment
 * @see app/Http/Controllers/AdminEventsController.php:328
 * @route '/admin/events/{event}/attendance-assignment'
 */
        attendanceAssignmentForm.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: attendanceAssignment.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    attendanceAssignment.form = attendanceAssignmentForm
/**
* @see \App\Http\Controllers\AdminEventsController::storeAttendanceAssignment
 * @see app/Http/Controllers/AdminEventsController.php:348
 * @route '/admin/events/{event}/attendance-assignment'
 */
export const storeAttendanceAssignment = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeAttendanceAssignment.url(args, options),
    method: 'post',
})

storeAttendanceAssignment.definition = {
    methods: ["post"],
    url: '/admin/events/{event}/attendance-assignment',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminEventsController::storeAttendanceAssignment
 * @see app/Http/Controllers/AdminEventsController.php:348
 * @route '/admin/events/{event}/attendance-assignment'
 */
storeAttendanceAssignment.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return storeAttendanceAssignment.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminEventsController::storeAttendanceAssignment
 * @see app/Http/Controllers/AdminEventsController.php:348
 * @route '/admin/events/{event}/attendance-assignment'
 */
storeAttendanceAssignment.post = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeAttendanceAssignment.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminEventsController::storeAttendanceAssignment
 * @see app/Http/Controllers/AdminEventsController.php:348
 * @route '/admin/events/{event}/attendance-assignment'
 */
    const storeAttendanceAssignmentForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeAttendanceAssignment.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminEventsController::storeAttendanceAssignment
 * @see app/Http/Controllers/AdminEventsController.php:348
 * @route '/admin/events/{event}/attendance-assignment'
 */
        storeAttendanceAssignmentForm.post = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeAttendanceAssignment.url(args, options),
            method: 'post',
        })
    
    storeAttendanceAssignment.form = storeAttendanceAssignmentForm
const AdminEventsController = { index, store, create, show, edit, update, destroy, archive, unarchive, qrCode, participantMonitoring, attendanceAssignment, storeAttendanceAssignment }

export default AdminEventsController