import UnifiedLoginController from './UnifiedLoginController'
import LandingController from './LandingController'
import AdminLoginController from './AdminLoginController'
import StudentLoginController from './StudentLoginController'
import ProgramHeadLoginController from './ProgramHeadLoginController'
import StudentDashboardController from './StudentDashboardController'
import StudentAttendanceController from './StudentAttendanceController'
import DynamicAttendanceQrController from './DynamicAttendanceQrController'
import StudentEvaluationController from './StudentEvaluationController'
import StudentEventsController from './StudentEventsController'
import NotificationController from './NotificationController'
import StudentIncidentController from './StudentIncidentController'
import StudentAdmissionSlipController from './StudentAdmissionSlipController'
import StudentRegistrationController from './StudentRegistrationController'
import ProgramHeadDashboardController from './ProgramHeadDashboardController'
import ProgramHeadAttendanceController from './ProgramHeadAttendanceController'
import ProgramHeadViolationsController from './ProgramHeadViolationsController'
import ProgramHeadReportsController from './ProgramHeadReportsController'
import ProgramHeadEventsController from './ProgramHeadEventsController'
import AdminDashboardController from './AdminDashboardController'
import AdminManageUsersController from './AdminManageUsersController'
import AdminProgramsController from './AdminProgramsController'
import AdminEventsController from './AdminEventsController'
import AdminAdmissionSlipController from './AdminAdmissionSlipController'
import DSAAdmissionSlipController from './DSAAdmissionSlipController'
import AdminIncidentsViolationsController from './AdminIncidentsViolationsController'
import AdminAttendanceController from './AdminAttendanceController'
import AdminAnalyticsController from './AdminAnalyticsController'
import AdminReportsController from './AdminReportsController'
import AdminEvaluationController from './AdminEvaluationController'
import AdminArchiveController from './AdminArchiveController'
import AdminActivityLogController from './AdminActivityLogController'
import CertificateController from './CertificateController'
import AuthStatusController from './AuthStatusController'
import SecurityAlertController from './SecurityAlertController'
import Settings from './Settings'
const Controllers = {
    UnifiedLoginController: Object.assign(UnifiedLoginController, UnifiedLoginController),
LandingController: Object.assign(LandingController, LandingController),
AdminLoginController: Object.assign(AdminLoginController, AdminLoginController),
StudentLoginController: Object.assign(StudentLoginController, StudentLoginController),
ProgramHeadLoginController: Object.assign(ProgramHeadLoginController, ProgramHeadLoginController),
StudentDashboardController: Object.assign(StudentDashboardController, StudentDashboardController),
StudentAttendanceController: Object.assign(StudentAttendanceController, StudentAttendanceController),
DynamicAttendanceQrController: Object.assign(DynamicAttendanceQrController, DynamicAttendanceQrController),
StudentEvaluationController: Object.assign(StudentEvaluationController, StudentEvaluationController),
StudentEventsController: Object.assign(StudentEventsController, StudentEventsController),
NotificationController: Object.assign(NotificationController, NotificationController),
StudentIncidentController: Object.assign(StudentIncidentController, StudentIncidentController),
StudentAdmissionSlipController: Object.assign(StudentAdmissionSlipController, StudentAdmissionSlipController),
StudentRegistrationController: Object.assign(StudentRegistrationController, StudentRegistrationController),
ProgramHeadDashboardController: Object.assign(ProgramHeadDashboardController, ProgramHeadDashboardController),
ProgramHeadAttendanceController: Object.assign(ProgramHeadAttendanceController, ProgramHeadAttendanceController),
ProgramHeadViolationsController: Object.assign(ProgramHeadViolationsController, ProgramHeadViolationsController),
ProgramHeadReportsController: Object.assign(ProgramHeadReportsController, ProgramHeadReportsController),
ProgramHeadEventsController: Object.assign(ProgramHeadEventsController, ProgramHeadEventsController),
AdminDashboardController: Object.assign(AdminDashboardController, AdminDashboardController),
AdminManageUsersController: Object.assign(AdminManageUsersController, AdminManageUsersController),
AdminProgramsController: Object.assign(AdminProgramsController, AdminProgramsController),
AdminEventsController: Object.assign(AdminEventsController, AdminEventsController),
AdminAdmissionSlipController: Object.assign(AdminAdmissionSlipController, AdminAdmissionSlipController),
DSAAdmissionSlipController: Object.assign(DSAAdmissionSlipController, DSAAdmissionSlipController),
AdminIncidentsViolationsController: Object.assign(AdminIncidentsViolationsController, AdminIncidentsViolationsController),
AdminAttendanceController: Object.assign(AdminAttendanceController, AdminAttendanceController),
AdminAnalyticsController: Object.assign(AdminAnalyticsController, AdminAnalyticsController),
AdminReportsController: Object.assign(AdminReportsController, AdminReportsController),
AdminEvaluationController: Object.assign(AdminEvaluationController, AdminEvaluationController),
AdminArchiveController: Object.assign(AdminArchiveController, AdminArchiveController),
AdminActivityLogController: Object.assign(AdminActivityLogController, AdminActivityLogController),
CertificateController: Object.assign(CertificateController, CertificateController),
AuthStatusController: Object.assign(AuthStatusController, AuthStatusController),
SecurityAlertController: Object.assign(SecurityAlertController, SecurityAlertController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers