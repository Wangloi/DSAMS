import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\StudentRegistrationController::storeStep1
 * @see app/Http/Controllers/StudentRegistrationController.php:13
 * @route '/student-register/step1'
 */
export const storeStep1 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeStep1.url(options),
    method: 'post',
})

storeStep1.definition = {
    methods: ["post"],
    url: '/student-register/step1',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StudentRegistrationController::storeStep1
 * @see app/Http/Controllers/StudentRegistrationController.php:13
 * @route '/student-register/step1'
 */
storeStep1.url = (options?: RouteQueryOptions) => {
    return storeStep1.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentRegistrationController::storeStep1
 * @see app/Http/Controllers/StudentRegistrationController.php:13
 * @route '/student-register/step1'
 */
storeStep1.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeStep1.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StudentRegistrationController::storeStep1
 * @see app/Http/Controllers/StudentRegistrationController.php:13
 * @route '/student-register/step1'
 */
    const storeStep1Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeStep1.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StudentRegistrationController::storeStep1
 * @see app/Http/Controllers/StudentRegistrationController.php:13
 * @route '/student-register/step1'
 */
        storeStep1Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeStep1.url(options),
            method: 'post',
        })
    
    storeStep1.form = storeStep1Form
/**
* @see \App\Http\Controllers\StudentRegistrationController::storeStep2
 * @see app/Http/Controllers/StudentRegistrationController.php:49
 * @route '/student-register/step2'
 */
export const storeStep2 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeStep2.url(options),
    method: 'post',
})

storeStep2.definition = {
    methods: ["post"],
    url: '/student-register/step2',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StudentRegistrationController::storeStep2
 * @see app/Http/Controllers/StudentRegistrationController.php:49
 * @route '/student-register/step2'
 */
storeStep2.url = (options?: RouteQueryOptions) => {
    return storeStep2.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentRegistrationController::storeStep2
 * @see app/Http/Controllers/StudentRegistrationController.php:49
 * @route '/student-register/step2'
 */
storeStep2.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeStep2.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StudentRegistrationController::storeStep2
 * @see app/Http/Controllers/StudentRegistrationController.php:49
 * @route '/student-register/step2'
 */
    const storeStep2Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeStep2.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StudentRegistrationController::storeStep2
 * @see app/Http/Controllers/StudentRegistrationController.php:49
 * @route '/student-register/step2'
 */
        storeStep2Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeStep2.url(options),
            method: 'post',
        })
    
    storeStep2.form = storeStep2Form
/**
* @see \App\Http\Controllers\StudentRegistrationController::storeStep3
 * @see app/Http/Controllers/StudentRegistrationController.php:77
 * @route '/student-register/step3'
 */
export const storeStep3 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeStep3.url(options),
    method: 'post',
})

storeStep3.definition = {
    methods: ["post"],
    url: '/student-register/step3',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StudentRegistrationController::storeStep3
 * @see app/Http/Controllers/StudentRegistrationController.php:77
 * @route '/student-register/step3'
 */
storeStep3.url = (options?: RouteQueryOptions) => {
    return storeStep3.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentRegistrationController::storeStep3
 * @see app/Http/Controllers/StudentRegistrationController.php:77
 * @route '/student-register/step3'
 */
storeStep3.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeStep3.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StudentRegistrationController::storeStep3
 * @see app/Http/Controllers/StudentRegistrationController.php:77
 * @route '/student-register/step3'
 */
    const storeStep3Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeStep3.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StudentRegistrationController::storeStep3
 * @see app/Http/Controllers/StudentRegistrationController.php:77
 * @route '/student-register/step3'
 */
        storeStep3Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeStep3.url(options),
            method: 'post',
        })
    
    storeStep3.form = storeStep3Form
/**
* @see \App\Http\Controllers\StudentRegistrationController::storeStep4
 * @see app/Http/Controllers/StudentRegistrationController.php:104
 * @route '/student-register/step4'
 */
export const storeStep4 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeStep4.url(options),
    method: 'post',
})

storeStep4.definition = {
    methods: ["post"],
    url: '/student-register/step4',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StudentRegistrationController::storeStep4
 * @see app/Http/Controllers/StudentRegistrationController.php:104
 * @route '/student-register/step4'
 */
storeStep4.url = (options?: RouteQueryOptions) => {
    return storeStep4.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentRegistrationController::storeStep4
 * @see app/Http/Controllers/StudentRegistrationController.php:104
 * @route '/student-register/step4'
 */
storeStep4.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeStep4.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StudentRegistrationController::storeStep4
 * @see app/Http/Controllers/StudentRegistrationController.php:104
 * @route '/student-register/step4'
 */
    const storeStep4Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeStep4.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StudentRegistrationController::storeStep4
 * @see app/Http/Controllers/StudentRegistrationController.php:104
 * @route '/student-register/step4'
 */
        storeStep4Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeStep4.url(options),
            method: 'post',
        })
    
    storeStep4.form = storeStep4Form
/**
* @see \App\Http\Controllers\StudentRegistrationController::complete
 * @see app/Http/Controllers/StudentRegistrationController.php:168
 * @route '/student-register/complete'
 */
export const complete = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(options),
    method: 'post',
})

complete.definition = {
    methods: ["post"],
    url: '/student-register/complete',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StudentRegistrationController::complete
 * @see app/Http/Controllers/StudentRegistrationController.php:168
 * @route '/student-register/complete'
 */
complete.url = (options?: RouteQueryOptions) => {
    return complete.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentRegistrationController::complete
 * @see app/Http/Controllers/StudentRegistrationController.php:168
 * @route '/student-register/complete'
 */
complete.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StudentRegistrationController::complete
 * @see app/Http/Controllers/StudentRegistrationController.php:168
 * @route '/student-register/complete'
 */
    const completeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: complete.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StudentRegistrationController::complete
 * @see app/Http/Controllers/StudentRegistrationController.php:168
 * @route '/student-register/complete'
 */
        completeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: complete.url(options),
            method: 'post',
        })
    
    complete.form = completeForm
/**
* @see \App\Http\Controllers\StudentRegistrationController::restart
 * @see app/Http/Controllers/StudentRegistrationController.php:258
 * @route '/student-register/restart'
 */
export const restart = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restart.url(options),
    method: 'post',
})

restart.definition = {
    methods: ["post"],
    url: '/student-register/restart',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StudentRegistrationController::restart
 * @see app/Http/Controllers/StudentRegistrationController.php:258
 * @route '/student-register/restart'
 */
restart.url = (options?: RouteQueryOptions) => {
    return restart.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentRegistrationController::restart
 * @see app/Http/Controllers/StudentRegistrationController.php:258
 * @route '/student-register/restart'
 */
restart.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restart.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StudentRegistrationController::restart
 * @see app/Http/Controllers/StudentRegistrationController.php:258
 * @route '/student-register/restart'
 */
    const restartForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restart.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StudentRegistrationController::restart
 * @see app/Http/Controllers/StudentRegistrationController.php:258
 * @route '/student-register/restart'
 */
        restartForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restart.url(options),
            method: 'post',
        })
    
    restart.form = restartForm
const StudentRegistrationController = { storeStep1, storeStep2, storeStep3, storeStep4, complete, restart }

export default StudentRegistrationController