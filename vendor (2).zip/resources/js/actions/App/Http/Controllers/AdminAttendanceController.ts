import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminAttendanceController::activateScannerPortal
 * @see app/Http/Controllers/AdminAttendanceController.php:203
 * @route '/admin/attendance/{event}/activate-scanner-portal'
 */
export const activateScannerPortal = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: activateScannerPortal.url(args, options),
    method: 'post',
})

activateScannerPortal.definition = {
    methods: ["post"],
    url: '/admin/attendance/{event}/activate-scanner-portal',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminAttendanceController::activateScannerPortal
 * @see app/Http/Controllers/AdminAttendanceController.php:203
 * @route '/admin/attendance/{event}/activate-scanner-portal'
 */
activateScannerPortal.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return activateScannerPortal.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminAttendanceController::activateScannerPortal
 * @see app/Http/Controllers/AdminAttendanceController.php:203
 * @route '/admin/attendance/{event}/activate-scanner-portal'
 */
activateScannerPortal.post = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: activateScannerPortal.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminAttendanceController::activateScannerPortal
 * @see app/Http/Controllers/AdminAttendanceController.php:203
 * @route '/admin/attendance/{event}/activate-scanner-portal'
 */
    const activateScannerPortalForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: activateScannerPortal.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminAttendanceController::activateScannerPortal
 * @see app/Http/Controllers/AdminAttendanceController.php:203
 * @route '/admin/attendance/{event}/activate-scanner-portal'
 */
        activateScannerPortalForm.post = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: activateScannerPortal.url(args, options),
            method: 'post',
        })
    
    activateScannerPortal.form = activateScannerPortalForm
/**
* @see \App\Http\Controllers\AdminAttendanceController::logs
 * @see app/Http/Controllers/AdminAttendanceController.php:222
 * @route '/admin/attendance/{event}/logs'
 */
export const logs = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logs.url(args, options),
    method: 'get',
})

logs.definition = {
    methods: ["get","head"],
    url: '/admin/attendance/{event}/logs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminAttendanceController::logs
 * @see app/Http/Controllers/AdminAttendanceController.php:222
 * @route '/admin/attendance/{event}/logs'
 */
logs.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return logs.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminAttendanceController::logs
 * @see app/Http/Controllers/AdminAttendanceController.php:222
 * @route '/admin/attendance/{event}/logs'
 */
logs.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logs.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminAttendanceController::logs
 * @see app/Http/Controllers/AdminAttendanceController.php:222
 * @route '/admin/attendance/{event}/logs'
 */
logs.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: logs.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminAttendanceController::logs
 * @see app/Http/Controllers/AdminAttendanceController.php:222
 * @route '/admin/attendance/{event}/logs'
 */
    const logsForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: logs.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminAttendanceController::logs
 * @see app/Http/Controllers/AdminAttendanceController.php:222
 * @route '/admin/attendance/{event}/logs'
 */
        logsForm.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: logs.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminAttendanceController::logs
 * @see app/Http/Controllers/AdminAttendanceController.php:222
 * @route '/admin/attendance/{event}/logs'
 */
        logsForm.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: logs.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    logs.form = logsForm
/**
* @see \App\Http\Controllers\AdminAttendanceController::studentsByCourse
 * @see app/Http/Controllers/AdminAttendanceController.php:509
 * @route '/admin/attendance/{event}/students-by-course'
 */
export const studentsByCourse = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: studentsByCourse.url(args, options),
    method: 'get',
})

studentsByCourse.definition = {
    methods: ["get","head"],
    url: '/admin/attendance/{event}/students-by-course',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminAttendanceController::studentsByCourse
 * @see app/Http/Controllers/AdminAttendanceController.php:509
 * @route '/admin/attendance/{event}/students-by-course'
 */
studentsByCourse.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return studentsByCourse.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminAttendanceController::studentsByCourse
 * @see app/Http/Controllers/AdminAttendanceController.php:509
 * @route '/admin/attendance/{event}/students-by-course'
 */
studentsByCourse.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: studentsByCourse.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminAttendanceController::studentsByCourse
 * @see app/Http/Controllers/AdminAttendanceController.php:509
 * @route '/admin/attendance/{event}/students-by-course'
 */
studentsByCourse.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: studentsByCourse.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminAttendanceController::studentsByCourse
 * @see app/Http/Controllers/AdminAttendanceController.php:509
 * @route '/admin/attendance/{event}/students-by-course'
 */
    const studentsByCourseForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: studentsByCourse.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminAttendanceController::studentsByCourse
 * @see app/Http/Controllers/AdminAttendanceController.php:509
 * @route '/admin/attendance/{event}/students-by-course'
 */
        studentsByCourseForm.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: studentsByCourse.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminAttendanceController::studentsByCourse
 * @see app/Http/Controllers/AdminAttendanceController.php:509
 * @route '/admin/attendance/{event}/students-by-course'
 */
        studentsByCourseForm.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: studentsByCourse.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    studentsByCourse.form = studentsByCourseForm
/**
* @see \App\Http\Controllers\AdminAttendanceController::scanAttendance
 * @see app/Http/Controllers/AdminAttendanceController.php:354
 * @route '/admin/attendance/{event}/scan'
 */
export const scanAttendance = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: scanAttendance.url(args, options),
    method: 'post',
})

scanAttendance.definition = {
    methods: ["post"],
    url: '/admin/attendance/{event}/scan',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminAttendanceController::scanAttendance
 * @see app/Http/Controllers/AdminAttendanceController.php:354
 * @route '/admin/attendance/{event}/scan'
 */
scanAttendance.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return scanAttendance.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminAttendanceController::scanAttendance
 * @see app/Http/Controllers/AdminAttendanceController.php:354
 * @route '/admin/attendance/{event}/scan'
 */
scanAttendance.post = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: scanAttendance.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminAttendanceController::scanAttendance
 * @see app/Http/Controllers/AdminAttendanceController.php:354
 * @route '/admin/attendance/{event}/scan'
 */
    const scanAttendanceForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: scanAttendance.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminAttendanceController::scanAttendance
 * @see app/Http/Controllers/AdminAttendanceController.php:354
 * @route '/admin/attendance/{event}/scan'
 */
        scanAttendanceForm.post = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: scanAttendance.url(args, options),
            method: 'post',
        })
    
    scanAttendance.form = scanAttendanceForm
/**
* @see \App\Http\Controllers\AdminAttendanceController::update
 * @see app/Http/Controllers/AdminAttendanceController.php:650
 * @route '/admin/attendance/{event}'
 */
export const update = (args: { event: string | number } | [event: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","post"],
    url: '/admin/attendance/{event}',
} satisfies RouteDefinition<["put","post"]>

/**
* @see \App\Http\Controllers\AdminAttendanceController::update
 * @see app/Http/Controllers/AdminAttendanceController.php:650
 * @route '/admin/attendance/{event}'
 */
update.url = (args: { event: string | number } | [event: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: args.event,
                }

    return update.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminAttendanceController::update
 * @see app/Http/Controllers/AdminAttendanceController.php:650
 * @route '/admin/attendance/{event}'
 */
update.put = (args: { event: string | number } | [event: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\AdminAttendanceController::update
 * @see app/Http/Controllers/AdminAttendanceController.php:650
 * @route '/admin/attendance/{event}'
 */
update.post = (args: { event: string | number } | [event: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminAttendanceController::update
 * @see app/Http/Controllers/AdminAttendanceController.php:650
 * @route '/admin/attendance/{event}'
 */
    const updateForm = (args: { event: string | number } | [event: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminAttendanceController::update
 * @see app/Http/Controllers/AdminAttendanceController.php:650
 * @route '/admin/attendance/{event}'
 */
        updateForm.put = (args: { event: string | number } | [event: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\AdminAttendanceController::update
 * @see app/Http/Controllers/AdminAttendanceController.php:650
 * @route '/admin/attendance/{event}'
 */
        updateForm.post = (args: { event: string | number } | [event: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, options),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\AdminAttendanceController::destroy
 * @see app/Http/Controllers/AdminAttendanceController.php:736
 * @route '/admin/attendance/{event}'
 */
export const destroy = (args: { event: string | number } | [event: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/attendance/{event}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AdminAttendanceController::destroy
 * @see app/Http/Controllers/AdminAttendanceController.php:736
 * @route '/admin/attendance/{event}'
 */
destroy.url = (args: { event: string | number } | [event: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: args.event,
                }

    return destroy.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminAttendanceController::destroy
 * @see app/Http/Controllers/AdminAttendanceController.php:736
 * @route '/admin/attendance/{event}'
 */
destroy.delete = (args: { event: string | number } | [event: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\AdminAttendanceController::destroy
 * @see app/Http/Controllers/AdminAttendanceController.php:736
 * @route '/admin/attendance/{event}'
 */
    const destroyForm = (args: { event: string | number } | [event: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminAttendanceController::destroy
 * @see app/Http/Controllers/AdminAttendanceController.php:736
 * @route '/admin/attendance/{event}'
 */
        destroyForm.delete = (args: { event: string | number } | [event: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\AdminAttendanceController::archive
 * @see app/Http/Controllers/AdminAttendanceController.php:835
 * @route '/admin/attendance/{event}/archive'
 */
export const archive = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: archive.url(args, options),
    method: 'put',
})

archive.definition = {
    methods: ["put"],
    url: '/admin/attendance/{event}/archive',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AdminAttendanceController::archive
 * @see app/Http/Controllers/AdminAttendanceController.php:835
 * @route '/admin/attendance/{event}/archive'
 */
archive.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return archive.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminAttendanceController::archive
 * @see app/Http/Controllers/AdminAttendanceController.php:835
 * @route '/admin/attendance/{event}/archive'
 */
archive.put = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: archive.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AdminAttendanceController::archive
 * @see app/Http/Controllers/AdminAttendanceController.php:835
 * @route '/admin/attendance/{event}/archive'
 */
    const archiveForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: archive.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminAttendanceController::archive
 * @see app/Http/Controllers/AdminAttendanceController.php:835
 * @route '/admin/attendance/{event}/archive'
 */
        archiveForm.put = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: archive.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    archive.form = archiveForm
/**
* @see \App\Http\Controllers\AdminAttendanceController::unarchive
 * @see app/Http/Controllers/AdminAttendanceController.php:842
 * @route '/admin/attendance/{event}/unarchive'
 */
export const unarchive = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: unarchive.url(args, options),
    method: 'put',
})

unarchive.definition = {
    methods: ["put"],
    url: '/admin/attendance/{event}/unarchive',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AdminAttendanceController::unarchive
 * @see app/Http/Controllers/AdminAttendanceController.php:842
 * @route '/admin/attendance/{event}/unarchive'
 */
unarchive.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return unarchive.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminAttendanceController::unarchive
 * @see app/Http/Controllers/AdminAttendanceController.php:842
 * @route '/admin/attendance/{event}/unarchive'
 */
unarchive.put = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: unarchive.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AdminAttendanceController::unarchive
 * @see app/Http/Controllers/AdminAttendanceController.php:842
 * @route '/admin/attendance/{event}/unarchive'
 */
    const unarchiveForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unarchive.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminAttendanceController::unarchive
 * @see app/Http/Controllers/AdminAttendanceController.php:842
 * @route '/admin/attendance/{event}/unarchive'
 */
        unarchiveForm.put = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unarchive.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    unarchive.form = unarchiveForm
/**
* @see \App\Http\Controllers\AdminAttendanceController::index
 * @see app/Http/Controllers/AdminAttendanceController.php:20
 * @route '/admin/attendance'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/attendance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminAttendanceController::index
 * @see app/Http/Controllers/AdminAttendanceController.php:20
 * @route '/admin/attendance'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminAttendanceController::index
 * @see app/Http/Controllers/AdminAttendanceController.php:20
 * @route '/admin/attendance'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminAttendanceController::index
 * @see app/Http/Controllers/AdminAttendanceController.php:20
 * @route '/admin/attendance'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminAttendanceController::index
 * @see app/Http/Controllers/AdminAttendanceController.php:20
 * @route '/admin/attendance'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminAttendanceController::index
 * @see app/Http/Controllers/AdminAttendanceController.php:20
 * @route '/admin/attendance'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminAttendanceController::index
 * @see app/Http/Controllers/AdminAttendanceController.php:20
 * @route '/admin/attendance'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AdminAttendanceController::store
 * @see app/Http/Controllers/AdminAttendanceController.php:565
 * @route '/admin/attendance'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/attendance',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminAttendanceController::store
 * @see app/Http/Controllers/AdminAttendanceController.php:565
 * @route '/admin/attendance'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminAttendanceController::store
 * @see app/Http/Controllers/AdminAttendanceController.php:565
 * @route '/admin/attendance'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminAttendanceController::store
 * @see app/Http/Controllers/AdminAttendanceController.php:565
 * @route '/admin/attendance'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminAttendanceController::store
 * @see app/Http/Controllers/AdminAttendanceController.php:565
 * @route '/admin/attendance'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AdminAttendanceController::printEvent
 * @see app/Http/Controllers/AdminAttendanceController.php:763
 * @route '/admin/attendance/{event}/print'
 */
export const printEvent = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printEvent.url(args, options),
    method: 'get',
})

printEvent.definition = {
    methods: ["get","head"],
    url: '/admin/attendance/{event}/print',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminAttendanceController::printEvent
 * @see app/Http/Controllers/AdminAttendanceController.php:763
 * @route '/admin/attendance/{event}/print'
 */
printEvent.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return printEvent.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminAttendanceController::printEvent
 * @see app/Http/Controllers/AdminAttendanceController.php:763
 * @route '/admin/attendance/{event}/print'
 */
printEvent.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printEvent.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminAttendanceController::printEvent
 * @see app/Http/Controllers/AdminAttendanceController.php:763
 * @route '/admin/attendance/{event}/print'
 */
printEvent.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: printEvent.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminAttendanceController::printEvent
 * @see app/Http/Controllers/AdminAttendanceController.php:763
 * @route '/admin/attendance/{event}/print'
 */
    const printEventForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: printEvent.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminAttendanceController::printEvent
 * @see app/Http/Controllers/AdminAttendanceController.php:763
 * @route '/admin/attendance/{event}/print'
 */
        printEventForm.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: printEvent.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminAttendanceController::printEvent
 * @see app/Http/Controllers/AdminAttendanceController.php:763
 * @route '/admin/attendance/{event}/print'
 */
        printEventForm.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: printEvent.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    printEvent.form = printEventForm
const AdminAttendanceController = { activateScannerPortal, logs, studentsByCourse, scanAttendance, update, destroy, archive, unarchive, index, store, printEvent }

export default AdminAttendanceController