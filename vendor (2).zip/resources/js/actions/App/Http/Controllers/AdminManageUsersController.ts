import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminManageUsersController::index
 * @see app/Http/Controllers/AdminManageUsersController.php:22
 * @route '/admin/manage-users'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/manage-users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminManageUsersController::index
 * @see app/Http/Controllers/AdminManageUsersController.php:22
 * @route '/admin/manage-users'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminManageUsersController::index
 * @see app/Http/Controllers/AdminManageUsersController.php:22
 * @route '/admin/manage-users'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminManageUsersController::index
 * @see app/Http/Controllers/AdminManageUsersController.php:22
 * @route '/admin/manage-users'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminManageUsersController::index
 * @see app/Http/Controllers/AdminManageUsersController.php:22
 * @route '/admin/manage-users'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminManageUsersController::index
 * @see app/Http/Controllers/AdminManageUsersController.php:22
 * @route '/admin/manage-users'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminManageUsersController::index
 * @see app/Http/Controllers/AdminManageUsersController.php:22
 * @route '/admin/manage-users'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AdminManageUsersController::store
 * @see app/Http/Controllers/AdminManageUsersController.php:243
 * @route '/admin/manage-users'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/manage-users',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminManageUsersController::store
 * @see app/Http/Controllers/AdminManageUsersController.php:243
 * @route '/admin/manage-users'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminManageUsersController::store
 * @see app/Http/Controllers/AdminManageUsersController.php:243
 * @route '/admin/manage-users'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminManageUsersController::store
 * @see app/Http/Controllers/AdminManageUsersController.php:243
 * @route '/admin/manage-users'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminManageUsersController::store
 * @see app/Http/Controllers/AdminManageUsersController.php:243
 * @route '/admin/manage-users'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AdminManageUsersController::updateLegacy
 * @see app/Http/Controllers/AdminManageUsersController.php:382
 * @route '/admin/manage-users'
 */
export const updateLegacy = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateLegacy.url(options),
    method: 'put',
})

updateLegacy.definition = {
    methods: ["put"],
    url: '/admin/manage-users',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AdminManageUsersController::updateLegacy
 * @see app/Http/Controllers/AdminManageUsersController.php:382
 * @route '/admin/manage-users'
 */
updateLegacy.url = (options?: RouteQueryOptions) => {
    return updateLegacy.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminManageUsersController::updateLegacy
 * @see app/Http/Controllers/AdminManageUsersController.php:382
 * @route '/admin/manage-users'
 */
updateLegacy.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateLegacy.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AdminManageUsersController::updateLegacy
 * @see app/Http/Controllers/AdminManageUsersController.php:382
 * @route '/admin/manage-users'
 */
    const updateLegacyForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateLegacy.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminManageUsersController::updateLegacy
 * @see app/Http/Controllers/AdminManageUsersController.php:382
 * @route '/admin/manage-users'
 */
        updateLegacyForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateLegacy.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateLegacy.form = updateLegacyForm
/**
* @see \App\Http\Controllers\AdminManageUsersController::destroyLegacy
 * @see app/Http/Controllers/AdminManageUsersController.php:394
 * @route '/admin/manage-users'
 */
export const destroyLegacy = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyLegacy.url(options),
    method: 'delete',
})

destroyLegacy.definition = {
    methods: ["delete"],
    url: '/admin/manage-users',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AdminManageUsersController::destroyLegacy
 * @see app/Http/Controllers/AdminManageUsersController.php:394
 * @route '/admin/manage-users'
 */
destroyLegacy.url = (options?: RouteQueryOptions) => {
    return destroyLegacy.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminManageUsersController::destroyLegacy
 * @see app/Http/Controllers/AdminManageUsersController.php:394
 * @route '/admin/manage-users'
 */
destroyLegacy.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyLegacy.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\AdminManageUsersController::destroyLegacy
 * @see app/Http/Controllers/AdminManageUsersController.php:394
 * @route '/admin/manage-users'
 */
    const destroyLegacyForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyLegacy.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminManageUsersController::destroyLegacy
 * @see app/Http/Controllers/AdminManageUsersController.php:394
 * @route '/admin/manage-users'
 */
        destroyLegacyForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyLegacy.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyLegacy.form = destroyLegacyForm
/**
* @see \App\Http\Controllers\AdminManageUsersController::update
 * @see app/Http/Controllers/AdminManageUsersController.php:460
 * @route '/admin/manage-users/{student}'
 */
export const update = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/manage-users/{student}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AdminManageUsersController::update
 * @see app/Http/Controllers/AdminManageUsersController.php:460
 * @route '/admin/manage-users/{student}'
 */
update.url = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { student: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    student: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student: typeof args.student === 'object'
                ? args.student.id
                : args.student,
                }

    return update.definition.url
            .replace('{student}', parsedArgs.student.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminManageUsersController::update
 * @see app/Http/Controllers/AdminManageUsersController.php:460
 * @route '/admin/manage-users/{student}'
 */
update.put = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AdminManageUsersController::update
 * @see app/Http/Controllers/AdminManageUsersController.php:460
 * @route '/admin/manage-users/{student}'
 */
    const updateForm = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminManageUsersController::update
 * @see app/Http/Controllers/AdminManageUsersController.php:460
 * @route '/admin/manage-users/{student}'
 */
        updateForm.put = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\AdminManageUsersController::updateStatus
 * @see app/Http/Controllers/AdminManageUsersController.php:312
 * @route '/admin/manage-users/{student}/status'
 */
export const updateStatus = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateStatus.url(args, options),
    method: 'put',
})

updateStatus.definition = {
    methods: ["put","post"],
    url: '/admin/manage-users/{student}/status',
} satisfies RouteDefinition<["put","post"]>

/**
* @see \App\Http\Controllers\AdminManageUsersController::updateStatus
 * @see app/Http/Controllers/AdminManageUsersController.php:312
 * @route '/admin/manage-users/{student}/status'
 */
updateStatus.url = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { student: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    student: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student: typeof args.student === 'object'
                ? args.student.id
                : args.student,
                }

    return updateStatus.definition.url
            .replace('{student}', parsedArgs.student.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminManageUsersController::updateStatus
 * @see app/Http/Controllers/AdminManageUsersController.php:312
 * @route '/admin/manage-users/{student}/status'
 */
updateStatus.put = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateStatus.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\AdminManageUsersController::updateStatus
 * @see app/Http/Controllers/AdminManageUsersController.php:312
 * @route '/admin/manage-users/{student}/status'
 */
updateStatus.post = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateStatus.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminManageUsersController::updateStatus
 * @see app/Http/Controllers/AdminManageUsersController.php:312
 * @route '/admin/manage-users/{student}/status'
 */
    const updateStatusForm = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateStatus.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminManageUsersController::updateStatus
 * @see app/Http/Controllers/AdminManageUsersController.php:312
 * @route '/admin/manage-users/{student}/status'
 */
        updateStatusForm.put = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\AdminManageUsersController::updateStatus
 * @see app/Http/Controllers/AdminManageUsersController.php:312
 * @route '/admin/manage-users/{student}/status'
 */
        updateStatusForm.post = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateStatus.url(args, options),
            method: 'post',
        })
    
    updateStatus.form = updateStatusForm
/**
* @see \App\Http\Controllers\AdminManageUsersController::updateApproval
 * @see app/Http/Controllers/AdminManageUsersController.php:339
 * @route '/admin/manage-users/{student}/status/approve'
 */
export const updateApproval = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateApproval.url(args, options),
    method: 'put',
})

updateApproval.definition = {
    methods: ["put","post"],
    url: '/admin/manage-users/{student}/status/approve',
} satisfies RouteDefinition<["put","post"]>

/**
* @see \App\Http\Controllers\AdminManageUsersController::updateApproval
 * @see app/Http/Controllers/AdminManageUsersController.php:339
 * @route '/admin/manage-users/{student}/status/approve'
 */
updateApproval.url = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { student: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    student: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student: typeof args.student === 'object'
                ? args.student.id
                : args.student,
                }

    return updateApproval.definition.url
            .replace('{student}', parsedArgs.student.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminManageUsersController::updateApproval
 * @see app/Http/Controllers/AdminManageUsersController.php:339
 * @route '/admin/manage-users/{student}/status/approve'
 */
updateApproval.put = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateApproval.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\AdminManageUsersController::updateApproval
 * @see app/Http/Controllers/AdminManageUsersController.php:339
 * @route '/admin/manage-users/{student}/status/approve'
 */
updateApproval.post = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateApproval.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminManageUsersController::updateApproval
 * @see app/Http/Controllers/AdminManageUsersController.php:339
 * @route '/admin/manage-users/{student}/status/approve'
 */
    const updateApprovalForm = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateApproval.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminManageUsersController::updateApproval
 * @see app/Http/Controllers/AdminManageUsersController.php:339
 * @route '/admin/manage-users/{student}/status/approve'
 */
        updateApprovalForm.put = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateApproval.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\AdminManageUsersController::updateApproval
 * @see app/Http/Controllers/AdminManageUsersController.php:339
 * @route '/admin/manage-users/{student}/status/approve'
 */
        updateApprovalForm.post = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateApproval.url(args, options),
            method: 'post',
        })
    
    updateApproval.form = updateApprovalForm
/**
* @see \App\Http\Controllers\AdminManageUsersController::archive
 * @see app/Http/Controllers/AdminManageUsersController.php:406
 * @route '/admin/manage-users/{student}/archive'
 */
export const archive = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: archive.url(args, options),
    method: 'put',
})

archive.definition = {
    methods: ["put","post"],
    url: '/admin/manage-users/{student}/archive',
} satisfies RouteDefinition<["put","post"]>

/**
* @see \App\Http\Controllers\AdminManageUsersController::archive
 * @see app/Http/Controllers/AdminManageUsersController.php:406
 * @route '/admin/manage-users/{student}/archive'
 */
archive.url = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { student: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    student: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student: typeof args.student === 'object'
                ? args.student.id
                : args.student,
                }

    return archive.definition.url
            .replace('{student}', parsedArgs.student.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminManageUsersController::archive
 * @see app/Http/Controllers/AdminManageUsersController.php:406
 * @route '/admin/manage-users/{student}/archive'
 */
archive.put = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: archive.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\AdminManageUsersController::archive
 * @see app/Http/Controllers/AdminManageUsersController.php:406
 * @route '/admin/manage-users/{student}/archive'
 */
archive.post = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: archive.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminManageUsersController::archive
 * @see app/Http/Controllers/AdminManageUsersController.php:406
 * @route '/admin/manage-users/{student}/archive'
 */
    const archiveForm = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: archive.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminManageUsersController::archive
 * @see app/Http/Controllers/AdminManageUsersController.php:406
 * @route '/admin/manage-users/{student}/archive'
 */
        archiveForm.put = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: archive.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\AdminManageUsersController::archive
 * @see app/Http/Controllers/AdminManageUsersController.php:406
 * @route '/admin/manage-users/{student}/archive'
 */
        archiveForm.post = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: archive.url(args, options),
            method: 'post',
        })
    
    archive.form = archiveForm
/**
* @see \App\Http\Controllers\AdminManageUsersController::approveProgramHead
 * @see app/Http/Controllers/AdminManageUsersController.php:526
 * @route '/admin/manage-users/program-heads/{programHead}/verification/approve'
 */
export const approveProgramHead = (args: { programHead: number | { id: number } } | [programHead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: approveProgramHead.url(args, options),
    method: 'put',
})

approveProgramHead.definition = {
    methods: ["put","post"],
    url: '/admin/manage-users/program-heads/{programHead}/verification/approve',
} satisfies RouteDefinition<["put","post"]>

/**
* @see \App\Http\Controllers\AdminManageUsersController::approveProgramHead
 * @see app/Http/Controllers/AdminManageUsersController.php:526
 * @route '/admin/manage-users/program-heads/{programHead}/verification/approve'
 */
approveProgramHead.url = (args: { programHead: number | { id: number } } | [programHead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { programHead: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { programHead: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    programHead: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        programHead: typeof args.programHead === 'object'
                ? args.programHead.id
                : args.programHead,
                }

    return approveProgramHead.definition.url
            .replace('{programHead}', parsedArgs.programHead.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminManageUsersController::approveProgramHead
 * @see app/Http/Controllers/AdminManageUsersController.php:526
 * @route '/admin/manage-users/program-heads/{programHead}/verification/approve'
 */
approveProgramHead.put = (args: { programHead: number | { id: number } } | [programHead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: approveProgramHead.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\AdminManageUsersController::approveProgramHead
 * @see app/Http/Controllers/AdminManageUsersController.php:526
 * @route '/admin/manage-users/program-heads/{programHead}/verification/approve'
 */
approveProgramHead.post = (args: { programHead: number | { id: number } } | [programHead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approveProgramHead.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminManageUsersController::approveProgramHead
 * @see app/Http/Controllers/AdminManageUsersController.php:526
 * @route '/admin/manage-users/program-heads/{programHead}/verification/approve'
 */
    const approveProgramHeadForm = (args: { programHead: number | { id: number } } | [programHead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approveProgramHead.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminManageUsersController::approveProgramHead
 * @see app/Http/Controllers/AdminManageUsersController.php:526
 * @route '/admin/manage-users/program-heads/{programHead}/verification/approve'
 */
        approveProgramHeadForm.put = (args: { programHead: number | { id: number } } | [programHead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approveProgramHead.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\AdminManageUsersController::approveProgramHead
 * @see app/Http/Controllers/AdminManageUsersController.php:526
 * @route '/admin/manage-users/program-heads/{programHead}/verification/approve'
 */
        approveProgramHeadForm.post = (args: { programHead: number | { id: number } } | [programHead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approveProgramHead.url(args, options),
            method: 'post',
        })
    
    approveProgramHead.form = approveProgramHeadForm
/**
* @see \App\Http\Controllers\AdminManageUsersController::rejectProgramHead
 * @see app/Http/Controllers/AdminManageUsersController.php:558
 * @route '/admin/manage-users/program-heads/{programHead}/verification/reject'
 */
export const rejectProgramHead = (args: { programHead: number | { id: number } } | [programHead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: rejectProgramHead.url(args, options),
    method: 'put',
})

rejectProgramHead.definition = {
    methods: ["put","post"],
    url: '/admin/manage-users/program-heads/{programHead}/verification/reject',
} satisfies RouteDefinition<["put","post"]>

/**
* @see \App\Http\Controllers\AdminManageUsersController::rejectProgramHead
 * @see app/Http/Controllers/AdminManageUsersController.php:558
 * @route '/admin/manage-users/program-heads/{programHead}/verification/reject'
 */
rejectProgramHead.url = (args: { programHead: number | { id: number } } | [programHead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { programHead: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { programHead: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    programHead: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        programHead: typeof args.programHead === 'object'
                ? args.programHead.id
                : args.programHead,
                }

    return rejectProgramHead.definition.url
            .replace('{programHead}', parsedArgs.programHead.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminManageUsersController::rejectProgramHead
 * @see app/Http/Controllers/AdminManageUsersController.php:558
 * @route '/admin/manage-users/program-heads/{programHead}/verification/reject'
 */
rejectProgramHead.put = (args: { programHead: number | { id: number } } | [programHead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: rejectProgramHead.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\AdminManageUsersController::rejectProgramHead
 * @see app/Http/Controllers/AdminManageUsersController.php:558
 * @route '/admin/manage-users/program-heads/{programHead}/verification/reject'
 */
rejectProgramHead.post = (args: { programHead: number | { id: number } } | [programHead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rejectProgramHead.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminManageUsersController::rejectProgramHead
 * @see app/Http/Controllers/AdminManageUsersController.php:558
 * @route '/admin/manage-users/program-heads/{programHead}/verification/reject'
 */
    const rejectProgramHeadForm = (args: { programHead: number | { id: number } } | [programHead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: rejectProgramHead.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminManageUsersController::rejectProgramHead
 * @see app/Http/Controllers/AdminManageUsersController.php:558
 * @route '/admin/manage-users/program-heads/{programHead}/verification/reject'
 */
        rejectProgramHeadForm.put = (args: { programHead: number | { id: number } } | [programHead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: rejectProgramHead.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\AdminManageUsersController::rejectProgramHead
 * @see app/Http/Controllers/AdminManageUsersController.php:558
 * @route '/admin/manage-users/program-heads/{programHead}/verification/reject'
 */
        rejectProgramHeadForm.post = (args: { programHead: number | { id: number } } | [programHead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: rejectProgramHead.url(args, options),
            method: 'post',
        })
    
    rejectProgramHead.form = rejectProgramHeadForm
/**
* @see \App\Http\Controllers\AdminManageUsersController::bulkApproveVerification
 * @see app/Http/Controllers/AdminManageUsersController.php:587
 * @route '/admin/manage-users/bulk/verification/approve'
 */
export const bulkApproveVerification = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkApproveVerification.url(options),
    method: 'post',
})

bulkApproveVerification.definition = {
    methods: ["post"],
    url: '/admin/manage-users/bulk/verification/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminManageUsersController::bulkApproveVerification
 * @see app/Http/Controllers/AdminManageUsersController.php:587
 * @route '/admin/manage-users/bulk/verification/approve'
 */
bulkApproveVerification.url = (options?: RouteQueryOptions) => {
    return bulkApproveVerification.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminManageUsersController::bulkApproveVerification
 * @see app/Http/Controllers/AdminManageUsersController.php:587
 * @route '/admin/manage-users/bulk/verification/approve'
 */
bulkApproveVerification.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkApproveVerification.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminManageUsersController::bulkApproveVerification
 * @see app/Http/Controllers/AdminManageUsersController.php:587
 * @route '/admin/manage-users/bulk/verification/approve'
 */
    const bulkApproveVerificationForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bulkApproveVerification.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminManageUsersController::bulkApproveVerification
 * @see app/Http/Controllers/AdminManageUsersController.php:587
 * @route '/admin/manage-users/bulk/verification/approve'
 */
        bulkApproveVerificationForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bulkApproveVerification.url(options),
            method: 'post',
        })
    
    bulkApproveVerification.form = bulkApproveVerificationForm
/**
* @see \App\Http\Controllers\AdminManageUsersController::bulkRejectVerification
 * @see app/Http/Controllers/AdminManageUsersController.php:592
 * @route '/admin/manage-users/bulk/verification/reject'
 */
export const bulkRejectVerification = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkRejectVerification.url(options),
    method: 'post',
})

bulkRejectVerification.definition = {
    methods: ["post"],
    url: '/admin/manage-users/bulk/verification/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminManageUsersController::bulkRejectVerification
 * @see app/Http/Controllers/AdminManageUsersController.php:592
 * @route '/admin/manage-users/bulk/verification/reject'
 */
bulkRejectVerification.url = (options?: RouteQueryOptions) => {
    return bulkRejectVerification.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminManageUsersController::bulkRejectVerification
 * @see app/Http/Controllers/AdminManageUsersController.php:592
 * @route '/admin/manage-users/bulk/verification/reject'
 */
bulkRejectVerification.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkRejectVerification.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminManageUsersController::bulkRejectVerification
 * @see app/Http/Controllers/AdminManageUsersController.php:592
 * @route '/admin/manage-users/bulk/verification/reject'
 */
    const bulkRejectVerificationForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bulkRejectVerification.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminManageUsersController::bulkRejectVerification
 * @see app/Http/Controllers/AdminManageUsersController.php:592
 * @route '/admin/manage-users/bulk/verification/reject'
 */
        bulkRejectVerificationForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bulkRejectVerification.url(options),
            method: 'post',
        })
    
    bulkRejectVerification.form = bulkRejectVerificationForm
/**
* @see \App\Http\Controllers\AdminManageUsersController::unarchive
 * @see app/Http/Controllers/AdminManageUsersController.php:433
 * @route '/admin/manage-users/{student}/unarchive'
 */
export const unarchive = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: unarchive.url(args, options),
    method: 'put',
})

unarchive.definition = {
    methods: ["put","post"],
    url: '/admin/manage-users/{student}/unarchive',
} satisfies RouteDefinition<["put","post"]>

/**
* @see \App\Http\Controllers\AdminManageUsersController::unarchive
 * @see app/Http/Controllers/AdminManageUsersController.php:433
 * @route '/admin/manage-users/{student}/unarchive'
 */
unarchive.url = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { student: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    student: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student: typeof args.student === 'object'
                ? args.student.id
                : args.student,
                }

    return unarchive.definition.url
            .replace('{student}', parsedArgs.student.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminManageUsersController::unarchive
 * @see app/Http/Controllers/AdminManageUsersController.php:433
 * @route '/admin/manage-users/{student}/unarchive'
 */
unarchive.put = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: unarchive.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\AdminManageUsersController::unarchive
 * @see app/Http/Controllers/AdminManageUsersController.php:433
 * @route '/admin/manage-users/{student}/unarchive'
 */
unarchive.post = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unarchive.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminManageUsersController::unarchive
 * @see app/Http/Controllers/AdminManageUsersController.php:433
 * @route '/admin/manage-users/{student}/unarchive'
 */
    const unarchiveForm = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unarchive.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminManageUsersController::unarchive
 * @see app/Http/Controllers/AdminManageUsersController.php:433
 * @route '/admin/manage-users/{student}/unarchive'
 */
        unarchiveForm.put = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unarchive.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\AdminManageUsersController::unarchive
 * @see app/Http/Controllers/AdminManageUsersController.php:433
 * @route '/admin/manage-users/{student}/unarchive'
 */
        unarchiveForm.post = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unarchive.url(args, options),
            method: 'post',
        })
    
    unarchive.form = unarchiveForm
/**
* @see \App\Http\Controllers\AdminManageUsersController::destroy
 * @see app/Http/Controllers/AdminManageUsersController.php:521
 * @route '/admin/manage-users/{student}'
 */
export const destroy = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/manage-users/{student}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AdminManageUsersController::destroy
 * @see app/Http/Controllers/AdminManageUsersController.php:521
 * @route '/admin/manage-users/{student}'
 */
destroy.url = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { student: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { student: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    student: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        student: typeof args.student === 'object'
                ? args.student.id
                : args.student,
                }

    return destroy.definition.url
            .replace('{student}', parsedArgs.student.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminManageUsersController::destroy
 * @see app/Http/Controllers/AdminManageUsersController.php:521
 * @route '/admin/manage-users/{student}'
 */
destroy.delete = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\AdminManageUsersController::destroy
 * @see app/Http/Controllers/AdminManageUsersController.php:521
 * @route '/admin/manage-users/{student}'
 */
    const destroyForm = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminManageUsersController::destroy
 * @see app/Http/Controllers/AdminManageUsersController.php:521
 * @route '/admin/manage-users/{student}'
 */
        destroyForm.delete = (args: { student: number | { id: number } } | [student: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\AdminManageUsersController::updateProgramHead
 * @see app/Http/Controllers/AdminManageUsersController.php:649
 * @route '/admin/program-heads/{programHead}'
 */
export const updateProgramHead = (args: { programHead: number | { id: number } } | [programHead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateProgramHead.url(args, options),
    method: 'put',
})

updateProgramHead.definition = {
    methods: ["put"],
    url: '/admin/program-heads/{programHead}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AdminManageUsersController::updateProgramHead
 * @see app/Http/Controllers/AdminManageUsersController.php:649
 * @route '/admin/program-heads/{programHead}'
 */
updateProgramHead.url = (args: { programHead: number | { id: number } } | [programHead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { programHead: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { programHead: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    programHead: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        programHead: typeof args.programHead === 'object'
                ? args.programHead.id
                : args.programHead,
                }

    return updateProgramHead.definition.url
            .replace('{programHead}', parsedArgs.programHead.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminManageUsersController::updateProgramHead
 * @see app/Http/Controllers/AdminManageUsersController.php:649
 * @route '/admin/program-heads/{programHead}'
 */
updateProgramHead.put = (args: { programHead: number | { id: number } } | [programHead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateProgramHead.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AdminManageUsersController::updateProgramHead
 * @see app/Http/Controllers/AdminManageUsersController.php:649
 * @route '/admin/program-heads/{programHead}'
 */
    const updateProgramHeadForm = (args: { programHead: number | { id: number } } | [programHead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateProgramHead.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminManageUsersController::updateProgramHead
 * @see app/Http/Controllers/AdminManageUsersController.php:649
 * @route '/admin/program-heads/{programHead}'
 */
        updateProgramHeadForm.put = (args: { programHead: number | { id: number } } | [programHead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateProgramHead.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateProgramHead.form = updateProgramHeadForm
const AdminManageUsersController = { index, store, updateLegacy, destroyLegacy, update, updateStatus, updateApproval, archive, approveProgramHead, rejectProgramHead, bulkApproveVerification, bulkRejectVerification, unarchive, destroy, updateProgramHead }

export default AdminManageUsersController