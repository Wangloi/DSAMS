import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::index
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:15
 * @route '/dsa/admission-slip'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/dsa/admission-slip',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::index
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:15
 * @route '/dsa/admission-slip'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::index
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:15
 * @route '/dsa/admission-slip'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::index
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:15
 * @route '/dsa/admission-slip'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DSAAdmissionSlipController::index
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:15
 * @route '/dsa/admission-slip'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DSAAdmissionSlipController::index
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:15
 * @route '/dsa/admission-slip'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DSAAdmissionSlipController::index
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:15
 * @route '/dsa/admission-slip'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::store
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:34
 * @route '/dsa/admission-slip'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/dsa/admission-slip',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::store
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:34
 * @route '/dsa/admission-slip'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::store
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:34
 * @route '/dsa/admission-slip'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DSAAdmissionSlipController::store
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:34
 * @route '/dsa/admission-slip'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DSAAdmissionSlipController::store
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:34
 * @route '/dsa/admission-slip'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::update
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:70
 * @route '/dsa/admission-slip/{admissionSlip}'
 */
export const update = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/dsa/admission-slip/{admissionSlip}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::update
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:70
 * @route '/dsa/admission-slip/{admissionSlip}'
 */
update.url = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { admissionSlip: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { admissionSlip: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    admissionSlip: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        admissionSlip: typeof args.admissionSlip === 'object'
                ? args.admissionSlip.id
                : args.admissionSlip,
                }

    return update.definition.url
            .replace('{admissionSlip}', parsedArgs.admissionSlip.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::update
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:70
 * @route '/dsa/admission-slip/{admissionSlip}'
 */
update.put = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\DSAAdmissionSlipController::update
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:70
 * @route '/dsa/admission-slip/{admissionSlip}'
 */
    const updateForm = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DSAAdmissionSlipController::update
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:70
 * @route '/dsa/admission-slip/{admissionSlip}'
 */
        updateForm.put = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::destroy
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:91
 * @route '/dsa/admission-slip/{admissionSlip}'
 */
export const destroy = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/dsa/admission-slip/{admissionSlip}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::destroy
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:91
 * @route '/dsa/admission-slip/{admissionSlip}'
 */
destroy.url = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { admissionSlip: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { admissionSlip: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    admissionSlip: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        admissionSlip: typeof args.admissionSlip === 'object'
                ? args.admissionSlip.id
                : args.admissionSlip,
                }

    return destroy.definition.url
            .replace('{admissionSlip}', parsedArgs.admissionSlip.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::destroy
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:91
 * @route '/dsa/admission-slip/{admissionSlip}'
 */
destroy.delete = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\DSAAdmissionSlipController::destroy
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:91
 * @route '/dsa/admission-slip/{admissionSlip}'
 */
    const destroyForm = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DSAAdmissionSlipController::destroy
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:91
 * @route '/dsa/admission-slip/{admissionSlip}'
 */
        destroyForm.delete = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::approve
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:106
 * @route '/dsa/admission-slip/{admissionSlip}/approve'
 */
export const approve = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: approve.url(args, options),
    method: 'put',
})

approve.definition = {
    methods: ["put"],
    url: '/dsa/admission-slip/{admissionSlip}/approve',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::approve
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:106
 * @route '/dsa/admission-slip/{admissionSlip}/approve'
 */
approve.url = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { admissionSlip: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { admissionSlip: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    admissionSlip: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        admissionSlip: typeof args.admissionSlip === 'object'
                ? args.admissionSlip.id
                : args.admissionSlip,
                }

    return approve.definition.url
            .replace('{admissionSlip}', parsedArgs.admissionSlip.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::approve
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:106
 * @route '/dsa/admission-slip/{admissionSlip}/approve'
 */
approve.put = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: approve.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\DSAAdmissionSlipController::approve
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:106
 * @route '/dsa/admission-slip/{admissionSlip}/approve'
 */
    const approveForm = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DSAAdmissionSlipController::approve
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:106
 * @route '/dsa/admission-slip/{admissionSlip}/approve'
 */
        approveForm.put = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::reject
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:137
 * @route '/dsa/admission-slip/{admissionSlip}/reject'
 */
export const reject = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: reject.url(args, options),
    method: 'put',
})

reject.definition = {
    methods: ["put"],
    url: '/dsa/admission-slip/{admissionSlip}/reject',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::reject
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:137
 * @route '/dsa/admission-slip/{admissionSlip}/reject'
 */
reject.url = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { admissionSlip: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { admissionSlip: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    admissionSlip: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        admissionSlip: typeof args.admissionSlip === 'object'
                ? args.admissionSlip.id
                : args.admissionSlip,
                }

    return reject.definition.url
            .replace('{admissionSlip}', parsedArgs.admissionSlip.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::reject
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:137
 * @route '/dsa/admission-slip/{admissionSlip}/reject'
 */
reject.put = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: reject.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\DSAAdmissionSlipController::reject
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:137
 * @route '/dsa/admission-slip/{admissionSlip}/reject'
 */
    const rejectForm = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DSAAdmissionSlipController::reject
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:137
 * @route '/dsa/admission-slip/{admissionSlip}/reject'
 */
        rejectForm.put = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    reject.form = rejectForm
/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::archive
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:167
 * @route '/dsa/admission-slip/{admissionSlip}/archive'
 */
export const archive = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: archive.url(args, options),
    method: 'put',
})

archive.definition = {
    methods: ["put"],
    url: '/dsa/admission-slip/{admissionSlip}/archive',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::archive
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:167
 * @route '/dsa/admission-slip/{admissionSlip}/archive'
 */
archive.url = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { admissionSlip: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { admissionSlip: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    admissionSlip: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        admissionSlip: typeof args.admissionSlip === 'object'
                ? args.admissionSlip.id
                : args.admissionSlip,
                }

    return archive.definition.url
            .replace('{admissionSlip}', parsedArgs.admissionSlip.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::archive
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:167
 * @route '/dsa/admission-slip/{admissionSlip}/archive'
 */
archive.put = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: archive.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\DSAAdmissionSlipController::archive
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:167
 * @route '/dsa/admission-slip/{admissionSlip}/archive'
 */
    const archiveForm = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: archive.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DSAAdmissionSlipController::archive
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:167
 * @route '/dsa/admission-slip/{admissionSlip}/archive'
 */
        archiveForm.put = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: archive.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    archive.form = archiveForm
/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::unarchive
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:196
 * @route '/dsa/admission-slip/{admissionSlip}/unarchive'
 */
export const unarchive = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: unarchive.url(args, options),
    method: 'put',
})

unarchive.definition = {
    methods: ["put"],
    url: '/dsa/admission-slip/{admissionSlip}/unarchive',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::unarchive
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:196
 * @route '/dsa/admission-slip/{admissionSlip}/unarchive'
 */
unarchive.url = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { admissionSlip: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { admissionSlip: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    admissionSlip: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        admissionSlip: typeof args.admissionSlip === 'object'
                ? args.admissionSlip.id
                : args.admissionSlip,
                }

    return unarchive.definition.url
            .replace('{admissionSlip}', parsedArgs.admissionSlip.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DSAAdmissionSlipController::unarchive
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:196
 * @route '/dsa/admission-slip/{admissionSlip}/unarchive'
 */
unarchive.put = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: unarchive.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\DSAAdmissionSlipController::unarchive
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:196
 * @route '/dsa/admission-slip/{admissionSlip}/unarchive'
 */
    const unarchiveForm = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unarchive.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DSAAdmissionSlipController::unarchive
 * @see app/Http/Controllers/DSAAdmissionSlipController.php:196
 * @route '/dsa/admission-slip/{admissionSlip}/unarchive'
 */
        unarchiveForm.put = (args: { admissionSlip: number | { id: number } } | [admissionSlip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unarchive.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    unarchive.form = unarchiveForm
const DSAAdmissionSlipController = { index, store, update, destroy, approve, reject, archive, unarchive }

export default DSAAdmissionSlipController