import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::index
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:14
 * @route '/program-head/attendance'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/program-head/attendance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::index
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:14
 * @route '/program-head/attendance'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::index
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:14
 * @route '/program-head/attendance'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::index
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:14
 * @route '/program-head/attendance'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::index
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:14
 * @route '/program-head/attendance'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::index
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:14
 * @route '/program-head/attendance'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::index
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:14
 * @route '/program-head/attendance'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::logs
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:166
 * @route '/program-head/attendance/{event}/logs'
 */
export const logs = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logs.url(args, options),
    method: 'get',
})

logs.definition = {
    methods: ["get","head"],
    url: '/program-head/attendance/{event}/logs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::logs
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:166
 * @route '/program-head/attendance/{event}/logs'
 */
logs.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return logs.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::logs
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:166
 * @route '/program-head/attendance/{event}/logs'
 */
logs.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logs.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::logs
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:166
 * @route '/program-head/attendance/{event}/logs'
 */
logs.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: logs.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::logs
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:166
 * @route '/program-head/attendance/{event}/logs'
 */
    const logsForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: logs.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::logs
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:166
 * @route '/program-head/attendance/{event}/logs'
 */
        logsForm.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: logs.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::logs
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:166
 * @route '/program-head/attendance/{event}/logs'
 */
        logsForm.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: logs.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    logs.form = logsForm
/**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::studentsByCourse
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:125
 * @route '/program-head/attendance/{event}/students'
 */
export const studentsByCourse = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: studentsByCourse.url(args, options),
    method: 'get',
})

studentsByCourse.definition = {
    methods: ["get","head"],
    url: '/program-head/attendance/{event}/students',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::studentsByCourse
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:125
 * @route '/program-head/attendance/{event}/students'
 */
studentsByCourse.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return studentsByCourse.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::studentsByCourse
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:125
 * @route '/program-head/attendance/{event}/students'
 */
studentsByCourse.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: studentsByCourse.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::studentsByCourse
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:125
 * @route '/program-head/attendance/{event}/students'
 */
studentsByCourse.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: studentsByCourse.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::studentsByCourse
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:125
 * @route '/program-head/attendance/{event}/students'
 */
    const studentsByCourseForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: studentsByCourse.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::studentsByCourse
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:125
 * @route '/program-head/attendance/{event}/students'
 */
        studentsByCourseForm.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: studentsByCourse.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::studentsByCourse
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:125
 * @route '/program-head/attendance/{event}/students'
 */
        studentsByCourseForm.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: studentsByCourse.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    studentsByCourse.form = studentsByCourseForm
/**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::printEvent
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:236
 * @route '/program-head/attendance/{event}/print'
 */
export const printEvent = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printEvent.url(args, options),
    method: 'get',
})

printEvent.definition = {
    methods: ["get","head"],
    url: '/program-head/attendance/{event}/print',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::printEvent
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:236
 * @route '/program-head/attendance/{event}/print'
 */
printEvent.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return printEvent.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::printEvent
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:236
 * @route '/program-head/attendance/{event}/print'
 */
printEvent.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printEvent.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::printEvent
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:236
 * @route '/program-head/attendance/{event}/print'
 */
printEvent.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: printEvent.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::printEvent
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:236
 * @route '/program-head/attendance/{event}/print'
 */
    const printEventForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: printEvent.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::printEvent
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:236
 * @route '/program-head/attendance/{event}/print'
 */
        printEventForm.get = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: printEvent.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProgramHeadAttendanceController::printEvent
 * @see app/Http/Controllers/ProgramHeadAttendanceController.php:236
 * @route '/program-head/attendance/{event}/print'
 */
        printEventForm.head = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: printEvent.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    printEvent.form = printEventForm
const ProgramHeadAttendanceController = { index, logs, studentsByCourse, printEvent }

export default ProgramHeadAttendanceController