import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\StudentEvaluationController::show
 * @see app/Http/Controllers/StudentEvaluationController.php:16
 * @route '/student/evaluation/{evaluation}'
 */
export const show = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/student/evaluation/{evaluation}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StudentEvaluationController::show
 * @see app/Http/Controllers/StudentEvaluationController.php:16
 * @route '/student/evaluation/{evaluation}'
 */
show.url = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { evaluation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { evaluation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    evaluation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        evaluation: typeof args.evaluation === 'object'
                ? args.evaluation.id
                : args.evaluation,
                }

    return show.definition.url
            .replace('{evaluation}', parsedArgs.evaluation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentEvaluationController::show
 * @see app/Http/Controllers/StudentEvaluationController.php:16
 * @route '/student/evaluation/{evaluation}'
 */
show.get = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StudentEvaluationController::show
 * @see app/Http/Controllers/StudentEvaluationController.php:16
 * @route '/student/evaluation/{evaluation}'
 */
show.head = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StudentEvaluationController::show
 * @see app/Http/Controllers/StudentEvaluationController.php:16
 * @route '/student/evaluation/{evaluation}'
 */
    const showForm = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StudentEvaluationController::show
 * @see app/Http/Controllers/StudentEvaluationController.php:16
 * @route '/student/evaluation/{evaluation}'
 */
        showForm.get = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StudentEvaluationController::show
 * @see app/Http/Controllers/StudentEvaluationController.php:16
 * @route '/student/evaluation/{evaluation}'
 */
        showForm.head = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\StudentEvaluationController::submit
 * @see app/Http/Controllers/StudentEvaluationController.php:48
 * @route '/student/evaluation/{evaluation}'
 */
export const submit = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

submit.definition = {
    methods: ["post"],
    url: '/student/evaluation/{evaluation}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StudentEvaluationController::submit
 * @see app/Http/Controllers/StudentEvaluationController.php:48
 * @route '/student/evaluation/{evaluation}'
 */
submit.url = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { evaluation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { evaluation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    evaluation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        evaluation: typeof args.evaluation === 'object'
                ? args.evaluation.id
                : args.evaluation,
                }

    return submit.definition.url
            .replace('{evaluation}', parsedArgs.evaluation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentEvaluationController::submit
 * @see app/Http/Controllers/StudentEvaluationController.php:48
 * @route '/student/evaluation/{evaluation}'
 */
submit.post = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StudentEvaluationController::submit
 * @see app/Http/Controllers/StudentEvaluationController.php:48
 * @route '/student/evaluation/{evaluation}'
 */
    const submitForm = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: submit.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StudentEvaluationController::submit
 * @see app/Http/Controllers/StudentEvaluationController.php:48
 * @route '/student/evaluation/{evaluation}'
 */
        submitForm.post = (args: { evaluation: number | { id: number } } | [evaluation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: submit.url(args, options),
            method: 'post',
        })
    
    submit.form = submitForm
const StudentEvaluationController = { show, submit }

export default StudentEvaluationController