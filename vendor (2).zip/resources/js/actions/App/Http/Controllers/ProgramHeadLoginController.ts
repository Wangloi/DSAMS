import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ProgramHeadLoginController::login
 * @see app/Http/Controllers/ProgramHeadLoginController.php:11
 * @route '/program-head-login'
 */
export const login = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

login.definition = {
    methods: ["post"],
    url: '/program-head-login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProgramHeadLoginController::login
 * @see app/Http/Controllers/ProgramHeadLoginController.php:11
 * @route '/program-head-login'
 */
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramHeadLoginController::login
 * @see app/Http/Controllers/ProgramHeadLoginController.php:11
 * @route '/program-head-login'
 */
login.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ProgramHeadLoginController::login
 * @see app/Http/Controllers/ProgramHeadLoginController.php:11
 * @route '/program-head-login'
 */
    const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: login.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProgramHeadLoginController::login
 * @see app/Http/Controllers/ProgramHeadLoginController.php:11
 * @route '/program-head-login'
 */
        loginForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: login.url(options),
            method: 'post',
        })
    
    login.form = loginForm
const ProgramHeadLoginController = { login }

export default ProgramHeadLoginController