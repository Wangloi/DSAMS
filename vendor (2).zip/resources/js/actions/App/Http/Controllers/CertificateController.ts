import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CertificateController::index
 * @see app/Http/Controllers/CertificateController.php:22
 * @route '/student/certificates'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/student/certificates',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CertificateController::index
 * @see app/Http/Controllers/CertificateController.php:22
 * @route '/student/certificates'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CertificateController::index
 * @see app/Http/Controllers/CertificateController.php:22
 * @route '/student/certificates'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CertificateController::index
 * @see app/Http/Controllers/CertificateController.php:22
 * @route '/student/certificates'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CertificateController::index
 * @see app/Http/Controllers/CertificateController.php:22
 * @route '/student/certificates'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CertificateController::index
 * @see app/Http/Controllers/CertificateController.php:22
 * @route '/student/certificates'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CertificateController::index
 * @see app/Http/Controllers/CertificateController.php:22
 * @route '/student/certificates'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CertificateController::getAvailableCertificates
 * @see app/Http/Controllers/CertificateController.php:190
 * @route '/student/certificates/available'
 */
export const getAvailableCertificates = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAvailableCertificates.url(options),
    method: 'get',
})

getAvailableCertificates.definition = {
    methods: ["get","head"],
    url: '/student/certificates/available',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CertificateController::getAvailableCertificates
 * @see app/Http/Controllers/CertificateController.php:190
 * @route '/student/certificates/available'
 */
getAvailableCertificates.url = (options?: RouteQueryOptions) => {
    return getAvailableCertificates.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CertificateController::getAvailableCertificates
 * @see app/Http/Controllers/CertificateController.php:190
 * @route '/student/certificates/available'
 */
getAvailableCertificates.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAvailableCertificates.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CertificateController::getAvailableCertificates
 * @see app/Http/Controllers/CertificateController.php:190
 * @route '/student/certificates/available'
 */
getAvailableCertificates.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getAvailableCertificates.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CertificateController::getAvailableCertificates
 * @see app/Http/Controllers/CertificateController.php:190
 * @route '/student/certificates/available'
 */
    const getAvailableCertificatesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getAvailableCertificates.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CertificateController::getAvailableCertificates
 * @see app/Http/Controllers/CertificateController.php:190
 * @route '/student/certificates/available'
 */
        getAvailableCertificatesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getAvailableCertificates.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CertificateController::getAvailableCertificates
 * @see app/Http/Controllers/CertificateController.php:190
 * @route '/student/certificates/available'
 */
        getAvailableCertificatesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getAvailableCertificates.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getAvailableCertificates.form = getAvailableCertificatesForm
/**
* @see \App\Http\Controllers\CertificateController::generateCertificate
 * @see app/Http/Controllers/CertificateController.php:53
 * @route '/student/certificates/generate/{event}'
 */
export const generateCertificate = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generateCertificate.url(args, options),
    method: 'post',
})

generateCertificate.definition = {
    methods: ["post"],
    url: '/student/certificates/generate/{event}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CertificateController::generateCertificate
 * @see app/Http/Controllers/CertificateController.php:53
 * @route '/student/certificates/generate/{event}'
 */
generateCertificate.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return generateCertificate.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CertificateController::generateCertificate
 * @see app/Http/Controllers/CertificateController.php:53
 * @route '/student/certificates/generate/{event}'
 */
generateCertificate.post = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generateCertificate.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CertificateController::generateCertificate
 * @see app/Http/Controllers/CertificateController.php:53
 * @route '/student/certificates/generate/{event}'
 */
    const generateCertificateForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generateCertificate.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CertificateController::generateCertificate
 * @see app/Http/Controllers/CertificateController.php:53
 * @route '/student/certificates/generate/{event}'
 */
        generateCertificateForm.post = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generateCertificate.url(args, options),
            method: 'post',
        })
    
    generateCertificate.form = generateCertificateForm
/**
* @see \App\Http\Controllers\CertificateController::downloadCertificate
 * @see app/Http/Controllers/CertificateController.php:127
 * @route '/student/certificates/{certificate}/download'
 */
export const downloadCertificate = (args: { certificate: number | { id: number } } | [certificate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadCertificate.url(args, options),
    method: 'get',
})

downloadCertificate.definition = {
    methods: ["get","head"],
    url: '/student/certificates/{certificate}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CertificateController::downloadCertificate
 * @see app/Http/Controllers/CertificateController.php:127
 * @route '/student/certificates/{certificate}/download'
 */
downloadCertificate.url = (args: { certificate: number | { id: number } } | [certificate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { certificate: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { certificate: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    certificate: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        certificate: typeof args.certificate === 'object'
                ? args.certificate.id
                : args.certificate,
                }

    return downloadCertificate.definition.url
            .replace('{certificate}', parsedArgs.certificate.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CertificateController::downloadCertificate
 * @see app/Http/Controllers/CertificateController.php:127
 * @route '/student/certificates/{certificate}/download'
 */
downloadCertificate.get = (args: { certificate: number | { id: number } } | [certificate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadCertificate.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CertificateController::downloadCertificate
 * @see app/Http/Controllers/CertificateController.php:127
 * @route '/student/certificates/{certificate}/download'
 */
downloadCertificate.head = (args: { certificate: number | { id: number } } | [certificate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadCertificate.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CertificateController::downloadCertificate
 * @see app/Http/Controllers/CertificateController.php:127
 * @route '/student/certificates/{certificate}/download'
 */
    const downloadCertificateForm = (args: { certificate: number | { id: number } } | [certificate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: downloadCertificate.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CertificateController::downloadCertificate
 * @see app/Http/Controllers/CertificateController.php:127
 * @route '/student/certificates/{certificate}/download'
 */
        downloadCertificateForm.get = (args: { certificate: number | { id: number } } | [certificate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadCertificate.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CertificateController::downloadCertificate
 * @see app/Http/Controllers/CertificateController.php:127
 * @route '/student/certificates/{certificate}/download'
 */
        downloadCertificateForm.head = (args: { certificate: number | { id: number } } | [certificate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadCertificate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    downloadCertificate.form = downloadCertificateForm
const CertificateController = { index, getAvailableCertificates, generateCertificate, downloadCertificate }

export default CertificateController