import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminAnalyticsController::index
 * @see app/Http/Controllers/AdminAnalyticsController.php:17
 * @route '/admin/analytics'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/analytics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminAnalyticsController::index
 * @see app/Http/Controllers/AdminAnalyticsController.php:17
 * @route '/admin/analytics'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminAnalyticsController::index
 * @see app/Http/Controllers/AdminAnalyticsController.php:17
 * @route '/admin/analytics'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminAnalyticsController::index
 * @see app/Http/Controllers/AdminAnalyticsController.php:17
 * @route '/admin/analytics'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminAnalyticsController::index
 * @see app/Http/Controllers/AdminAnalyticsController.php:17
 * @route '/admin/analytics'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminAnalyticsController::index
 * @see app/Http/Controllers/AdminAnalyticsController.php:17
 * @route '/admin/analytics'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminAnalyticsController::index
 * @see app/Http/Controllers/AdminAnalyticsController.php:17
 * @route '/admin/analytics'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AdminAnalyticsController::data
 * @see app/Http/Controllers/AdminAnalyticsController.php:40
 * @route '/admin/analytics/data'
 */
export const data = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: data.url(options),
    method: 'get',
})

data.definition = {
    methods: ["get","head"],
    url: '/admin/analytics/data',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminAnalyticsController::data
 * @see app/Http/Controllers/AdminAnalyticsController.php:40
 * @route '/admin/analytics/data'
 */
data.url = (options?: RouteQueryOptions) => {
    return data.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminAnalyticsController::data
 * @see app/Http/Controllers/AdminAnalyticsController.php:40
 * @route '/admin/analytics/data'
 */
data.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: data.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminAnalyticsController::data
 * @see app/Http/Controllers/AdminAnalyticsController.php:40
 * @route '/admin/analytics/data'
 */
data.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: data.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminAnalyticsController::data
 * @see app/Http/Controllers/AdminAnalyticsController.php:40
 * @route '/admin/analytics/data'
 */
    const dataForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: data.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminAnalyticsController::data
 * @see app/Http/Controllers/AdminAnalyticsController.php:40
 * @route '/admin/analytics/data'
 */
        dataForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: data.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminAnalyticsController::data
 * @see app/Http/Controllers/AdminAnalyticsController.php:40
 * @route '/admin/analytics/data'
 */
        dataForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: data.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    data.form = dataForm
const AdminAnalyticsController = { index, data }

export default AdminAnalyticsController