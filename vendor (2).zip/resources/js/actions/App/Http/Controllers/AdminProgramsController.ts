import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminProgramsController::index
 * @see app/Http/Controllers/AdminProgramsController.php:15
 * @route '/admin/programs'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/programs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminProgramsController::index
 * @see app/Http/Controllers/AdminProgramsController.php:15
 * @route '/admin/programs'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminProgramsController::index
 * @see app/Http/Controllers/AdminProgramsController.php:15
 * @route '/admin/programs'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminProgramsController::index
 * @see app/Http/Controllers/AdminProgramsController.php:15
 * @route '/admin/programs'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminProgramsController::index
 * @see app/Http/Controllers/AdminProgramsController.php:15
 * @route '/admin/programs'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminProgramsController::index
 * @see app/Http/Controllers/AdminProgramsController.php:15
 * @route '/admin/programs'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminProgramsController::index
 * @see app/Http/Controllers/AdminProgramsController.php:15
 * @route '/admin/programs'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AdminProgramsController::store
 * @see app/Http/Controllers/AdminProgramsController.php:45
 * @route '/admin/programs'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/programs',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminProgramsController::store
 * @see app/Http/Controllers/AdminProgramsController.php:45
 * @route '/admin/programs'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminProgramsController::store
 * @see app/Http/Controllers/AdminProgramsController.php:45
 * @route '/admin/programs'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminProgramsController::store
 * @see app/Http/Controllers/AdminProgramsController.php:45
 * @route '/admin/programs'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminProgramsController::store
 * @see app/Http/Controllers/AdminProgramsController.php:45
 * @route '/admin/programs'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AdminProgramsController::create
 * @see app/Http/Controllers/AdminProgramsController.php:40
 * @route '/admin/programs/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/programs/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminProgramsController::create
 * @see app/Http/Controllers/AdminProgramsController.php:40
 * @route '/admin/programs/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminProgramsController::create
 * @see app/Http/Controllers/AdminProgramsController.php:40
 * @route '/admin/programs/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminProgramsController::create
 * @see app/Http/Controllers/AdminProgramsController.php:40
 * @route '/admin/programs/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminProgramsController::create
 * @see app/Http/Controllers/AdminProgramsController.php:40
 * @route '/admin/programs/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminProgramsController::create
 * @see app/Http/Controllers/AdminProgramsController.php:40
 * @route '/admin/programs/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminProgramsController::create
 * @see app/Http/Controllers/AdminProgramsController.php:40
 * @route '/admin/programs/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\AdminProgramsController::show
 * @see app/Http/Controllers/AdminProgramsController.php:72
 * @route '/admin/programs/{program}'
 */
export const show = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/programs/{program}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminProgramsController::show
 * @see app/Http/Controllers/AdminProgramsController.php:72
 * @route '/admin/programs/{program}'
 */
show.url = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { program: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { program: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    program: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        program: typeof args.program === 'object'
                ? args.program.id
                : args.program,
                }

    return show.definition.url
            .replace('{program}', parsedArgs.program.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminProgramsController::show
 * @see app/Http/Controllers/AdminProgramsController.php:72
 * @route '/admin/programs/{program}'
 */
show.get = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminProgramsController::show
 * @see app/Http/Controllers/AdminProgramsController.php:72
 * @route '/admin/programs/{program}'
 */
show.head = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminProgramsController::show
 * @see app/Http/Controllers/AdminProgramsController.php:72
 * @route '/admin/programs/{program}'
 */
    const showForm = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminProgramsController::show
 * @see app/Http/Controllers/AdminProgramsController.php:72
 * @route '/admin/programs/{program}'
 */
        showForm.get = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminProgramsController::show
 * @see app/Http/Controllers/AdminProgramsController.php:72
 * @route '/admin/programs/{program}'
 */
        showForm.head = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\AdminProgramsController::edit
 * @see app/Http/Controllers/AdminProgramsController.php:116
 * @route '/admin/programs/{program}/edit'
 */
export const edit = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/programs/{program}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminProgramsController::edit
 * @see app/Http/Controllers/AdminProgramsController.php:116
 * @route '/admin/programs/{program}/edit'
 */
edit.url = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { program: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { program: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    program: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        program: typeof args.program === 'object'
                ? args.program.id
                : args.program,
                }

    return edit.definition.url
            .replace('{program}', parsedArgs.program.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminProgramsController::edit
 * @see app/Http/Controllers/AdminProgramsController.php:116
 * @route '/admin/programs/{program}/edit'
 */
edit.get = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminProgramsController::edit
 * @see app/Http/Controllers/AdminProgramsController.php:116
 * @route '/admin/programs/{program}/edit'
 */
edit.head = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminProgramsController::edit
 * @see app/Http/Controllers/AdminProgramsController.php:116
 * @route '/admin/programs/{program}/edit'
 */
    const editForm = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminProgramsController::edit
 * @see app/Http/Controllers/AdminProgramsController.php:116
 * @route '/admin/programs/{program}/edit'
 */
        editForm.get = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminProgramsController::edit
 * @see app/Http/Controllers/AdminProgramsController.php:116
 * @route '/admin/programs/{program}/edit'
 */
        editForm.head = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\AdminProgramsController::update
 * @see app/Http/Controllers/AdminProgramsController.php:131
 * @route '/admin/programs/{program}'
 */
export const update = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/programs/{program}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AdminProgramsController::update
 * @see app/Http/Controllers/AdminProgramsController.php:131
 * @route '/admin/programs/{program}'
 */
update.url = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { program: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { program: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    program: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        program: typeof args.program === 'object'
                ? args.program.id
                : args.program,
                }

    return update.definition.url
            .replace('{program}', parsedArgs.program.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminProgramsController::update
 * @see app/Http/Controllers/AdminProgramsController.php:131
 * @route '/admin/programs/{program}'
 */
update.put = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AdminProgramsController::update
 * @see app/Http/Controllers/AdminProgramsController.php:131
 * @route '/admin/programs/{program}'
 */
    const updateForm = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminProgramsController::update
 * @see app/Http/Controllers/AdminProgramsController.php:131
 * @route '/admin/programs/{program}'
 */
        updateForm.put = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\AdminProgramsController::destroy
 * @see app/Http/Controllers/AdminProgramsController.php:159
 * @route '/admin/programs/{program}'
 */
export const destroy = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/programs/{program}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AdminProgramsController::destroy
 * @see app/Http/Controllers/AdminProgramsController.php:159
 * @route '/admin/programs/{program}'
 */
destroy.url = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { program: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { program: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    program: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        program: typeof args.program === 'object'
                ? args.program.id
                : args.program,
                }

    return destroy.definition.url
            .replace('{program}', parsedArgs.program.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminProgramsController::destroy
 * @see app/Http/Controllers/AdminProgramsController.php:159
 * @route '/admin/programs/{program}'
 */
destroy.delete = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\AdminProgramsController::destroy
 * @see app/Http/Controllers/AdminProgramsController.php:159
 * @route '/admin/programs/{program}'
 */
    const destroyForm = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminProgramsController::destroy
 * @see app/Http/Controllers/AdminProgramsController.php:159
 * @route '/admin/programs/{program}'
 */
        destroyForm.delete = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\AdminProgramsController::archive
 * @see app/Http/Controllers/AdminProgramsController.php:185
 * @route '/admin/programs/{program}/archive'
 */
export const archive = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: archive.url(args, options),
    method: 'put',
})

archive.definition = {
    methods: ["put"],
    url: '/admin/programs/{program}/archive',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AdminProgramsController::archive
 * @see app/Http/Controllers/AdminProgramsController.php:185
 * @route '/admin/programs/{program}/archive'
 */
archive.url = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { program: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { program: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    program: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        program: typeof args.program === 'object'
                ? args.program.id
                : args.program,
                }

    return archive.definition.url
            .replace('{program}', parsedArgs.program.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminProgramsController::archive
 * @see app/Http/Controllers/AdminProgramsController.php:185
 * @route '/admin/programs/{program}/archive'
 */
archive.put = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: archive.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AdminProgramsController::archive
 * @see app/Http/Controllers/AdminProgramsController.php:185
 * @route '/admin/programs/{program}/archive'
 */
    const archiveForm = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: archive.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminProgramsController::archive
 * @see app/Http/Controllers/AdminProgramsController.php:185
 * @route '/admin/programs/{program}/archive'
 */
        archiveForm.put = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: archive.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    archive.form = archiveForm
/**
* @see \App\Http\Controllers\AdminProgramsController::unarchive
 * @see app/Http/Controllers/AdminProgramsController.php:203
 * @route '/admin/programs/{program}/unarchive'
 */
export const unarchive = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: unarchive.url(args, options),
    method: 'put',
})

unarchive.definition = {
    methods: ["put"],
    url: '/admin/programs/{program}/unarchive',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AdminProgramsController::unarchive
 * @see app/Http/Controllers/AdminProgramsController.php:203
 * @route '/admin/programs/{program}/unarchive'
 */
unarchive.url = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { program: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { program: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    program: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        program: typeof args.program === 'object'
                ? args.program.id
                : args.program,
                }

    return unarchive.definition.url
            .replace('{program}', parsedArgs.program.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminProgramsController::unarchive
 * @see app/Http/Controllers/AdminProgramsController.php:203
 * @route '/admin/programs/{program}/unarchive'
 */
unarchive.put = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: unarchive.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AdminProgramsController::unarchive
 * @see app/Http/Controllers/AdminProgramsController.php:203
 * @route '/admin/programs/{program}/unarchive'
 */
    const unarchiveForm = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unarchive.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminProgramsController::unarchive
 * @see app/Http/Controllers/AdminProgramsController.php:203
 * @route '/admin/programs/{program}/unarchive'
 */
        unarchiveForm.put = (args: { program: number | { id: number } } | [program: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unarchive.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    unarchive.form = unarchiveForm
const AdminProgramsController = { index, store, create, show, edit, update, destroy, archive, unarchive }

export default AdminProgramsController