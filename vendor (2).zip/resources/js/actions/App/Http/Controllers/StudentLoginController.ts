import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\StudentLoginController::login
 * @see app/Http/Controllers/StudentLoginController.php:12
 * @route '/student-login'
 */
export const login = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

login.definition = {
    methods: ["post"],
    url: '/student-login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StudentLoginController::login
 * @see app/Http/Controllers/StudentLoginController.php:12
 * @route '/student-login'
 */
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentLoginController::login
 * @see app/Http/Controllers/StudentLoginController.php:12
 * @route '/student-login'
 */
login.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StudentLoginController::login
 * @see app/Http/Controllers/StudentLoginController.php:12
 * @route '/student-login'
 */
    const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: login.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StudentLoginController::login
 * @see app/Http/Controllers/StudentLoginController.php:12
 * @route '/student-login'
 */
        loginForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: login.url(options),
            method: 'post',
        })
    
    login.form = loginForm
/**
* @see \App\Http\Controllers\StudentLoginController::logout
 * @see app/Http/Controllers/StudentLoginController.php:31
 * @route '/student-logout'
 */
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/student-logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StudentLoginController::logout
 * @see app/Http/Controllers/StudentLoginController.php:31
 * @route '/student-logout'
 */
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentLoginController::logout
 * @see app/Http/Controllers/StudentLoginController.php:31
 * @route '/student-logout'
 */
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StudentLoginController::logout
 * @see app/Http/Controllers/StudentLoginController.php:31
 * @route '/student-logout'
 */
    const logoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: logout.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StudentLoginController::logout
 * @see app/Http/Controllers/StudentLoginController.php:31
 * @route '/student-logout'
 */
        logoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: logout.url(options),
            method: 'post',
        })
    
    logout.form = logoutForm
const StudentLoginController = { login, logout }

export default StudentLoginController