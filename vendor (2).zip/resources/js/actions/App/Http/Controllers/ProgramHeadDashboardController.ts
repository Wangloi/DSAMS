import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ProgramHeadDashboardController::index
 * @see app/Http/Controllers/ProgramHeadDashboardController.php:17
 * @route '/program-head-dashboard'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/program-head-dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProgramHeadDashboardController::index
 * @see app/Http/Controllers/ProgramHeadDashboardController.php:17
 * @route '/program-head-dashboard'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramHeadDashboardController::index
 * @see app/Http/Controllers/ProgramHeadDashboardController.php:17
 * @route '/program-head-dashboard'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProgramHeadDashboardController::index
 * @see app/Http/Controllers/ProgramHeadDashboardController.php:17
 * @route '/program-head-dashboard'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProgramHeadDashboardController::index
 * @see app/Http/Controllers/ProgramHeadDashboardController.php:17
 * @route '/program-head-dashboard'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProgramHeadDashboardController::index
 * @see app/Http/Controllers/ProgramHeadDashboardController.php:17
 * @route '/program-head-dashboard'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProgramHeadDashboardController::index
 * @see app/Http/Controllers/ProgramHeadDashboardController.php:17
 * @route '/program-head-dashboard'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ProgramHeadDashboardController::students
 * @see app/Http/Controllers/ProgramHeadDashboardController.php:55
 * @route '/program-head/students'
 */
export const students = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: students.url(options),
    method: 'get',
})

students.definition = {
    methods: ["get","head"],
    url: '/program-head/students',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProgramHeadDashboardController::students
 * @see app/Http/Controllers/ProgramHeadDashboardController.php:55
 * @route '/program-head/students'
 */
students.url = (options?: RouteQueryOptions) => {
    return students.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramHeadDashboardController::students
 * @see app/Http/Controllers/ProgramHeadDashboardController.php:55
 * @route '/program-head/students'
 */
students.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: students.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProgramHeadDashboardController::students
 * @see app/Http/Controllers/ProgramHeadDashboardController.php:55
 * @route '/program-head/students'
 */
students.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: students.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProgramHeadDashboardController::students
 * @see app/Http/Controllers/ProgramHeadDashboardController.php:55
 * @route '/program-head/students'
 */
    const studentsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: students.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProgramHeadDashboardController::students
 * @see app/Http/Controllers/ProgramHeadDashboardController.php:55
 * @route '/program-head/students'
 */
        studentsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: students.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProgramHeadDashboardController::students
 * @see app/Http/Controllers/ProgramHeadDashboardController.php:55
 * @route '/program-head/students'
 */
        studentsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: students.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    students.form = studentsForm
const ProgramHeadDashboardController = { index, students }

export default ProgramHeadDashboardController