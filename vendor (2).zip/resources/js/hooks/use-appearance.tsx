import { useCallback, useMemo, useSyncExternalStore } from 'react';

export type ResolvedAppearance = 'light' | 'dark';
export type Appearance = 'light' | 'dark' | 'system';

export type UseAppearanceReturn = {
    readonly appearance: Appearance;
    readonly resolvedAppearance: ResolvedAppearance;
    readonly updateAppearance: (mode: Appearance) => void;
};

const listeners = new Set<() => void>();
let currentAppearance: Appearance = 'light';

const setCookie = (name: string, value: string, days = 365): void => {
    if (typeof document === 'undefined') return;
    const maxAge = days * 24 * 60 * 60;
    document.cookie = `${name}=${value};path=/;max-age=${maxAge};SameSite=Lax`;
};

export const LANDING_COMPONENTS = new Set([
    'landing-page',
    'landing/about',
    'landing/features',
    'landing/get-started',
    'help',
    'privacy',
    'terms',
    'sitemap',
    'welcome',
]);

export function isLandingPage(componentName?: string): boolean {
    if (componentName) {
        return LANDING_COMPONENTS.has(componentName);
    }
    if (typeof window !== 'undefined') {
        const path = window.location.pathname;
        if (
            path === '/' ||
            path === '/about' ||
            path === '/features' ||
            path === '/get-started' ||
            path === '/help' ||
            path === '/privacy' ||
            path === '/privacy-policy' ||
            path === '/terms' ||
            path === '/terms-of-service' ||
            path === '/sitemap'
        ) {
            return true;
        }
    }
    return false;
}

export const getStoredAppearance = (): Appearance => {
    if (typeof window === 'undefined') return 'light';

    const stored = localStorage.getItem('appearance');
    return stored === 'dark' ? 'dark' : 'light';
};

const isDarkMode = (appearance: Appearance): boolean => {
    return appearance === 'dark';
};

export const applyTheme = (appearance: Appearance, componentName?: string): void => {
    if (typeof document === 'undefined') return;

    if (isLandingPage(componentName)) {
        document.documentElement.classList.remove('dark');
        document.documentElement.style.colorScheme = 'light';
        document.documentElement.setAttribute('data-appearance', 'light');
        document.documentElement.setAttribute('data-theme', 'light');
        return;
    }

    const isDark = isDarkMode(appearance);

    if (isDark) {
        document.documentElement.classList.add('dark');
        document.documentElement.style.colorScheme = 'dark';
    } else {
        document.documentElement.classList.remove('dark');
        document.documentElement.style.colorScheme = 'light';
    }

    document.documentElement.setAttribute('data-appearance', appearance === 'dark' ? 'dark' : 'light');
    document.documentElement.setAttribute(
        'data-theme',
        isDark ? 'dark' : 'light',
    );
};

const subscribe = (callback: () => void) => {
    listeners.add(callback);

    return () => listeners.delete(callback);
};

const notify = (): void => listeners.forEach((listener) => listener());

export function initializeTheme(): void {
    if (typeof window === 'undefined') return;

    const stored = localStorage.getItem('appearance');
    if (stored !== 'light' && stored !== 'dark') {
        localStorage.setItem('appearance', 'light');
        setCookie('appearance', 'light');
    }

    currentAppearance = getStoredAppearance();
    applyTheme(currentAppearance);
}

export function useAppearance(): UseAppearanceReturn {
    const appearance: Appearance = useSyncExternalStore(
        subscribe,
        () => currentAppearance,
        () => 'light',
    );

    const resolvedAppearance: ResolvedAppearance = useMemo(
        () => (isDarkMode(appearance) ? 'dark' : 'light'),
        [appearance],
    );

    const updateAppearance = useCallback((mode: Appearance): void => {
        const normalizedMode = mode === 'dark' ? 'dark' : 'light';
        currentAppearance = normalizedMode;

        // Store in localStorage for client-side persistence...
        localStorage.setItem('appearance', normalizedMode);

        // Store in cookie for SSR...
        setCookie('appearance', normalizedMode);

        applyTheme(normalizedMode);
        notify();
    }, []);

    return { appearance, resolvedAppearance, updateAppearance } as const;
}
