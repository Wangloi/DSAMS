import { Button } from '@/components/ui/button';
import { formatDate } from '@/lib/utils';
import { CalendarDays, ClipboardList, PlusCircle, RefreshCw } from 'lucide-react';

type Props = {
    onCreateNew: () => void;
    isRefreshing?: boolean;
    lastUpdated?: Date;
    isAutoRefreshEnabled?: boolean;
    onToggleAutoRefresh?: () => void;
};

export default function AdmissionSlipHeader({
    onCreateNew,
    isRefreshing,
    lastUpdated,
    isAutoRefreshEnabled,
    onToggleAutoRefresh,
}: Props) {
    return (
        <div className="relative mb-6 overflow-hidden rounded-2xl bg-gradient-to-br from-[#0b1c5c] via-[#1e3a8a] to-[#0B4DFF] p-6 shadow-xl shadow-blue-900/20">
            <div className="pointer-events-none absolute -top-12 -right-12 h-56 w-56 rounded-full bg-white/5" />
            <div className="pointer-events-none absolute -top-4 -right-4 h-32 w-32 rounded-full bg-white/5" />
            <div className="pointer-events-none absolute bottom-0 left-1/3 h-48 w-48 -translate-y-1/4 rounded-full bg-blue-400/10 blur-2xl" />
            <div className="relative flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-center gap-4">
                    <div className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-white/10 text-white shadow-inner ring-1 ring-white/20 backdrop-blur-sm">
                        <ClipboardList className="h-7 w-7" />
                    </div>
                    <div>
                        <h1 className="text-2xl font-black tracking-tight text-white">
                            Admission Slips
                        </h1>
                        <p className="mt-0.5 text-sm font-medium text-blue-200/80">
                            Manage and track student admission slip records,
                            pass authorizations, and history
                        </p>
                    </div>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                    {onToggleAutoRefresh && (
                        <button
                            type="button"
                            onClick={onToggleAutoRefresh}
                            className={`flex items-center gap-2 rounded-xl border px-3.5 py-2.5 text-xs font-semibold backdrop-blur-md transition-all ${
                                isAutoRefreshEnabled
                                    ? 'border-emerald-400/30 bg-emerald-500/20 text-emerald-100 hover:bg-emerald-500/30'
                                    : 'border-white/10 bg-white/10 text-white/70 hover:bg-white/20'
                            }`}
                            title={
                                isAutoRefreshEnabled
                                    ? 'Auto-refresh active (every 5s)'
                                    : 'Auto-refresh paused'
                            }
                        >
                            <RefreshCw
                                className={`h-3.5 w-3.5 ${
                                    isRefreshing ? 'animate-spin text-white' : ''
                                }`}
                            />
                            <span>
                                {isAutoRefreshEnabled ? 'Live Sync' : 'Sync Paused'}
                            </span>
                        </button>
                    )}

                    <div className="hidden items-center gap-3 rounded-xl border border-white/10 bg-white/10 px-4 py-2.5 text-white ring-1 ring-white/20 backdrop-blur-md md:flex">
                        <CalendarDays className="h-4 w-4 text-blue-200" />
                        <div className="text-xs font-semibold tracking-wide text-white/90 uppercase">
                            {formatDate(lastUpdated || new Date())}
                        </div>
                    </div>

                    <Button
                        type="button"
                        className="h-11 gap-2 self-start rounded-xl bg-white px-5 font-bold text-[#1e3a8a] shadow-md transition-all duration-200 hover:bg-blue-50 hover:shadow-lg sm:self-auto"
                        onClick={onCreateNew}
                    >
                        <PlusCircle className="h-5 w-5" />
                        Walk-in Slip
                    </Button>
                </div>
            </div>
        </div>
    );
}
