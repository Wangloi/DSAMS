import type { InertiaLinkProps } from '@inertiajs/react';
import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
    return twMerge(clsx(inputs));
}

export function toUrl(url: NonNullable<InertiaLinkProps['href']>): string {
    return typeof url === 'string' ? url : url.url;
}

export function formatTimeAgo(dateStr?: string | null, fallback?: string): string {
    if (!dateStr) return fallback || '';
    try {
        const date = new Date(dateStr);
        if (isNaN(date.getTime())) return fallback || '';
        const now = new Date();
        const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);

        if (diffInSeconds < 0 || diffInSeconds < 60) return 'Just now';
        if (diffInSeconds < 3600) {
            const mins = Math.floor(diffInSeconds / 60);
            return `${mins} ${mins === 1 ? 'minute' : 'minutes'} ago`;
        }
        if (diffInSeconds < 86400) {
            const hours = Math.floor(diffInSeconds / 3600);
            return `${hours} ${hours === 1 ? 'hour' : 'hours'} ago`;
        }
        if (diffInSeconds < 604800) {
            const days = Math.floor(diffInSeconds / 86400);
            return `${days} ${days === 1 ? 'day' : 'days'} ago`;
        }

        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    } catch {
        return fallback || 'Recently';
    }
}

export function formatTimeTo12Hour(raw?: string | null, fallback: string = '—'): string {
    const value = String(raw ?? '').trim();
    if (!value || value === '—') return fallback;

    // If already in 12-hour AM/PM format
    if (/(am|pm)$/i.test(value)) return value;

    // Match "HH:mm" or "HH:mm:ss"
    const timeMatch = value.match(/^(\d{1,2}):(\d{2})(?::\d{2})?$/);
    if (timeMatch) {
        const hh = Number.parseInt(timeMatch[1], 10);
        const mm = timeMatch[2];
        if (Number.isFinite(hh) && hh >= 0 && hh <= 23) {
            const suffix = hh >= 12 ? 'PM' : 'AM';
            const hour12 = ((hh + 11) % 12) + 1;
            return `${hour12}:${mm} ${suffix}`;
        }
    }

    // Match ISO or timestamp string with date and time
    if (value.includes('T') || value.includes('-') || value.includes(' ')) {
        try {
            const d = new Date(value);
            if (!isNaN(d.getTime())) {
                return d.toLocaleTimeString('en-US', {
                    hour: 'numeric',
                    minute: '2-digit',
                    hour12: true,
                });
            }
        } catch {}
    }

    return value;
}

export function formatDate(raw?: string | Date | number | null, fallback: string = '—'): string {
    if (!raw) return fallback;
    try {
        const date = typeof raw === 'object' && raw instanceof Date ? raw : new Date(raw);
        if (isNaN(date.getTime())) return fallback;
        return date.toLocaleDateString('en-US', {
            month: 'long',
            day: 'numeric',
            year: 'numeric',
        });
    } catch {
        return fallback;
    }
}

export function formatTime(raw?: string | Date | number | null, fallback: string = '—'): string {
    if (!raw) return fallback;
    if (typeof raw === 'string') {
        return formatTimeTo12Hour(raw, fallback);
    }
    try {
        const date = typeof raw === 'object' && raw instanceof Date ? raw : new Date(raw);
        if (isNaN(date.getTime())) return fallback;
        return date.toLocaleTimeString('en-US', {
            hour: 'numeric',
            minute: '2-digit',
            hour12: true,
        });
    } catch {
        return fallback;
    }
}

export function formatDateTime(raw?: string | Date | number | null, fallback: string = '—'): string {
    if (!raw) return fallback;
    try {
        const date = typeof raw === 'object' && raw instanceof Date ? raw : new Date(raw);
        if (isNaN(date.getTime())) return fallback;
        const formattedDate = date.toLocaleDateString('en-US', {
            month: 'long',
            day: 'numeric',
            year: 'numeric',
        });
        const formattedTime = date.toLocaleTimeString('en-US', {
            hour: 'numeric',
            minute: '2-digit',
            hour12: true,
        });
        return `${formattedDate}, ${formattedTime}`;
    } catch {
        return fallback;
    }
}

export function formatLastNameFirst(
    input?:
        | string
        | {
              name?: string | null;
              student_name?: string | null;
              first_name?: string | null;
              last_name?: string | null;
              middle_name?: string | null;
              student?: {
                  name?: string | null;
                  first_name?: string | null;
                  last_name?: string | null;
                  middle_name?: string | null;
              } | null;
          }
        | null,
    fallback: string = '—'
): string {
    if (!input) return fallback;

    if (typeof input === 'string') {
        const trimmed = input.trim();
        if (!trimmed) return fallback;
        if (trimmed.includes(',')) return trimmed;
        const parts = trimmed.split(/\s+/);
        if (parts.length <= 1) return trimmed;
        const lastName = parts.pop();
        const firstNames = parts.join(' ');
        return `${lastName}, ${firstNames}`;
    }

    if (typeof input === 'object') {
        const lastName = input.last_name || input.student?.last_name;
        const firstName = input.first_name || input.student?.first_name;
        const middleName = input.middle_name || input.student?.middle_name;

        if (lastName && firstName) {
            const middle = middleName ? ` ${middleName}` : '';
            return `${lastName}, ${firstName}${middle}`.trim();
        }

        const rawName =
            input.student_name ||
            input.name ||
            input.student?.name ||
            '';

        if (rawName) {
            const trimmed = String(rawName).trim();
            if (trimmed.includes(',')) return trimmed;
            const parts = trimmed.split(/\s+/);
            if (parts.length <= 1) return trimmed;
            const last = parts.pop();
            const firsts = parts.join(' ');
            return `${last}, ${firsts}`;
        }
    }

    return fallback;
}

export interface AcademicYearInfo {
    currentAY: string;
    semester: string;
    todayFormatted: string;
    options: Array<{ value: string; label: string; isCurrent: boolean }>;
}

/**
 * Calculates real-time academic session information based on the current system date.
 * Following the Philippine higher education and DSAMS calendar:
 * - Months 1-6 (Jan-Jun): 2nd Semester of AY (currentYear - 1) - currentYear
 * - Months 7-12 (Jul-Dec): 1st Semester of AY currentYear - (currentYear + 1)
 */
export function getRealAcademicYearInfo(): AcademicYearInfo {
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth() + 1; // 1 to 12

    const startYear = currentMonth <= 6 ? currentYear - 1 : currentYear;
    const currentAY = `${startYear} - ${startYear + 1}`;
    const semester = currentMonth <= 6 ? '2nd Semester' : '1st Semester';

    const options: Array<{ value: string; label: string; isCurrent: boolean }> = [];
    for (let i = 0; i < 4; i++) {
        const sy = startYear - i;
        const val = `${sy} - ${sy + 1}`;
        options.push({
            value: val,
            label: `AY ${val}${i === 0 ? ' (Current)' : ''}`,
            isCurrent: i === 0,
        });
    }

    const todayFormatted = now.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
    });

    return {
        currentAY,
        semester,
        todayFormatted,
        options,
    };
}

