<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\PasswordResetRequest;
use App\Models\Program;
use App\Models\AdminUser;
use App\Models\ProgramHead;
use App\Models\Student;
use Carbon\Carbon;
use Illuminate\Support\Arr;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Inertia\Inertia;
use Inertia\Response;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Writer\Csv;
use PhpOffice\PhpSpreadsheet\IOFactory;

class AdminManageUsersController extends Controller
{
    public function index(): Response
    {
        $columns = [
            'id',
            'student_id',
            'first_name',
            'middle_name',
            'last_name',
            'name',
            'email',
            'course',
            'year_level',
            'role',
            'officer_features',
            'is_active',
            'status',
            'verification_status',
            'qr_code_path',
            'entry_status',
            'program',
            'major',
            'home_address',
            'birthday',
            'place_of_birth',
            'religion',
            'gender',
            'contact_no',
            'nationality',
            'elementary_school',
            'elementary_year_graduated',
            'junior_high_school',
            'junior_high_year_graduated',
            'senior_high_school',
            'senior_high_year_graduated',
            'mother_name',
            'mother_contact',
            'father_name',
            'father_contact',
            'guardian_name',
            'guardian_relation',
            'guardian_contact',
            'is_archived',
            'created_at',
            'updated_at',
        ];

        $columns = array_values(array_filter($columns, fn ($col) => Schema::hasColumn('students', $col)));

        $query = Student::query()->orderBy('last_name', 'asc')->orderBy('first_name', 'asc');

        if (Schema::hasColumn('students', 'is_archived')) {
            $query->where(function ($q) {
                $q->where('is_archived', false)->orWhereNull('is_archived');
            });
        }

        $students = $query
            ->get($columns)
            ->map(function ($student) {
                /** @var Student $student */
                $row = $student->toArray();
                $row['userType'] = 'student';
                if (Schema::hasColumn('students', 'verification_status')) {
                    $row['status'] = $student->verification_status ?? $row['status'] ?? 'approved';
                }
                return $row;
            });

        $users = $this->getAdminUsers()
            ->concat($this->getProgramHeads())
            ->concat($students)
            ->values();

        $passwordResetRequests = PasswordResetRequest::orderByDesc('id')->get();

        return Inertia::render('admin-dashboard/manage-users/index', [
            'students' => $users,
            'programs' => $this->getPrograms(),
            'passwordResetRequests' => $passwordResetRequests,
        ]);
    }

    public function show(string $type, int $id): Response
    {
        if ($type === 'program-head') {
            $row = $this->getProgramHeads()->firstWhere('program_head_id', $id);
            abort_if(! $row, 404);
        } else {
            $student = Student::findOrFail($id);
            $row = $student->toArray();
            $row['userType'] = 'student';
            if (Schema::hasColumn('students', 'verification_status')) {
                $row['status'] = $student->verification_status ?? $row['status'] ?? 'approved';
            }
        }

        return Inertia::render('admin-dashboard/manage-users/view', [
            'user' => $row,
        ]);
    }

    private function getProgramHeads(): \Illuminate\Support\Collection
    {
        if (!Schema::hasTable('program_heads')) {
            return collect();
        }

        $columns = ['id', 'name', 'email', 'program', 'verification_status', 'created_at', 'updated_at'];
        if (Schema::hasColumn('program_heads', 'role')) {
            $columns[] = 'role';
        }
        if (Schema::hasColumn('program_heads', 'office')) {
            $columns[] = 'office';
        }

        return ProgramHead::query()
            ->orderByDesc('id')
            ->get($columns)
            ->map(function ($ph) {
                /** @var ProgramHead $ph */
                return [
                    'id' => 1000000000 + (int) $ph->id,
                    'program_head_id' => (int) $ph->id,
                    'student_id' => 'PH-' . $ph->id,
                    'first_name' => null,
                    'middle_name' => null,
                    'last_name' => null,
                    'name' => $ph->name,
                    'email' => $ph->email,
                    'course' => $ph->program ?? '',
                    'year_level' => '',
                    'role' => $ph->role ?? 'Program Head',
                    'office' => $ph->office ?? null,
                    'is_active' => true,
                    'status' => $ph->verification_status ?? 'pending',
                    'qr_code_path' => null,
                    'entry_status' => null,
                    'program' => $ph->program,
                    'major' => null,
                    'home_address' => null,
                    'birthday' => null,
                    'place_of_birth' => null,
                    'religion' => null,
                    'gender' => null,
                    'contact_no' => null,
                    'nationality' => null,
                    'elementary_school' => null,
                    'elementary_year_graduated' => null,
                    'junior_high_school' => null,
                    'junior_high_year_graduated' => null,
                    'senior_high_school' => null,
                    'senior_high_year_graduated' => null,
                    'mother_name' => null,
                    'mother_contact' => null,
                    'father_name' => null,
                    'father_contact' => null,
                    'guardian_name' => null,
                    'guardian_relation' => null,
                    'guardian_contact' => null,
                    'is_archived' => false,
                    'created_at' => optional($ph->created_at)->toISOString(),
                    'updated_at' => optional($ph->updated_at)->toISOString(),
                    'userType' => 'program_head',
                ];
            });
    }

    private function getAdminUsers(): \Illuminate\Support\Collection
    {
        if (!Schema::hasTable('admin_users')) {
            return collect();
        }

        return AdminUser::query()
            ->orderByDesc('id')
            ->get(['id', 'name', 'email', 'handover_expires_at', 'is_active', 'created_by_admin_id', 'created_at', 'updated_at'])
            ->map(function ($admin) {
                /** @var AdminUser $admin */
                $isUnderHandover = $admin->isUnderHandover();
                $isExpired = $admin->isHandoverExpired() || $admin->is_active === false;

                return [
                    'id' => 2000000000 + (int) $admin->id,
                    'admin_user_id' => (int) $admin->id,
                    'student_id' => 'ADMIN-' . $admin->id,
                    'first_name' => null,
                    'middle_name' => null,
                    'last_name' => null,
                    'name' => $admin->name,
                    'email' => $admin->email,
                    'course' => 'System Administration',
                    'year_level' => '',
                    'role' => 'Administrator',
                    'is_active' => !$isExpired,
                    'status' => $isExpired ? 'expired' : ($isUnderHandover ? 'handover' : 'approved'),
                    'handover_expires_at' => optional($admin->handover_expires_at)->toISOString(),
                    'handover_expires_at_formatted' => $admin->handover_expires_at_formatted,
                    'is_handover_active' => $isUnderHandover,
                    'is_handover_expired' => $isExpired,
                    'qr_code_path' => null,
                    'entry_status' => null,
                    'program' => 'System Administration',
                    'major' => null,
                    'home_address' => null,
                    'birthday' => null,
                    'place_of_birth' => null,
                    'religion' => null,
                    'gender' => null,
                    'contact_no' => null,
                    'nationality' => null,
                    'elementary_school' => null,
                    'elementary_year_graduated' => null,
                    'junior_high_school' => null,
                    'junior_high_year_graduated' => null,
                    'senior_high_school' => null,
                    'senior_high_year_graduated' => null,
                    'mother_name' => null,
                    'mother_contact' => null,
                    'father_name' => null,
                    'father_contact' => null,
                    'guardian_name' => null,
                    'guardian_relation' => null,
                    'guardian_contact' => null,
                    'is_archived' => false,
                    'created_at' => optional($admin->created_at)->toISOString(),
                    'updated_at' => optional($admin->updated_at)->toISOString(),
                    'userType' => 'admin',
                ];
            });
    }

    private function getPrograms(): \Illuminate\Support\Collection
    {
        if (Program::count() === 0) {
            $defaultPrograms = [
                ['code' => 'BSIT', 'name' => 'Bachelor of Science in Information Technology', 'department' => 'HED', 'duration' => '4 Years', 'is_active' => true],
                ['code' => 'BSBA', 'name' => 'Bachelor of Science in Business Administration', 'department' => 'HED', 'duration' => '4 Years', 'is_active' => true],
                ['code' => 'BEED', 'name' => 'Bachelor of Elementary Education', 'department' => 'HED', 'duration' => '4 Years', 'is_active' => true],
                ['code' => 'BSED', 'name' => 'Bachelor of Secondary Education', 'department' => 'HED', 'duration' => '4 Years', 'is_active' => true],
                ['code' => 'BSCrim', 'name' => 'Bachelor of Science in Criminology', 'department' => 'HED', 'duration' => '4 Years', 'is_active' => true],
                ['code' => 'BSHM', 'name' => 'Bachelor of Science in Hospitality Management', 'department' => 'HED', 'duration' => '4 Years', 'is_active' => true],
            ];
            foreach ($defaultPrograms as $prog) {
                Program::firstOrCreate(['code' => $prog['code']], $prog);
            }
        }

        $courseCounts = Student::query()
            ->selectRaw('LOWER(TRIM(course)) as course_key, COUNT(*) as aggregate')
            ->groupBy('course_key')
            ->pluck('aggregate', 'course_key')
            ->all();

        return Program::query()
            ->orderBy('name')
            ->get()
            ->map(function ($program) use ($courseCounts) {
                $codeKey = strtolower(trim((string) $program->code));
                $nameKey = strtolower(trim((string) $program->name));

                $count = $courseCounts[$codeKey] ?? $courseCounts[$nameKey] ?? 0;

                return [
                    'id'           => $program->id,
                    'name'         => $program->name,
                    'code'         => $program->code,
                    'department'   => $program->department ?? 'N/A',
                    'description'  => $program->description ?? '',
                    'duration'     => $program->duration ?? 'N/A',
                    'status'       => $program->is_active ? 'active' : 'inactive',
                    'studentCount' => (int) $count,
                    'createdAt'    => $program->created_at ? $program->created_at->format('M d, Y') : '',
                    'updatedAt'    => $program->updated_at ? $program->updated_at->format('M d, Y') : '',
                ];
            });
    }

    private function storeQrCodePng(string $studentId, string $dataUrl): string
    {
        $prefix = 'data:image/png;base64,';
        if (!str_starts_with($dataUrl, $prefix)) {
            throw new \InvalidArgumentException('Invalid QR code image format.');
        }

        $binary = base64_decode(substr($dataUrl, strlen($prefix)), true);
        if ($binary === false) {
            throw new \InvalidArgumentException('Invalid QR code image data.');
        }

        $fileName = 'qr-codes/student-' . $studentId . '.png';
        Storage::disk('public')->put($fileName, $binary);

        $publicStoragePath = public_path('storage/' . $fileName);
        File::ensureDirectoryExists(dirname($publicStoragePath));
        File::put($publicStoragePath, $binary);

        return $fileName;
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'student_id' => ['required', 'string', 'max:255', 'unique:students,student_id'],
            'email' => ['nullable', 'string', 'email', 'max:255', 'unique:students,email'],
            'password' => ['nullable', 'string', 'min:6'],
            'first_name' => ['required', 'string', 'max:255'],
            'middle_name' => ['nullable', 'string', 'max:255'],
            'last_name' => ['required', 'string', 'max:255'],
            'course' => ['required', 'string', 'max:255'],
            'year_level' => ['required', 'string', 'max:255'],
            'program' => ['nullable', 'string', 'max:255'],
            'role' => ['sometimes', 'string', 'max:255'],
            'is_active' => ['sometimes', 'boolean'],
            'qr_code_data_url' => ['nullable', 'string'],
            'officer_features' => ['nullable', 'array'],
            'officer_features.*' => ['string'],
        ]);

        $name = trim(implode(' ', array_filter([
            $validated['first_name'],
            $validated['middle_name'] ?? null,
            $validated['last_name'],
        ])));

        $qrCodePath = null;
        if (!empty($validated['qr_code_data_url'])) {
            $qrCodePath = $this->storeQrCodePng($validated['student_id'], $validated['qr_code_data_url']);
        }

        $rawPassword = !empty($validated['password']) ? $validated['password'] : 'password123';
        $rawEmail = !empty($validated['email']) ? $validated['email'] : null;

        $studentData = [
            'student_id' => $validated['student_id'],
            'email' => $rawEmail,
            'password' => Hash::make($rawPassword),
            'first_name' => $validated['first_name'],
            'middle_name' => $validated['middle_name'] ?? null,
            'last_name' => $validated['last_name'],
            'name' => $name,
            'course' => $validated['course'],
            'year_level' => $validated['year_level'],
            'program' => $validated['program'] ?? null,
            'role' => $validated['role'] ?? 'Student',
            'is_active' => $validated['is_active'] ?? true,
            'status' => 'approved',
            'qr_code_path' => $qrCodePath,
            'officer_features' => $validated['officer_features'] ?? null,
        ];

        if (Schema::hasColumn('students', 'is_archived')) {
            $studentData['is_archived'] = false;
        }

        if (Schema::hasColumn('students', 'verification_status')) {
            $studentData['verification_status'] = 'approved';
        }

        $student = Student::create($studentData);

        if (Schema::hasTable('activity_logs')) {
            $admin = auth()->guard('admin')->user();
            ActivityLog::logForUser(
                $admin,
                'User Management',
                'Created',
                "Created user: {$validated['student_id']} ({$validated['role']})",
                $request,
                null,
                ['student_id' => $validated['student_id'], 'role' => $validated['role'], 'name' => $name]
            );
        }

        return redirect()->route('admin.manage-users')->with('success', 'Student account created successfully.')->setStatusCode(303);
    }

    public function updateStatus(Request $request, Student $student): RedirectResponse
    {
        if (!Schema::hasColumn('students', 'is_active')) {
            return redirect()->back()->with('error', 'Student active status is not available.');
        }

        $validated = $request->validate([
            'is_active' => ['required', 'boolean'],
        ]);

        $student->update([
            'is_active' => (bool) $validated['is_active'],
        ]);

        if (Schema::hasTable('activity_logs')) {
            $admin = auth()->guard('admin')->user();
            ActivityLog::logForUser(
                $admin,
                'User Management',
                'Updated',
                'Updated status for student user: ' . (string) $student->student_id
            );
        }

        return redirect()->route('admin.manage-users')->with('success', 'Student status updated successfully.')->setStatusCode(303);
    }

    public function updateApproval(Request $request, Student $student): RedirectResponse
    {
        // Backward-compatible endpoint: keep accepting `status` but persist into both
        // `verification_status` (new) and `status` (legacy) fields for full compatibility.
        $validated = $request->validate([
            'status' => ['required', 'in:pending,approved,rejected'],
        ]);

        $updateData = [];
        if (Schema::hasColumn('students', 'status')) {
            $updateData['status'] = $validated['status'];
        }
        if (Schema::hasColumn('students', 'verification_status')) {
            $updateData['verification_status'] = $validated['status'];
        }

        if (!empty($updateData)) {
            $student->update($updateData);
        }

        if (Schema::hasTable('activity_logs')) {
            $admin = auth()->guard('admin')->user();
            $oldStatus = $student->getOriginal('verification_status') ?? $student->getOriginal('status');
            $newStatus = $validated['status'];

            ActivityLog::logForUser(
                $admin,
                'User Management',
                $newStatus === 'approved' ? 'Approved' : ($newStatus === 'rejected' ? 'Rejected' : 'Updated'),
                ($newStatus === 'approved' ? 'Approved' : ($newStatus === 'rejected' ? 'Rejected' : 'Updated status for')) . " user: {$student->student_id}",
                $request,
                ['verification_status' => $oldStatus],
                ['verification_status' => $newStatus]
            );
        }

        return redirect()->route('admin.manage-users')->with(
            'success',
            'Student account ' . $validated['status'] . ' successfully.'
        )->setStatusCode(303);
    }


    public function updateLegacy(Request $request): RedirectResponse
    {
        $studentId = $request->input('id');
        if (empty($studentId)) {
            abort(404);
        }

        $student = Student::query()->findOrFail($studentId);

        return $this->update($request, $student);
    }

    public function destroyLegacy(Request $request): RedirectResponse
    {
        $studentId = $request->input('id');
        if (empty($studentId)) {
            abort(404);
        }

        $student = Student::query()->findOrFail($studentId);

        return $this->archive($student);
    }

    public function archive(Student $student): RedirectResponse
    {
        if (!Schema::hasColumn('students', 'is_archived')) {
            return redirect()
                ->route('admin.manage-users')
                ->with('error', 'Archive is not available because the is_archived column is missing in students table.');
        }

        $oldArchived = (bool) ($student->getOriginal('is_archived') ?? false);
        $student->update(['is_archived' => true]);

        if (Schema::hasTable('activity_logs')) {
            $admin = auth()->guard('admin')->user();
            ActivityLog::logForUser(
                $admin,
                'User Management',
                'Archived',
                "Archived user: {$student->student_id}",
                request(),
                ['is_archived' => $oldArchived],
                ['is_archived' => true]
            );
        }

        return redirect()->route('admin.manage-users')->with('success', 'Student archived successfully.')->setStatusCode(303);
    }

    public function unarchive(Student $student): RedirectResponse
    {
        if (!Schema::hasColumn('students', 'is_archived')) {
            return redirect()
                ->route('admin.archive')
                ->with('error', 'Unarchive is not available because the is_archived column is missing in students table.');
        }

        $oldArchived = (bool) ($student->getOriginal('is_archived') ?? false);
        $student->update(['is_archived' => false]);

        if (Schema::hasTable('activity_logs')) {
            $admin = auth()->guard('admin')->user();
            ActivityLog::logForUser(
                $admin,
                'User Management',
                'Unarchived',
                "Unarchived user: {$student->student_id}",
                request(),
                ['is_archived' => $oldArchived],
                ['is_archived' => false]
            );
        }

        return redirect()->route('admin.archive')->with('success', 'Student restored successfully.');
    }

    public function update(Request $request, Student $student): RedirectResponse
    {
        $validated = $request->validate([
            'student_id' => ['required', 'string', 'max:255', 'unique:students,student_id,' . $student->id],
            'email' => ['nullable', 'string', 'email', 'max:255', 'unique:students,email,' . $student->id],
            'password' => ['nullable', 'string', 'min:8'],
            'first_name' => ['required', 'string', 'max:255'],
            'middle_name' => ['nullable', 'string', 'max:255'],
            'last_name' => ['required', 'string', 'max:255'],
            'course' => ['required', 'string', 'max:255'],
            'year_level' => ['required', 'string', 'max:255'],
            'role' => ['required', 'string', 'max:255'],
            'is_active' => ['sometimes', 'boolean'],
            'qr_code_data_url' => ['nullable', 'string'],
            'officer_features' => ['nullable', 'array'],
            'officer_features.*' => ['string'],
        ]);

        $name = trim(implode(' ', array_filter([
            $validated['first_name'],
            $validated['middle_name'] ?? null,
            $validated['last_name'],
        ])));

        if (!empty($validated['qr_code_data_url'])) {
            $student->qr_code_path = $this->storeQrCodePng($validated['student_id'], $validated['qr_code_data_url']);
        }

        $student->fill([
            'student_id' => $validated['student_id'],
            'email' => !empty($validated['email']) ? $validated['email'] : ($student->email ?: null),
            'first_name' => $validated['first_name'],
            'middle_name' => $validated['middle_name'] ?? null,
            'last_name' => $validated['last_name'],
            'name' => $name,
            'course' => $validated['course'],
            'year_level' => $validated['year_level'],
            'role' => $validated['role'],
            'is_active' => $validated['is_active'] ?? $student->is_active,
            'officer_features' => $validated['officer_features'] ?? null,
        ]);

        if (!empty($validated['password'])) {
            $student->password = Hash::make($validated['password']);
        }

        $student->save();

        if (Schema::hasTable('activity_logs')) {
            $admin = auth()->guard('admin')->user();
            ActivityLog::logForUser(
                $admin,
                'User Management',
                'Updated',
                "Updated user: {$student->student_id}",
                $request,
                $student->getOriginal(),
                $student->getAttributes()
            );
        }

        return redirect()->route('admin.manage-users')->with('success', 'Student account updated successfully.')->setStatusCode(303);
    }

    public function destroy(Student $student): RedirectResponse
    {
        return $this->archive($student);
    }

    public function approveProgramHead(Request $request, ProgramHead $programHead): RedirectResponse
    {
        $validated = $request->validate([
            'status' => ['sometimes', 'in:approved,rejected,pending'],
        ]);

        // Admin endpoints use request body status; if missing, default to approved.
        $targetStatus = Arr::get($validated, 'status', 'approved');

        $programHead->update([
            'verification_status' => $targetStatus,
        ]);

        if (Schema::hasTable('activity_logs')) {
            $admin = auth()->guard('admin')->user();
            ActivityLog::logForUser(
                $admin,
                'User Management',
                $targetStatus === 'approved' ? 'Approved' : ($targetStatus === 'rejected' ? 'Rejected' : 'Updated'),
                ($targetStatus === 'approved' ? 'Approved' : ($targetStatus === 'rejected' ? 'Rejected' : 'Updated')) . " program head user: {$programHead->id}",
                $request,
                ['verification_status' => $programHead->getOriginal('verification_status')],
                ['verification_status' => $targetStatus]
            );
        }

        return redirect()->route('admin.manage-users')->with(
            'success',
            'Program head account ' . $targetStatus . ' successfully.'
        )->setStatusCode(303);
    }

    public function rejectProgramHead(Request $request, ProgramHead $programHead): RedirectResponse
    {
        $request->validate([
            'status' => ['sometimes', 'in:approved,rejected,pending'],
        ]);

        $programHead->update([
            'verification_status' => 'rejected',
        ]);

        if (Schema::hasTable('activity_logs')) {
            $admin = auth()->guard('admin')->user();
            ActivityLog::logForUser(
                $admin,
                'User Management',
                'Rejected',
                "Rejected program head user: {$programHead->id}",
                $request,
                ['verification_status' => $programHead->getOriginal('verification_status')],
                ['verification_status' => 'rejected']
            );
        }

        return redirect()->route('admin.manage-users')->with(
            'success',
            'Program head account rejected successfully.'
        )->setStatusCode(303);
    }

    public function destroyProgramHead(ProgramHead $programHead): RedirectResponse
    {
        $name = $programHead->name;
        $email = $programHead->email;
        $programHead->delete();

        if (Schema::hasTable('activity_logs')) {
            $admin = auth()->guard('admin')->user();
            ActivityLog::logForUser(
                $admin,
                'User Management',
                'Deleted',
                "Deleted program head: {$name} ({$email})",
                request()
            );
        }

        return redirect()->route('admin.manage-users')->with('success', 'Program Head account deleted successfully.')->setStatusCode(303);
    }

    public function bulkApproveVerification(Request $request): RedirectResponse
    {
        return $this->bulkSetVerification($request, 'approved');
    }

    public function bulkRejectVerification(Request $request): RedirectResponse
    {
        return $this->bulkSetVerification($request, 'rejected');
    }

    private function bulkSetVerification(Request $request, string $status): RedirectResponse
    {
        $validated = $request->validate([
            'ids' => ['required', 'array', 'min:1'],
            'ids.*' => ['integer'],
        ]);

        $ids = $validated['ids'];

        // Program head synthetic IDs are 1,000,000,000 + program_heads.id
        $programHeadIds = collect($ids)
            ->filter(fn ($id) => $id >= 1000000000 && $id < 2000000000)
            ->map(fn ($id) => (int) $id - 1000000000)
            ->values();

        // Student synthetic IDs are the actual students.id
        $studentIds = collect($ids)
            ->filter(fn ($id) => $id < 1000000000)
            ->values();

        if ($studentIds->isNotEmpty()) {
            $updateData = [];
            if (Schema::hasColumn('students', 'verification_status')) {
                $updateData['verification_status'] = $status;
            }
            if (Schema::hasColumn('students', 'status')) {
                $updateData['status'] = $status;
            }

            if (!empty($updateData)) {
                Student::query()
                    ->whereIn('id', $studentIds->all())
                    ->update($updateData);
            }
        }

        if ($programHeadIds->isNotEmpty() && Schema::hasColumn('program_heads', 'verification_status')) {
            ProgramHead::query()
                ->whereIn('id', $programHeadIds->all())
                ->update(['verification_status' => $status]);
        }

        if (Schema::hasTable('activity_logs')) {
            $admin = auth()->guard('admin')->user();
            ActivityLog::logForUser(
                $admin,
                'User Management',
                $status === 'approved' ? 'Bulk Approved' : 'Bulk Rejected',
                "Bulk set verification to '{$status}' for " . count($ids) . ' records',
                $request,
                ['status' => null, 'ids' => $ids],
                ['status' => $status, 'ids' => $ids]
            );
        }

        return redirect()->route('admin.manage-users')->with(
            'success',
            'Verification updated successfully.'
        )->setStatusCode(303);
    }

    public function bulkActivate(Request $request): RedirectResponse
    {
        return $this->bulkSetStatus($request, true);
    }

    public function bulkDeactivate(Request $request): RedirectResponse
    {
        return $this->bulkSetStatus($request, false);
    }

    private function bulkSetStatus(Request $request, bool $isActive): RedirectResponse
    {
        $validated = $request->validate([
            'ids' => ['required', 'array', 'min:1'],
            'ids.*' => ['integer'],
        ]);

        $ids = $validated['ids'];

        // Program head synthetic IDs are 1,000,000,000 + program_heads.id
        $programHeadIds = collect($ids)
            ->filter(fn ($id) => $id >= 1000000000 && $id < 2000000000)
            ->map(fn ($id) => (int) $id - 1000000000)
            ->values();

        // Student synthetic IDs are the actual students.id
        $studentIds = collect($ids)
            ->filter(fn ($id) => $id < 1000000000)
            ->values();

        if ($studentIds->isNotEmpty()) {
            Student::query()
                ->whereIn('id', $studentIds->all())
                ->update(['is_active' => $isActive]);
        }

        if ($programHeadIds->isNotEmpty()) {
            ProgramHead::query()
                ->whereIn('id', $programHeadIds->all())
                ->update(['is_active' => $isActive]);
        }

        if (Schema::hasTable('activity_logs')) {
            $admin = auth()->guard('admin')->user();
            ActivityLog::logForUser(
                $admin,
                'User Management',
                $isActive ? 'Bulk Activated' : 'Bulk Deactivated',
                "Bulk set status to '" . ($isActive ? 'Active' : 'Inactive') . "' for " . count($ids) . ' records',
                $request,
                ['status' => null, 'ids' => $ids],
                ['status' => $isActive, 'ids' => $ids]
            );
        }

        return redirect()->route('admin.manage-users')->with(
            'success',
            'Account status updated successfully.'
        )->setStatusCode(303);
    }

    public function bulkSetYearLevel(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'ids' => ['required', 'array', 'min:1'],
            'ids.*' => ['integer'],
            'year_level' => ['required', 'string', 'in:1st Year,2nd Year,3rd Year,4th Year,Irregular,Graduated'],
        ]);

        $ids = $validated['ids'];

        // Student synthetic IDs are the actual students.id
        $studentIds = collect($ids)
            ->filter(fn ($id) => $id < 1000000000)
            ->values();

        if ($studentIds->isNotEmpty()) {
            Student::query()
                ->whereIn('id', $studentIds->all())
                ->update(['year_level' => $validated['year_level']]);
        }

        if (Schema::hasTable('activity_logs')) {
            $admin = auth()->guard('admin')->user();
            ActivityLog::logForUser(
                $admin,
                'User Management',
                'Bulk Updated Year Level',
                "Bulk set year level to '{$validated['year_level']}' for " . count($studentIds) . ' students',
                $request,
                ['year_level' => null, 'ids' => $studentIds->all()],
                ['year_level' => $validated['year_level'], 'ids' => $studentIds->all()]
            );
        }

        return redirect()->route('admin.manage-users')->with(
            'success',
            'Year level updated successfully.'
        )->setStatusCode(303);
    }

    public function bulkSetProgram(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'ids' => ['required', 'array', 'min:1'],
            'ids.*' => ['integer'],
            'program' => ['required', 'string', 'max:255'],
        ]);

        $ids = $validated['ids'];

        $studentIds = collect($ids)
            ->filter(fn ($id) => $id < 1000000000)
            ->values();

        if ($studentIds->isNotEmpty()) {
            Student::query()
                ->whereIn('id', $studentIds->all())
                ->update(['course' => $validated['program']]);
        }

        if (Schema::hasTable('activity_logs')) {
            $admin = auth()->guard('admin')->user();
            ActivityLog::logForUser(
                $admin,
                'User Management',
                'Bulk Updated Program',
                "Bulk set program to '{$validated['program']}' for " . count($studentIds) . ' students',
                $request,
                ['program' => null, 'ids' => $studentIds->all()],
                ['program' => $validated['program'], 'ids' => $studentIds->all()]
            );
        }

        return redirect()->route('admin.manage-users')->with(
            'success',
            'Program updated successfully.'
        )->setStatusCode(303);
    }

    public function bulkSetEntryStatus(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'ids' => ['required', 'array', 'min:1'],
            'ids.*' => ['integer'],
            'entry_status' => ['required', 'string', 'max:255'],
        ]);

        $ids = $validated['ids'];

        $studentIds = collect($ids)
            ->filter(fn ($id) => $id < 1000000000)
            ->values();

        if ($studentIds->isNotEmpty()) {
            Student::query()
                ->whereIn('id', $studentIds->all())
                ->update(['entry_status' => $validated['entry_status']]);
        }

        if (Schema::hasTable('activity_logs')) {
            $admin = auth()->guard('admin')->user();
            ActivityLog::logForUser(
                $admin,
                'User Management',
                'Bulk Updated Entry Status',
                "Bulk set entry status to '{$validated['entry_status']}' for " . count($studentIds) . ' students',
                $request,
                ['entry_status' => null, 'ids' => $studentIds->all()],
                ['entry_status' => $validated['entry_status'], 'ids' => $studentIds->all()]
            );
        }

        return redirect()->route('admin.manage-users')->with(
            'success',
            'Entry status updated successfully.'
        )->setStatusCode(303);
    }

    public function bulkResetOfficerRole(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'ids' => ['required', 'array', 'min:1'],
            'ids.*' => ['integer'],
        ]);

        $ids = $validated['ids'];

        $studentIds = collect($ids)
            ->filter(fn ($id) => $id < 1000000000)
            ->values();

        if ($studentIds->isNotEmpty()) {
            Student::query()
                ->whereIn('id', $studentIds->all())
                ->update([
                    'role' => 'Student',
                    'officer_features' => null,
                ]);
        }

        if (Schema::hasTable('activity_logs')) {
            $admin = auth()->guard('admin')->user();
            ActivityLog::logForUser(
                $admin,
                'User Management',
                'Bulk Reset Officer Role',
                'Bulk reset officer role to Student for ' . count($studentIds) . ' students',
                $request,
                ['role' => null, 'ids' => $studentIds->all()],
                ['role' => 'Student', 'ids' => $studentIds->all()]
            );
        }

        return redirect()->route('admin.manage-users')->with(
            'success',
            'Officer roles reset to Student successfully.'
        )->setStatusCode(303);
    }


    public function updateProgramHead(Request $request, ProgramHead $programHead): RedirectResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:program_heads,email,' . $programHead->id],
            'program' => ['nullable', 'string', 'max:255'],
            'role' => ['nullable', 'string', 'max:255'],
            'office' => ['nullable', 'string', 'max:255'],
            'password' => ['nullable', 'string', 'min:8'],
        ]);

        $updateData = [
            'name' => $validated['name'],
            'email' => $validated['email'],
            'program' => $validated['program'] ?? null,
        ];

        if (Schema::hasColumn('program_heads', 'role')) {
            $updateData['role'] = $validated['role'] ?? $programHead->role ?? 'Program Head';
        }

        if (Schema::hasColumn('program_heads', 'office')) {
            $updateData['office'] = $validated['office'] ?? $programHead->office ?? null;
        }

        $programHead->fill($updateData);

        if (!empty($validated['password'])) {
            $programHead->password = Hash::make($validated['password']);
        }

        $programHead->save();

        if (Schema::hasTable('activity_logs')) {
            $admin = auth()->guard('admin')->user();
            ActivityLog::logForUser(
                $admin,
                'User Management',
                'Updated',
                "Updated personnel user: {$programHead->email}",
                $request,
                $programHead->getOriginal(),
                $programHead->getAttributes()
            );
        }

        return redirect()->route('admin.manage-users')->with('success', 'Personnel account updated successfully.')->setStatusCode(303);
    }

    public function storeProgramHead(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:program_heads,email'],
            'program' => ['nullable', 'string', 'max:255'],
            'role' => ['nullable', 'string', 'max:255'],
            'office' => ['nullable', 'string', 'max:255'],
            'password' => ['required', 'string', 'min:8'],
        ]);

        $createData = [
            'name' => $validated['name'],
            'email' => $validated['email'],
            'program' => $validated['program'] ?? null,
            'password' => Hash::make($validated['password']),
            'verification_status' => 'approved',
        ];

        if (Schema::hasColumn('program_heads', 'role')) {
            $createData['role'] = $validated['role'] ?? 'Program Head';
        }

        if (Schema::hasColumn('program_heads', 'office')) {
            $createData['office'] = $validated['office'] ?? null;
        }

        $programHead = ProgramHead::create($createData);

        if (Schema::hasTable('activity_logs')) {
            $admin = auth()->guard('admin')->user();
            ActivityLog::logForUser(
                $admin,
                'User Management',
                'Created',
                "Created personnel user: {$validated['email']}",
                $request,
                null,
                $programHead->getAttributes()
            );
        }

        return redirect()->route('admin.manage-users')->with('success', 'Personnel account created successfully.')->setStatusCode(303);
    }

    public function storeAdmin(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:admin_users,email', 'unique:students,email', 'unique:program_heads,email'],
            'password' => ['required', 'string', 'min:8'],
        ]);

        $currentAdmin = auth()->guard('admin')->user();

        // 1. Create the new Administrator account
        $newAdmin = AdminUser::create([
            'name' => $validated['name'],
            'email' => $validated['email'],
            'password' => Hash::make($validated['password']),
            'is_active' => true,
            'created_by_admin_id' => $currentAdmin ? $currentAdmin->id : null,
        ]);

        // 2. Set 3-day (72 hours) expiration on the current admin
        $expirationTime = Carbon::now()->addDays(3);
        if ($currentAdmin) {
            $currentAdmin->update([
                'handover_expires_at' => $expirationTime,
            ]);
        }

        // 3. Log activity
        if (Schema::hasTable('activity_logs')) {
            ActivityLog::logForUser(
                $currentAdmin,
                'User Management',
                'Admin Handover',
                "Initiated Admin Handover. Created new Administrator: {$newAdmin->name} ({$newAdmin->email}). Current admin account scheduled to expire on " . $expirationTime->format('M d, Y g:i A') . " (3 days transition period).",
                $request,
                null,
                [
                    'new_admin_id' => $newAdmin->id,
                    'new_admin_email' => $newAdmin->email,
                    'expires_at' => $expirationTime->toIso8601String(),
                ]
            );
        }

        return redirect()->route('admin.manage-users')->with(
            'success',
            "New Administrator account for {$newAdmin->name} ({$newAdmin->email}) created successfully! Your current admin account is now in a 3-day handover period and will automatically expire on " . $expirationTime->format('M d, Y g:i A') . "."
        )->setStatusCode(303);
    }

    public function downloadBulkTemplate(Request $request)
    {
        $format = strtolower($request->query('format', 'csv'));
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle('Student Template');
        $sheet->fromArray([
            ['Student ID', 'Firstname', 'Lastname', 'Grade/Year Level', 'Section/Course', 'Department'],
            ['C230103', 'Vincent Jay', 'Abelidas', '4th Year', 'BSBA', 'HED'],
        ]);

        if ($format === 'xlsx') {
            $fileName = 'student_bulk_template.xlsx';
            $writer = new Xlsx($spreadsheet);
            $contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
        } else {
            $fileName = 'student_bulk_template.csv';
            $writer = new Csv($spreadsheet);
            $contentType = 'text/csv';
        }

        return response()->streamDownload(function () use ($writer) {
            $writer->save('php://output');
        }, $fileName, [
            'Content-Type' => $contentType,
            'Cache-Control' => 'no-cache, no-store, must-revalidate',
            'Pragma' => 'no-cache',
            'Expires' => '0',
        ]);
    }

    private function normalizeHeader(string $header): string
    {
        $key = strtolower(trim($header));
        if (in_array($key, ['student id', 'student_id', 'studentid', 'id'])) {
            return 'student_id';
        }
        if (in_array($key, ['firstname', 'first_name', 'first name'])) {
            return 'first_name';
        }
        if (in_array($key, ['lastname', 'last_name', 'last name'])) {
            return 'last_name';
        }
        if (in_array($key, ['grade/year level', 'year_level', 'year level', 'grade', 'year'])) {
            return 'year_level';
        }
        if (in_array($key, ['section/course', 'course', 'section', 'section_course'])) {
            return 'course';
        }
        if (in_array($key, ['department', 'program', 'dept'])) {
            return 'program';
        }
        return $key;
    }

    public function bulkImport(Request $request): RedirectResponse
    {
        if ($request->isMethod('get')) {
            return redirect()->route('admin.manage-users');
        }

        $rowsToImport = [];

        if ($request->hasFile('file')) {
            $request->validate([
                'file' => ['required', 'file', 'mimes:csv,xlsx,xls,txt', 'max:10240'],
            ]);

            $file = $request->file('file');
            $spreadsheet = IOFactory::load($file->getRealPath());
            $worksheet = $spreadsheet->getActiveSheet();
            $rawSheetData = $worksheet->toArray();

            if (empty($rawSheetData)) {
                return redirect()->back()->with('error', 'The uploaded file is empty.');
            }

            $rawHeader = array_shift($rawSheetData);
            $mappedHeader = array_map(fn($h) => $this->normalizeHeader((string)$h), $rawHeader);

            foreach ($rawSheetData as $row) {
                if (empty(array_filter($row, fn($v) => !is_null($v) && trim((string)$v) !== ''))) {
                    continue;
                }
                $item = [];
                foreach ($mappedHeader as $index => $colName) {
                    $item[$colName] = isset($row[$index]) ? trim((string)$row[$index]) : '';
                }
                $rowsToImport[] = $item;
            }
        } elseif ($request->has('rows') && is_array($request->input('rows'))) {
            $rawRows = $request->input('rows');
            foreach ($rawRows as $row) {
                if (!is_array($row)) continue;
                $item = [];
                foreach ($row as $k => $v) {
                    $item[$this->normalizeHeader((string)$k)] = trim((string)$v);
                }
                $rowsToImport[] = $item;
            }
        } else {
            return redirect()->back()->with('error', 'No file or valid data rows provided for bulk import.');
        }

        if (empty($rowsToImport)) {
            return redirect()->back()->with('error', 'No valid student records found in the import source.');
        }

        $importedCount = 0;
        $skippedCount = 0;

        // Pre-compute defaults and cache schema checks outside loop for performance
        $defaultPasswordHash = Hash::make('password123');
        $hasIsArchived = Schema::hasColumn('students', 'is_archived');
        $hasVerificationStatus = Schema::hasColumn('students', 'verification_status');

        // Pre-fetch existing values for duplicate checking (case-insensitive)
        $existingStudentIds = Student::pluck('student_id')
            ->map(fn($v) => strtolower(trim((string)$v)))
            ->filter()
            ->flip()
            ->all();

        $existingEmails = Student::pluck('email')
            ->map(fn($v) => strtolower(trim((string)$v)))
            ->filter()
            ->flip()
            ->all();

        \Illuminate\Support\Facades\DB::transaction(function () use (
            $rowsToImport,
            $defaultPasswordHash,
            $hasIsArchived,
            $hasVerificationStatus,
            &$existingStudentIds,
            &$existingEmails,
            &$importedCount,
            &$skippedCount
        ) {
            foreach ($rowsToImport as $row) {
                $rawId = $row['student_id'] ?? '';
                if (empty($rawId)) {
                    continue;
                }

                // Format Student ID: Ensure ID- prefix is present exactly once
                if (preg_match('/^ID-/i', $rawId)) {
                    $studentId = 'ID-' . preg_replace('/^ID-/i', '', $rawId);
                } else {
                    $studentId = 'ID-' . $rawId;
                }

                $firstName = $row['first_name'] ?? '';
                $lastName = $row['last_name'] ?? '';
                $fullName = trim($firstName . ' ' . $lastName);

                $rawIdLower = strtolower(trim($rawId));
                $studentIdLower = strtolower(trim($studentId));
                $email = !empty($row['email']) ? trim((string)$row['email']) : null;
                $emailLower = $email !== null ? strtolower(trim($email)) : null;

                // Duplicate checking: Skip ONLY if Student ID or Email already exists
                $isDuplicateId = isset($existingStudentIds[$studentIdLower]) || isset($existingStudentIds[$rawIdLower]);
                $isDuplicateEmail = $emailLower !== null && isset($existingEmails[$emailLower]);

                if ($isDuplicateId || $isDuplicateEmail) {
                    $skippedCount++;
                    continue;
                }

                $studentData = [
                    'student_id' => $studentId,
                    'first_name' => $firstName,
                    'last_name' => $lastName,
                    'name' => $fullName,
                    'year_level' => $row['year_level'] ?? '',
                    'course' => $row['course'] ?? '',
                    'program' => $row['program'] ?? '',
                    'email' => $email,
                    'role' => 'Student',
                    'is_active' => true,
                    'status' => 'approved',
                    'password' => $defaultPasswordHash,
                ];

                if ($hasIsArchived) {
                    $studentData['is_archived'] = false;
                }

                if ($hasVerificationStatus) {
                    $studentData['verification_status'] = 'approved';
                }

                Student::create($studentData);

                // Register into tracked sets so duplicate rows within the file are also caught
                $existingStudentIds[$studentIdLower] = true;
                $existingStudentIds[$rawIdLower] = true;
                if ($emailLower !== null) {
                    $existingEmails[$emailLower] = true;
                }

                $importedCount++;
            }
        });

        if (Schema::hasTable('activity_logs')) {
            $admin = auth()->guard('admin')->user();
            ActivityLog::logForUser(
                $admin,
                'User Management',
                'Bulk Import',
                "Bulk imported students: {$importedCount} created, {$skippedCount} skipped as duplicate.",
                $request
            );
        }

        $msgParts = [];
        if ($importedCount > 0) {
            $msgParts[] = "{$importedCount} student(s) added";
        }
        if ($skippedCount > 0) {
            $msgParts[] = "{$skippedCount} duplicate record(s) skipped";
        }

        $resultMsg = !empty($msgParts)
            ? 'Bulk import completed: ' . implode(', ', $msgParts) . '.'
            : 'No new student records were added.';

        return redirect()->route('admin.manage-users')->with('success', $resultMsg)->setStatusCode(303);
    }

    /**
     * Reset a student's bound device (One Device, One Account policy).
     * Enables students who lost/replaced their phone to bind their new device.
     */
    public function resetStudentDevice(Student $student, Request $request)
    {
        $oldDevice = $student->device_name ?: $student->device_uuid ?: 'Registered Device';
        $student->resetDeviceBinding();

        if (Schema::hasTable('activity_logs')) {
            $admin = auth()->guard('admin')->user();
            ActivityLog::logForUser(
                $admin,
                'User Management',
                'Device Reset',
                "Reset registered device binding for student {$student->name} ({$student->student_id}). Previous device: {$oldDevice}.",
                $request
            );
        }

        if ($request->wantsJson()) {
            return response()->json([
                'success' => true,
                'message' => "Device binding for {$student->name} has been reset. The student can now register a new device on next login.",
            ]);
        }

        return back()->with('success', "Device binding for {$student->name} has been successfully reset.")->setStatusCode(303);
    }
}
