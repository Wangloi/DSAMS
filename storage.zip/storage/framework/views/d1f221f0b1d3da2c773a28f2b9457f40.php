<?php
    $componentName = $page['component'] ?? '';
    $isLandingPage = in_array($componentName, [
        'landing-page',
        'landing/about',
        'landing/features',
        'landing/get-started',
        'help',
        'privacy',
        'terms',
        'sitemap',
        'welcome',
    ]);
?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['dark' => !$isLandingPage && ($appearance ?? 'light') == 'dark']); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">

        <!-- PWA Web App Manifest & App Metadata -->
        <link rel="manifest" href="/manifest.json">
        <meta name="mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
        <meta name="apple-mobile-web-app-title" content="DSAMS">
        <meta name="application-name" content="DSAMS">
        <meta name="theme-color" content="#0b1c5c">

        
        <script>
            (function() {
                const isLandingPage = <?php echo e($isLandingPage ? 'true' : 'false'); ?>;
                if (isLandingPage) {
                    document.documentElement.classList.remove('dark');
                    document.documentElement.style.colorScheme = 'light';
                    return;
                }

                let appearance = 'light';
                try {
                    const stored = localStorage.getItem('appearance');
                    if (stored === 'dark' || stored === 'light') {
                        appearance = stored;
                    } else {
                        appearance = '<?php echo e(($appearance ?? "light") === "dark" ? "dark" : "light"); ?>';
                    }
                } catch (e) {
                    appearance = '<?php echo e(($appearance ?? "light") === "dark" ? "dark" : "light"); ?>';
                }

                if (appearance === 'dark') {
                    document.documentElement.classList.add('dark');
                    document.documentElement.style.colorScheme = 'dark';
                } else {
                    document.documentElement.classList.remove('dark');
                    document.documentElement.style.colorScheme = 'light';
                }
            })();
        </script>

        
        <style>
            html {
                background-color: oklch(1 0 0);
            }

            html.dark {
                background-color: oklch(0.145 0 0);
            }
        </style>

        <title inertia><?php echo e(config('app.name', 'OSAMS')); ?></title>

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <link rel="icon" href="/images/DSA.ico" sizes="any">
        <link rel="icon" href="/images/DSA.png" type="image/png">
        <link rel="apple-touch-icon" href="/images/DSA.png">
        <link rel="apple-touch-icon" sizes="152x152" href="/images/DSA.png">
        <link rel="apple-touch-icon" sizes="180x180" href="/images/DSA.png">
        <link rel="apple-touch-icon" sizes="167x167" href="/images/DSA.png">

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

        <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.tsx']); ?>
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
    </head>
    <body class="font-sans antialiased">
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } elseif (config('inertia.use_script_element_for_initial_page')) { ?><script data-page="app" type="application/json"><?php echo json_encode($page); ?></script><div id="app"></div><?php } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
    </body>
</html>
<?php /**PATH C:\laragon\www\DSAMS\resources\views/app.blade.php ENDPATH**/ ?>