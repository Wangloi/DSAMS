<?php

namespace App\Services;

use App\Events\StudentNotificationRequested;
use App\Models\Announcement;
use App\Models\Attendance;
use App\Models\Event;
use App\Models\Incident;
use App\Models\Student;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class StudentNotificationDispatcher
{
    public function notifyStudents(
        iterable $studentIds,
        string $type,
        string $title,
        string $message,
        array $data = [],
        ?string $dedupeKey = null,
        bool $allowMail = true,
    ): void {
        $ids = collect($studentIds)
            ->map(fn ($id) => (int) $id)
            ->filter(fn (int $id) => $id > 0)
            ->unique()
            ->values()
            ->all();

        if (empty($ids)) {
            return;
        }

        $dispatch = function () use ($ids, $type, $title, $message, $data, $dedupeKey, $allowMail) {
            event(new StudentNotificationRequested(
                studentIds: $ids,
                type: $type,
                title: $title,
                message: $message,
                data: $data,
                dedupeKey: $dedupeKey,
                allowMail: $allowMail,
            ));

            // Real-Time Socket.IO delivery
            $realtimeService = app(\App\Services\RealtimeNotificationService::class);
            foreach ($ids as $studentId) {
                $realtimeService->sendToUser($studentId, [
                    'type'         => $type,
                    'title'        => $title,
                    'message'      => $message,
                    'related_id'   => $data['id'] ?? null,
                    'related_type' => $type,
                    'meta_data'    => $data,
                ], 'App\\Models\\Student');
            }
        };

        DB::transactionLevel() > 0 ? DB::afterCommit($dispatch) : $dispatch();
    }

    public function eventCreated(Event $event): void
    {
        $this->notifyStudents(
            $this->targetStudentIdsForEvent($event),
            'event_upcoming',
            'Upcoming event: '.(string) $event->event_name,
            'A new event has been posted for you.',
            $this->eventPayload($event),
            'event-upcoming-'.$event->id,
        );
    }


    public function eventUpdated(Event $event, array $changedFields): void
    {
        $important = array_values(array_intersect($changedFields, [
            'event_name',
            'event_date',
            'event_time',
            'registration_end_time',
            'location',
            'description',
        ]));

        if (empty($important)) {
            return;
        }

        $this->notifyStudents(
            $this->targetStudentIdsForEvent($event),
            'event_updated',
            'Event details updated',
            (string) $event->event_name.' has updated schedule, venue, or instructions.',
            [
                ...$this->eventPayload($event),
                'changed_fields' => $important,
            ],
            'event-updated-'.$event->id.'-'.md5(implode('|', $important).'|'.$event->updated_at?->timestamp),
        );
    }

    public function eventReminder(Event $event, string $timeframe = 'today', ?string $customMessage = null): void
    {
        $eventDateStr = optional($event->event_date)->format('F d, Y') ?? (string) $event->event_date;
        $eventTimeStr = (string) ($event->event_time ?? '');
        $venueStr = (string) ($event->location ?? 'Campus');

        $title = match ($timeframe) {
            'today' => 'Event Reminder: Today\'s Event',
            'tomorrow' => 'Event Reminder: Event Tomorrow',
            'soon' => 'Upcoming Event Reminder',
            default => 'Event Reminder: '.(string) $event->event_name,
        };

        $message = $customMessage ?? match ($timeframe) {
            'today' => "Reminder: \"{$event->event_name}\" is happening TODAY at {$eventTimeStr} at {$venueStr}. Don't forget to attend and scan your attendance.",
            'tomorrow' => "Reminder: \"{$event->event_name}\" is scheduled for TOMORROW ({$eventDateStr}) at {$eventTimeStr} at {$venueStr}.",
            'soon' => "Reminder: \"{$event->event_name}\" will take place on {$eventDateStr} at {$eventTimeStr} ({$venueStr}).",
            default => "Reminder: \"{$event->event_name}\" is scheduled on {$eventDateStr} at {$eventTimeStr} at {$venueStr}.",
        };

        $dedupeKey = 'event-reminder-'.$timeframe.'-'.$event->id.'-'.date('Y-m-d');

        $this->notifyStudents(
            $this->targetStudentIdsForEvent($event),
            'event_reminder',
            $title,
            $message,
            [
                ...$this->eventPayload($event),
                'timeframe' => $timeframe,
            ],
            $dedupeKey,
            true,
        );
    }


    public function scannerAccessGranted(Event $event, array $studentNumbers): void
    {
        $studentNumbers = array_values(array_filter(array_map(fn ($v) => trim((string) $v), $studentNumbers), fn ($v) => $v !== ''));

        if (empty($studentNumbers)) {
            return;
        }

        $query = Student::query()->where('is_active', true)->where('status', 'approved');

        $query->where(function (Builder $q) use ($studentNumbers) {
            $q->whereIn('student_id', $studentNumbers)
              ->orWhereIn('id', array_filter($studentNumbers, 'is_numeric'));
        });

        $studentIds = $query->pluck('id');

        if ($studentIds->isEmpty()) {
            return;
        }

        $eventDateStr = optional($event->event_date)->format('M d, Y') ?? (string) $event->event_date;
        $eventTimeStr = (string) ($event->event_time ?? '');
        $venueStr = (string) ($event->location ?? '');

        $title = 'Assigned to Attendance: ' . (string) $event->event_name;
        $details = array_filter([$eventDateStr, $eventTimeStr, $venueStr]);
        $detailsStr = !empty($details) ? ' (' . implode(' • ', $details) . ')' : '';
        $message = 'You have been assigned as an attendance scanner for ' . (string) $event->event_name . $detailsStr . '. You can now access the attendance scanner portal.';

        $this->notifyStudents(
            $studentIds,
            'scanner_portal_access_granted',
            $title,
            $message,
            [
                ...$this->eventPayload($event),
                'assigned_as' => 'attendance_scanner',
                'event_name' => (string) $event->event_name,
                'event_date' => $eventDateStr,
                'event_time' => $eventTimeStr,
                'location' => $venueStr,
            ],
            'scanner-access-' . $event->id . '-' . implode('-', $studentIds->all()) . '-' . now()->timestamp,
        );
    }


    public function attendanceScannerAvailable(Event $event): void
    {
        // Must notify ONLY students matching the event's selected courses + year levels.
        // If courses/year_levels are empty, the event targets are considered "all students"
        // (same semantics used by eligibleStudentsCount()).
        $this->notifyStudents(
            $this->targetStudentIdsForEvent($event),
            'attendance_scanner_available',
            'Attendance Scanner Available',
            'You are now allowed to scan attendance for '.(string) $event->event_name,
            [
                ...$this->eventPayload($event),
                'event_id' => $event->id,
            ],
            'attendance-scanner-available-'.$event->id,
        );
    }


    public function attendanceRecorded(Event $event, Attendance $attendance): void
    {
        $this->notifyStudents(
            [$attendance->student_id],
            'attendance_recorded',
            'Attendance recorded',
            'Your attendance for '.(string) $event->event_name.' was recorded as '.(string) $attendance->status.'.',
            [
                ...$this->eventPayload($event),
                'attendance_id' => $attendance->id,
                'status' => $attendance->status,
                'scanned_at' => optional($attendance->scanned_at ?? $attendance->checked_in_at)->toDateTimeString(),
            ],
            'attendance-recorded-'.$attendance->id.'-'.(string) $attendance->updated_at?->timestamp,
            false,
        );
    }

    public function attendanceIssue(Event $event, ?Student $student, string $message, string $reason): void
    {
        if (! $student) {
            return;
        }

        $this->notifyStudents(
            [$student->id],
            'attendance_scan_issue',
            'Attendance scan needs attention',
            $message,
            [
                ...$this->eventPayload($event),
                'reason' => $reason,
            ],
            'attendance-issue-'.$event->id.'-'.$student->id.'-'.md5($reason),
            false,
        );
    }

    public function incidentCreated(Incident $incident): void
    {
        $this->notifyStudents(
            $this->studentIdsForIncident($incident),
            'disciplinary_record_added',
            'Disciplinary record added',
            'A disciplinary or violation record has been added to your DSAMS profile.',
            $this->incidentPayload($incident),
            'incident-created-'.$incident->id,
        );
    }

    public function incidentUpdated(Incident $incident, array $changedFields): void
    {
        if (empty(array_intersect($changedFields, ['status', 'classification', 'description']))) {
            return;
        }

        $this->notifyStudents(
            $this->studentIdsForIncident($incident),
            'disciplinary_status_updated',
            'Violation status updated',
            'Your violation record status has been updated to '.(string) $incident->status.'.',
            [
                ...$this->incidentPayload($incident),
                'changed_fields' => array_values($changedFields),
            ],
            'incident-updated-'.$incident->id.'-'.(string) $incident->updated_at?->timestamp,
        );
    }

    public function announcementCreated(Announcement $announcement): void
    {
        $category = strtolower((string) ($announcement->category ?? 'general'));
        $type = match ($category) {
            'event' => 'event_announcement',
            'discipline' => 'disciplinary_announcement',
            default => 'student_announcement',
        };

        $this->notifyStudents(
            $this->targetStudentIdsForAnnouncement($announcement),
            $type,
            (string) $announcement->title,
            (string) (($announcement->content ?? '') ?: 'New announcement posted.'),
            [
                'announcement_id' => $announcement->id,
                'category' => $announcement->category,
                'event_date' => $announcement->event_date,
                'event_time' => $announcement->event_time,
            ],
            'announcement-'.$announcement->id,
        );
    }

    private function targetStudentIdsForEvent(Event $event): Collection
    {
        return $this->eventStudentQuery($event)->pluck('id');
    }

    private function eventStudentQuery(Event $event): Builder
    {
        $query = Student::query()->where('is_active', true)->where('status', 'approved');
        $courses = is_array($event->courses) ? $event->courses : [];
        $yearLevels = is_array($event->year_levels) ? $event->year_levels : [];

        if (! empty($courses)) {
            $query->whereIn('course', $courses);
        }

        if (! empty($yearLevels)) {
            $query->whereIn('year_level', $yearLevels);
        }

        return $query;
    }

    private function targetStudentIdsForAnnouncement(Announcement $announcement): Collection
    {
        $query = Student::query()->where('is_active', true)->where('status', 'approved');
        $target = (string) ($announcement->target_audience ?? 'student');

        if ($target !== 'all') {
            $query->where('role', 'Student');
        }

        return $query->pluck('id');
    }

    public function callingNoticeIssued(Incident $incident, array $customDetails = []): void
    {
        $studentIds = $this->studentIdsForIncident($incident);

        if ($studentIds->isEmpty() && !empty($customDetails['student_id'])) {
            $student = Student::where('student_id', $customDetails['student_id'])
                ->orWhere('id', $customDetails['student_id'])
                ->first();
            if ($student) {
                $studentIds = collect([$student->id]);
            }
        }

        $date = $incident->incident_date ? \Illuminate\Support\Carbon::parse($incident->incident_date) : null;
        $caseNumber = $date ? ($date->format('Y').'-'.str_pad((string) $incident->id, 3, '0', STR_PAD_LEFT)) : ('#'.$incident->id);
        $venue = $customDetails['venue'] ?? $incident->location ?? 'Office of the Dean of Student Affairs (ODSA)';
        $schedule = $customDetails['appearance_schedule'] ?? 'Next business day during office hours (8:00 AM - 5:00 PM)';
        $instructions = $customDetails['instructions'] ?? 'You are officially summoned to appear at the Office of Student Affairs & Discipline for Step 3: Meeting / Hearing.';

        $title = 'Official Notice to Appear: Case '.$caseNumber;
        $message = "You have been issued an official Calling Notice regarding {$incident->incident_type}. Venue: {$venue}. Schedule: {$schedule}. Please report promptly.";

        $this->notifyStudents(
            $studentIds,
            'calling_notice',
            $title,
            $message,
            [
                ...$this->incidentPayload($incident),
                'case_id' => $caseNumber,
                'venue' => $venue,
                'appearance_schedule' => $schedule,
                'instructions' => $instructions,
                'issued_at' => now()->toISOString(),
            ],
            'calling-notice-'.$incident->id.'-'.now()->timestamp,
            true,
        );
    }

    public function disciplinaryDecisionIssued(Incident $incident, array $decisionDetails = []): void
    {
        $studentIds = $this->studentIdsForIncident($incident);

        if ($studentIds->isEmpty() && !empty($decisionDetails['student_id'])) {
            $student = Student::where('student_id', $decisionDetails['student_id'])
                ->orWhere('id', $decisionDetails['student_id'])
                ->first();
            if ($student) {
                $studentIds = collect([$student->id]);
            }
        }

        $date = $incident->incident_date ? \Illuminate\Support\Carbon::parse($incident->incident_date) : null;
        $caseNumber = $date ? ($date->format('Y').'-'.str_pad((string) $incident->id, 3, '0', STR_PAD_LEFT)) : ('#'.$incident->id);
        $sanction = $decisionDetails['sanction'] ?? $decisionDetails['sanction_type'] ?? 'Warning';
        $penalty = $decisionDetails['specific_penalty'] ?? $sanction;

        $title = "Official Disciplinary Resolution: Case {$caseNumber}";
        $message = "A formal Notice of Decision has been issued regarding {$incident->incident_type}. Sanction: {$sanction} ({$penalty}). Check your dashboard for official terms and resolution.";

        $this->notifyStudents(
            $studentIds,
            'disciplinary_decision',
            $title,
            $message,
            [
                ...$this->incidentPayload($incident),
                'case_id' => $caseNumber,
                'sanction' => $sanction,
                'specific_penalty' => $penalty,
                'decision_details' => $decisionDetails,
                'served_at' => now()->toISOString(),
            ],
            'disciplinary-decision-'.$incident->id.'-'.now()->timestamp,
            true,
        );
    }

    private function studentIdsForIncident(Incident $incident): Collection
    {
        $values = is_array($incident->students_involved) ? $incident->students_involved : [];

        if (empty($values)) {
            return collect();
        }

        return Student::query()
            ->where(function (Builder $query) use ($values): void {
                foreach ($values as $value) {
                    if (is_array($value)) {
                        $sid = isset($value['id']) ? trim((string) $value['id']) : '';
                        $sname = isset($value['name']) ? trim((string) $value['name']) : '';
                        if ($sid !== '') {
                            $query->orWhere('student_id', $sid);
                            if (ctype_digit($sid)) {
                                $query->orWhereKey((int) $sid);
                            }
                        }
                        if ($sname !== '') {
                            $query->orWhere('name', $sname);
                        }
                        continue;
                    }

                    $value = trim((string) $value);
                    if ($value === '') {
                        continue;
                    }

                    $query->orWhere('student_id', $value)
                        ->orWhere('name', $value);

                    if (ctype_digit($value)) {
                        $query->orWhereKey((int) $value);
                    }
                }
            })
            ->pluck('id');
    }

    private function eventPayload(Event $event): array
    {
        return [
            'event_id' => $event->id,
            'event_name' => $event->event_name,
            'event_date' => optional($event->event_date)->format('Y-m-d'),
            'event_time' => $event->event_time,
            'location' => $event->location,
        ];
    }

    private function incidentPayload(Incident $incident): array
    {
        return [
            'incident_id' => $incident->id,
            'incident_type' => $incident->incident_type,
            'classification' => $incident->classification,
            'status' => $incident->status,
            'incident_date' => optional($incident->incident_date)->format('Y-m-d'),
        ];
    }
}
