<?php

namespace App\Http\Controllers;

use App\Support\TwoFactorLoginHelper;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;

class StudentLoginController extends Controller
{
    public function login(Request $request)
    {
        $request->validate([
            'email' => ['required', 'string'],
            'password' => ['required', 'string'],
        ]);

        $loginInput = $request->input('email');
        $password = $request->input('password');
        $remember = $request->boolean('remember');

        // Check by student_id or email
        if (
            Auth::guard('student')->attempt(['student_id' => $loginInput, 'password' => $password], $remember) ||
            Auth::guard('student')->attempt(['email' => $loginInput, 'password' => $password], $remember)
        ) {
            $user = Auth::guard('student')->user();
            if ($user->verification_status === 'rejected' || $user->status === 'rejected') {
                Auth::guard('student')->logout();
                throw ValidationException::withMessages([
                    'email' => 'Your registration has been rejected. Please contact the administrator.',
                ]);
            }
            // Check for two-factor authentication
            if ($redirect = TwoFactorLoginHelper::redirectIfTwoFactorEnabled($request, $user, 'student', $remember)) {
                return $redirect;
            }
            $request->session()->regenerate();
            $request->session()->flash('status', 'Login successful! Welcome back!');

            return redirect()->intended(route('student.dashboard'));
        }

        throw ValidationException::withMessages([
            'email' => trans('auth.failed'),
        ]);
    }

    public function logout(Request $request)
    {
        Auth::guard('student')->logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('student.login');
    }
}
