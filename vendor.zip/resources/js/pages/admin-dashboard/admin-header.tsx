import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { SimpleTooltip } from '@/components/ui/tooltip';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from '@/components/ui/dialog';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
    Sheet,
    SheetContent,
    SheetDescription,
    SheetHeader,
    SheetTitle,
    SheetTrigger,
} from '@/components/ui/sheet';
import { UserMenuContent } from '@/components/user-menu-content';
import { ThemeToggle } from '@/components/ThemeToggle';
import { DetailedHelpCenterModal } from '@/components/DetailedHelpCenterModal';
import { useInitials } from '@/hooks/use-initials';
import { cn, formatTimeAgo } from '@/lib/utils';
import { adminDashboard, adminNotifications, adminHelp } from '@/routes';
import type { SharedData } from '@/types';
import { Link, router, usePage } from '@inertiajs/react';
import axios from 'axios';
import {
    ArrowRight,
    Bell,
    BookOpen,
    CheckCircle2,
    ChevronDown,
    HelpCircle,
    LifeBuoy,
    Mail,
    Menu,
    Shield,
    Users,
    X,
} from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { MobileNavigation } from './mobile-navigation';
import { useNotifications } from '@/hooks/useNotifications';
import NotificationPopup from '@/components/notifications/NotificationPopup';
import { playNotificationSound } from '@/services/notification-sound';

export function AdminHeader() {
    const page = usePage<SharedData>();
    const { auth } = page.props;
    const getInitials = useInitials();
    const [locallyRead, setLocallyRead] = useState<string[]>([]);
    const [bellClicked, setBellClicked] = useState(false);
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
    const [helpOpen, setHelpOpen] = useState(false);

    useEffect(() => {
        const handleOpenMenu = () => setMobileMenuOpen(true);
        window.addEventListener('dsams:open-admin-mobile-menu', handleOpenMenu);
        return () => {
            window.removeEventListener('dsams:open-admin-mobile-menu', handleOpenMenu);
        };
    }, []);

    // Real-time notification hook powered by Node.js + Socket.IO
    const {
        notifications: realtimeList,
        unreadCount: realtimeUnread,
        popupNotification,
        markAsRead,
        markAllAsRead,
        clearPopup,
    } = useNotifications({
        userId: auth?.user?.id,
        role: (auth?.user as any)?.role || 'admin',
        autoConnect: Boolean(auth?.user?.id),
    });

    const recentNotifications = Array.isArray(
        (page.props as any)?.recentNotifications,
    )
        ? ((page.props as any).recentNotifications ?? [])
        : [];

    // Merge initial server-rendered notifications with live realtime notifications
    const notificationsToRender = (realtimeList.length > 0 ? realtimeList : recentNotifications) as Array<{
        id: string | number;
        type?: string;
        title: string;
        subtitle?: string;
        message?: string;
        timeAgo?: string;
        created_at?: string;
        is_read?: boolean;
    }>;

    const unreadNotifications = realtimeList.length > 0
        ? realtimeUnread
        : (bellClicked
            ? 0
            : notificationsToRender.filter(
                  (n) => !n.is_read && !locallyRead.includes(String(n.id)),
              ).length);

    const lastUnreadCount = useRef(unreadNotifications);
    useEffect(() => {
        if (unreadNotifications > lastUnreadCount.current) {
            playNotificationSound();
        }
        lastUnreadCount.current = unreadNotifications;
    }, [unreadNotifications]);

    const handleNotificationBellClick = () => {
        setBellClicked(true);
    };

    const getNotificationHref = (n: any) => {
        if (!n || !n.type) return null;
        if (
            n.type === 'admission_slip_requested' ||
            n.type === 'admission_slip_status_updated'
        ) {
            return n.slipId
                ? `/admin/admission-slip?slip_id=${n.slipId}`
                : '/admin/admission-slip';
        }
        if (
            n.type === 'incident_reported_admin' ||
            n.type === 'incident_reported_student'
        ) {
            return n.incidentId
                ? `/admin/incidents-violations/${n.incidentId}`
                : '/admin/incidents-violations';
        }
        if (n.type === 'evaluation_available') {
            return '/admin/evaluation';
        }
        if (n.type === 'activity_plan_submitted_admin') {
            return '/admin/events?status=pending';
        }
        if (n.type === 'activity_plan_status_updated') {
            return '/admin/events';
        }
        return null;
    };

    const handleNotificationClick = (n: any) => {
        const isRead = n.is_read || locallyRead.includes(String(n.id));
        if (!isRead) {
            setLocallyRead((prev) => [...prev, String(n.id)]);
            if (typeof n.id === 'number') {
                markAsRead(n.id);
            } else {
                axios.post(`/notifications/${n.id}/mark-read`).catch(console.error);
            }
        }

        const href = getNotificationHref(n);
        if (href) {
            router.visit(href);
        }
    };

    const handleMarkAllAsRead = () => {
        const allIds = notificationsToRender.map((n) => String(n.id));
        setLocallyRead(allIds);
        markAllAsRead();
    };

    const propsAny = page.props as unknown as Record<string, any>;
    const user =
        auth?.user ??
        propsAny?.auth?.user ??
        propsAny?.auth?.user?.data ??
        propsAny?.user;
    const defaultUser = { name: 'Admin User', avatar: null };
    const displayUser = user || defaultUser;
    const subtitleLabel = displayUser ? 'Administrator' : undefined;

    return (
        <div className="fixed inset-x-0 top-0 z-40 border-b border-white/5 bg-gradient-to-r from-[#0b2d66] via-[#103875] to-[#1e40af] text-white shadow-md dark:bg-[#0B192C] dark:from-transparent dark:via-transparent dark:to-transparent">
            <div className="flex h-16 w-full items-center px-4 sm:px-6">
                {/* Mobile Menu Trigger */}
                <div className="lg:hidden">
                    <Sheet
                        open={mobileMenuOpen}
                        onOpenChange={setMobileMenuOpen}
                    >
                        <SimpleTooltip content="Open Navigation Menu" side="bottom">
                            <SheetTrigger asChild>
                                <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-10 w-10 rounded-xl text-white hover:bg-white/10 cursor-pointer"
                                >
                                    <Menu className="h-5 w-5" />
                                </Button>
                            </SheetTrigger>
                        </SimpleTooltip>
                        <SheetContent
                            side="left"
                            className="w-72 border-r border-slate-200 bg-white p-0 gap-0 dark:border-white/10 dark:bg-[#0B192C] [&>button]:hidden"
                        >
                            <SheetHeader className="sr-only">
                                <SheetTitle>Navigation Menu</SheetTitle>
                                <SheetDescription>
                                    Main navigation menu for accessing admin
                                    dashboard features
                                </SheetDescription>
                            </SheetHeader>
                            <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50 p-5 dark:border-white/10 dark:bg-white/5">
                                <div className="flex items-center gap-2">
                                    <div className="flex -space-x-2">
                                        <img
                                            src="/images/SRCB.png"
                                            alt="SRCB Logo"
                                            className="h-9 w-9 rounded-full bg-white object-cover ring-2 ring-white"
                                        />
                                        <img
                                            src="/images/DSA.png"
                                            alt="DSA Logo"
                                            className="h-9 w-9 rounded-full bg-white object-cover ring-2 ring-white"
                                        />
                                    </div>
                                    <span className="font-bold text-slate-900 dark:text-white">
                                        OSAMS
                                    </span>
                                </div>
                                <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => setMobileMenuOpen(false)}
                                    className="h-8 w-8 rounded-full text-slate-500 hover:bg-slate-200 dark:text-white dark:hover:bg-white/10"
                                >
                                    <X className="h-4 w-4" />
                                </Button>
                            </div>
                            <MobileNavigation onNavigate={() => setMobileMenuOpen(false)} />
                        </SheetContent>
                    </Sheet>
                </div>

                {/* Logo and Title */}
                <Link
                    href={adminDashboard()}
                    prefetch
                    className="flex items-center gap-2 sm:gap-3 lg:ml-0"
                >
                    <div className="flex items-center gap-1 sm:gap-2">
                        <img
                            src="/images/SRCB.png"
                            alt="SRCB Logo"
                            className="h-8 w-8 rounded-full bg-white object-cover sm:h-10 sm:w-10"
                        />
                        <img
                            src="/images/DSA.png"
                            alt="DSA Logo"
                            className="h-8 w-8 rounded-full bg-white object-cover sm:h-10 sm:w-10"
                        />
                    </div>
                    <div className="hidden leading-tight sm:block">
                        <div className="flex flex-wrap items-center gap-1 sm:gap-2">
                            <div className="text-base font-bold tracking-wide sm:text-lg">
                                OSAMS
                            </div>
                            <div className="hidden text-white/50 md:block">
                                /
                            </div>
                            <div className="hidden text-xs font-semibold text-white/90 lg:block">
                                Office of Student Affairs Management System
                            </div>
                        </div>
                        <div className="hidden text-[10px] font-semibold text-white/80 sm:block sm:text-[11px]">
                            St. Rita's College of Balingasag
                        </div>
                    </div>
                    {/* Mobile-only title */}
                    <div className="leading-tight sm:hidden">
                        <div className="text-base font-bold tracking-wide">
                            OSAMS
                        </div>
                    </div>
                </Link>

                {/* Right side actions */}
                <div className="ml-auto flex items-center gap-1.5 sm:gap-3">
                    {/* Dark/Light Theme Quick Toggle */}
                    <ThemeToggle variant="header" />

                    {/* Detailed Help Center Page Link */}
                    <SimpleTooltip content="Help & Guidelines Center" side="bottom">
                        <Link
                            href={adminHelp()}
                            className="relative flex h-9 w-9 items-center justify-center rounded-full text-white hover:bg-white/15 hover:text-white sm:h-10 sm:w-10"
                        >
                            <HelpCircle className="h-4 w-4 sm:h-5 sm:w-5" />
                        </Link>
                    </SimpleTooltip>

                    {/* Notifications */}
                    <DropdownMenu modal={false}>
                        <SimpleTooltip content="Notifications" side="bottom">
                            <DropdownMenuTrigger asChild>
                                <Button
                                    type="button"
                                    variant="ghost"
                                    size="icon"
                                    onClick={handleNotificationBellClick}
                                    className="relative h-9 w-9 rounded-full text-white hover:bg-white/15 hover:text-white sm:h-10 sm:w-10 cursor-pointer"
                                    aria-label="Notifications"
                                >
                                    <Bell className="h-4 w-4 sm:h-5 sm:w-5" />
                                    {unreadNotifications > 0 ? (
                                        <span className="absolute -top-1 -right-1 inline-flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[8px] leading-none font-bold text-white sm:h-5 sm:w-5 sm:text-[9px]">
                                            {unreadNotifications > 99
                                                ? '99+'
                                                : unreadNotifications}
                                        </span>
                                    ) : null}
                                </Button>
                            </DropdownMenuTrigger>
                        </SimpleTooltip>
                        <DropdownMenuContent
                            className="z-[60] w-[calc(100vw-2rem)] max-w-sm rounded-2xl border border-slate-100 shadow-xl dark:border-slate-800 dark:bg-[#0B192C]"
                            align="end"
                        >
                            <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3 dark:border-slate-800">
                                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                                    Notifications
                                </h3>
                                {unreadNotifications > 0 && (
                                    <button
                                        type="button"
                                        onClick={handleMarkAllAsRead}
                                        className="text-xs font-semibold text-blue-600 transition-colors hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                                    >
                                        Mark all as read
                                    </button>
                                )}
                            </div>

                            <div className="max-h-80 divide-y divide-slate-100 overflow-y-auto dark:divide-slate-800">
                                {notificationsToRender.length > 0 ? (
                                    notificationsToRender.map((n) => {
                                        const isRead =
                                            n.is_read ||
                                            locallyRead.includes(String(n.id));
                                        const displaySubtitle = n.subtitle || n.message;
                                        const displayTime = n.timeAgo || (n.created_at ? formatTimeAgo(n.created_at) : undefined);
                                        return (
                                            <div
                                                key={n.id}
                                                onClick={() =>
                                                    handleNotificationClick(n)
                                                }
                                                className={cn(
                                                    'group flex cursor-pointer items-start gap-3 px-4 py-3 transition-all',
                                                    isRead
                                                        ? 'bg-transparent opacity-70 hover:bg-slate-50 dark:hover:bg-slate-800/40'
                                                        : 'bg-blue-50/40 hover:bg-blue-50/70 dark:bg-blue-950/10 dark:hover:bg-blue-950/20',
                                                )}
                                            >
                                                <div className="min-w-0 flex-1">
                                                    <p
                                                        className={cn(
                                                            'text-sm transition-colors',
                                                            isRead
                                                                ? 'dark:text-slate-350 font-medium text-slate-700'
                                                                : 'font-bold text-slate-900 group-hover:text-blue-600 dark:text-white dark:group-hover:text-blue-400',
                                                        )}
                                                    >
                                                        {n.title}
                                                    </p>
                                                    {displaySubtitle && (
                                                        <p className="mt-1 text-xs leading-normal text-slate-600 dark:text-slate-400">
                                                            {displaySubtitle}
                                                        </p>
                                                    )}
                                                    {displayTime && (
                                                        <p className="mt-1.5 text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                                                            {displayTime}
                                                        </p>
                                                    )}
                                                </div>
                                                {!isRead && (
                                                    <span className="mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full bg-blue-600 shadow-xs shadow-blue-500 dark:bg-blue-400" />
                                                )}
                                            </div>
                                        );
                                    })
                                ) : (
                                    <div className="px-4 py-12 text-center">
                                        <p className="dark:text-slate-450 text-sm text-slate-500">
                                            No notifications.
                                        </p>
                                    </div>
                                )}
                            </div>

                            {notificationsToRender.length > 0 && (
                                <>
                                    <DropdownMenuSeparator className="m-0 dark:bg-slate-800" />
                                    <Link
                                        href={adminNotifications()}
                                        className="block px-4 py-2.5 text-center text-xs font-bold text-[#23509A] transition-colors hover:bg-slate-50 dark:text-blue-400 dark:hover:bg-slate-800/40"
                                    >
                                        View all notifications
                                    </Link>
                                </>
                            )}
                        </DropdownMenuContent>
                    </DropdownMenu>

                    {/* User Menu */}
                    <DropdownMenu modal={false}>
                        <SimpleTooltip content="Account Settings & Profile" side="bottom">
                            <DropdownMenuTrigger asChild>
                                <Button
                                    variant="ghost"
                                    className="h-auto gap-1 rounded-full border border-white/15 bg-white/5 px-1.5 py-1.5 text-white hover:bg-white/15 hover:text-white sm:gap-2 sm:px-2 sm:py-2 cursor-pointer"
                                    aria-label="Account Settings & Profile"
                                >
                                    <Avatar className="size-7 overflow-hidden rounded-full sm:size-8">
                                        <AvatarImage
                                            src={displayUser.avatar}
                                            alt={displayUser.name}
                                        />
                                        <AvatarFallback className="rounded-lg bg-white/20 text-xs text-white sm:text-sm">
                                            {getInitials(displayUser.name)}
                                        </AvatarFallback>
                                    </Avatar>
                                    <div className="hidden text-left leading-tight md:block">
                                        <div className="max-w-32 truncate text-xs font-semibold sm:text-sm">
                                            {displayUser.name}
                                        </div>
                                        {subtitleLabel && (
                                            <div className="hidden text-xs text-white/90 lg:block">
                                                {subtitleLabel}
                                            </div>
                                        )}
                                    </div>
                                    <ChevronDown className="hidden h-3 w-3 opacity-90 sm:h-4 sm:w-4 md:block" />
                                </Button>
                            </DropdownMenuTrigger>
                        </SimpleTooltip>
                        <DropdownMenuContent className="w-56" align="end">
                            <UserMenuContent user={displayUser} />
                        </DropdownMenuContent>
                    </DropdownMenu>
                </div>
            </div>

            {/* Real-time Notification Popup Toast */}
            <NotificationPopup
                notification={popupNotification}
                onClose={clearPopup}
                onView={(n) => {
                    const href = getNotificationHref(n);
                    if (href) router.visit(href);
                }}
            />
        </div>
    );
}
