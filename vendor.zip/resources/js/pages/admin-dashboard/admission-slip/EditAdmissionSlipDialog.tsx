import InputError from '@/components/input-error';
import { Button } from '@/components/ui/button';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import { router, usePage } from '@inertiajs/react';
import { useEffect, useMemo, useState } from 'react';
import type { SweetAlertResult } from 'sweetalert2';
import Swal from 'sweetalert2';
import { getValidityDaysForReason } from './CreateAdmissionSlipDialog';
import type { SlipRow } from './types';

type Props = {
    open: boolean;
    setOpen: (open: boolean) => void;
    slip: SlipRow | null;
    errors: Record<string, string>;
};

const STANDARD_REASONS = [
    'Illness / Not Feeling Well',
    'Medical / Dental Appointment',
    'Family Emergency',
    'Bereavement in the Family',
    'Transportation Problem',
    'Bad Weather / Calamity',
    'Official School Activity',
    'Financial Concern',
];

const addDaysIso = (isoDate: string, days: number) => {
    const base = new Date(`${isoDate}T00:00:00`);
    if (Number.isNaN(base.getTime())) return '';
    base.setDate(base.getDate() + days);
    return base.toISOString().slice(0, 10);
};

export default function EditAdmissionSlipDialog({
    open,
    setOpen,
    slip,
    errors,
}: Props) {
    const emptyForm = {
        studentName: '',
        programYear: '',
        dateIssued: '',
        caseText: '',
        reasonText: '',
        validUntil: '',
        status: 'PENDING' as 'PENDING' | 'APPROVED' | 'REJECTED',
    };

    const [form, setForm] = useState(emptyForm);

    const synced = useMemo(() => {
        if (!slip) return emptyForm;
        return {
            studentName: slip.studentName,
            programYear: slip.programYear,
            dateIssued: slip.dateIssued,
            caseText: slip.caseText,
            reasonText: slip.reasonText,
            validUntil: slip.validUntil,
            status: (slip.status || 'PENDING') as
                | 'PENDING'
                | 'APPROVED'
                | 'REJECTED',
        };
    }, [slip]);

    useEffect(() => {
        if (open && slip) setForm(synced);
    }, [open, slip, synced]);

    const { props: pageProps } = usePage<any>();
    const role = pageProps?.auth?.user?.role;

    const closeEdit = () => {
        setOpen(false);
    };

    const updateSlip = () => {
        const clientErrors: string[] = [];
        if (!form.studentName.trim())
            clientErrors.push('Student name is required');
        if (!form.programYear.trim())
            clientErrors.push('Program year is required');
        if (!form.dateIssued.trim())
            clientErrors.push('Date issued is required');
        if (!form.reasonText.trim())
            clientErrors.push('Reason text is required');
        if (!form.validUntil.trim())
            clientErrors.push('Valid until date is required');
        if (clientErrors.length) {
            Swal.fire({
                title: 'Validation error',
                html: clientErrors.join('<br/>'),
                icon: 'error',
                confirmButtonText: 'OK',
            });
            return;
        }

        setOpen(false);
        Swal.fire({
            title: 'Confirm Update',
            text: 'Are you sure you want to save changes to this admission slip?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#2563eb',
            cancelButtonColor: '#64748b',
            confirmButtonText: 'Yes, update',
            cancelButtonText: 'Cancel',
        }).then((result: SweetAlertResult) => {
            if (result.isConfirmed && slip) {
                const endpoint =
                    role === 'dsa'
                        ? `/dsa/admission-slip/${slip.id}`
                        : `/admin/admission-slip/${slip.id}`;

                router.put(
                    endpoint,
                    {
                        student_name: form.studentName.trim(),
                        program_year_level: form.programYear.trim(),
                        date_issued: form.dateIssued.trim(),
                        case_text: form.reasonText.trim(),
                        reason_text: form.reasonText.trim(),
                        valid_until: form.validUntil.trim(),
                        status: form.status,
                    },
                    {
                        preserveScroll: true,
                        onSuccess: () => {
                            setOpen(false);
                            Swal.fire({
                                title: 'Updated!',
                                text: 'Admission slip has been updated successfully.',
                                icon: 'success',
                                timer: 2000,
                                showConfirmButton: false,
                            });
                        },
                        onError: () => {
                            setOpen(true);
                        },
                    },
                );
            } else {
                setOpen(true);
            }
        });
    };

    const isPredefined = STANDARD_REASONS.includes(form.reasonText);
    const isOtherSelected =
        !isPredefined && form.reasonText !== '';
    const dropdownValue = isPredefined
        ? form.reasonText
        : isOtherSelected
          ? 'Others'
          : '';

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogContent className="flex max-h-[90vh] w-full !max-w-2xl flex-col overflow-hidden p-0">
                <div className="flex-shrink-0 bg-gradient-to-r from-[#23509A] via-[#000D6A] to-[#23509A] px-6 py-5 text-white">
                    <DialogHeader>
                        <DialogTitle className="text-white">
                            Edit Admission Slip
                        </DialogTitle>
                        <DialogDescription className="text-white/80">
                            Update slip details and status.
                        </DialogDescription>
                    </DialogHeader>
                </div>

                <div className="flex-1 space-y-4 overflow-y-auto px-6 py-6">
                    {(slip?.slipCount || slip?.allTimeCount) && (
                        <div className="flex items-center justify-between rounded-lg border border-blue-100 bg-blue-50/70 p-3 text-xs text-blue-900 dark:border-blue-900/40 dark:bg-blue-950/40 dark:text-blue-200">
                            <span className="font-semibold">
                                Monthly Quota: {slip.slipCount}
                            </span>
                            {slip.allTimeCount && (
                                <span className="rounded-full bg-blue-100 px-2.5 py-0.5 font-medium text-blue-800 dark:bg-blue-900/60 dark:text-blue-300">
                                    {slip.allTimeCount}
                                </span>
                            )}
                        </div>
                    )}
                    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                        <div className="grid gap-2">
                            <Label htmlFor="editStudentName">
                                Student Name
                            </Label>
                            <Input
                                id="editStudentName"
                                value={form.studentName}
                                onChange={(e) =>
                                    setForm((p) => ({
                                        ...p,
                                        studentName: e.target.value,
                                    }))
                                }
                                placeholder="Student name"
                            />
                            <InputError message={errors.student_name} />
                        </div>

                        <div className="grid gap-2">
                            <Label htmlFor="editProgramYear">
                                Program/Year Level
                            </Label>
                            <Input
                                id="editProgramYear"
                                value={form.programYear}
                                onChange={(e) =>
                                    setForm((p) => ({
                                        ...p,
                                        programYear: e.target.value,
                                    }))
                                }
                                placeholder="Program and year level"
                            />
                            <InputError message={errors.program_year_level} />
                        </div>
                        <div className="grid gap-2">
                            <Label htmlFor="editDateIssued">Date Issued</Label>
                            <Input
                                id="editDateIssued"
                                type="date"
                                value={form.dateIssued}
                                onChange={(e) => {
                                    const v = e.target.value;
                                    const days = getValidityDaysForReason(form.reasonText);
                                    setForm((p) => ({
                                        ...p,
                                        dateIssued: v,
                                        validUntil: v ? addDaysIso(v, days) : p.validUntil,
                                    }));
                                }}
                            />
                            <InputError message={errors.date_issued} />
                        </div>
                        <div className="grid gap-2">
                            <div className="flex items-center justify-between">
                                <Label htmlFor="editValidUntil">Valid Until</Label>
                                <span className="text-[11px] font-semibold text-blue-600 dark:text-blue-400">
                                    {form.reasonText ? `Auto (+${getValidityDaysForReason(form.reasonText)}d) • Full Admin Override` : 'Full Admin Override • Editable'}
                                </span>
                            </div>
                            <Input
                                id="editValidUntil"
                                type="date"
                                value={form.validUntil}
                                onChange={(e) =>
                                    setForm((p) => ({
                                        ...p,
                                        validUntil: e.target.value,
                                    }))
                                }
                            />
                            <p className="text-[10px] text-slate-500 dark:text-slate-400">
                                Input is unlocked. Admins can adjust the expiration date shorter or longer depending on medical certificates or student circumstances.
                            </p>
                            <InputError message={errors.valid_until} />
                        </div>
                    </div>

                    <div className="grid gap-2">
                        <Label htmlFor="editStatus">Status</Label>
                        <Select
                            value={form.status}
                            onValueChange={(v) =>
                                setForm((p) => ({
                                    ...p,
                                    status: v as
                                        | 'PENDING'
                                        | 'APPROVED'
                                        | 'REJECTED',
                                }))
                            }
                        >
                            <SelectTrigger className="h-10 w-full sm:w-48">
                                <SelectValue placeholder="Select status" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="PENDING">Pending</SelectItem>
                                <SelectItem value="APPROVED">
                                    Approved
                                </SelectItem>
                                <SelectItem value="REJECTED">
                                    Rejected
                                </SelectItem>
                            </SelectContent>
                        </Select>
                        <InputError message={errors.status} />
                    </div>

                    <div className="grid gap-2">
                        <Label
                            htmlFor="editReasonSelect"
                            className="text-xs font-bold tracking-wider text-slate-600 uppercase dark:text-slate-400"
                        >
                            Reason *
                        </Label>
                        <select
                            id="editReasonSelect"
                            value={dropdownValue}
                            onChange={(e) => {
                                const val = e.target.value;
                                const nextReason =
                                    val === 'Others'
                                        ? form.reasonText.startsWith('Others: ')
                                            ? form.reasonText
                                            : 'Others: '
                                        : val;
                                const days = getValidityDaysForReason(val);
                                setForm((p) => ({
                                    ...p,
                                    reasonText: nextReason,
                                    validUntil: p.dateIssued ? addDaysIso(p.dateIssued, days) : p.validUntil,
                                }));
                            }}
                            className="flex h-10 w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 shadow-xs focus-visible:ring-2 focus-visible:ring-[#23509A] focus-visible:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                        >
                            <option value="" disabled>
                                -- Select Reason --
                            </option>
                            {STANDARD_REASONS.map((r) => (
                                <option key={r} value={r}>
                                    {r}
                                </option>
                            ))}
                            <option value="Others">
                                Others (Please Specify)
                            </option>
                        </select>

                        {dropdownValue === 'Others' && (
                            <div className="mt-2 animate-in space-y-1.5 duration-200 fade-in">
                                <Label
                                    htmlFor="editReasonText_other"
                                    className="text-xs font-bold tracking-wider text-slate-500 dark:text-slate-400"
                                >
                                    Specify Reason Details *
                                </Label>
                                <textarea
                                    id="editReasonText_other"
                                    value={
                                        form.reasonText.startsWith('Others: ')
                                            ? form.reasonText.replace(
                                                  'Others: ',
                                                  '',
                                              )
                                            : form.reasonText === 'Others'
                                              ? ''
                                              : form.reasonText
                                    }
                                    onChange={(e) =>
                                        setForm((p) => ({
                                            ...p,
                                            reasonText:
                                                'Others: ' + e.target.value,
                                        }))
                                    }
                                    placeholder="Specify other reason details..."
                                    rows={2}
                                    className="min-h-16 w-full resize-none rounded-md border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 shadow-xs focus-visible:ring-2 focus-visible:ring-[#23509A] focus-visible:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                                />
                            </div>
                        )}
                        <InputError message={errors.reason_text} />
                    </div>
                </div>

                <DialogFooter className="border-t border-slate-200 bg-slate-50 px-6 py-4">
                    <Button
                        variant="secondary"
                        type="button"
                        onClick={closeEdit}
                    >
                        Cancel
                    </Button>
                    <Button
                        type="button"
                        className="bg-[#23509A] transition-colors hover:bg-[#1e4a8a]"
                        onClick={updateSlip}
                        disabled={
                            !form.studentName.trim() ||
                            !form.programYear.trim() ||
                            !form.dateIssued.trim() ||
                            !form.caseText.trim() ||
                            !form.reasonText.trim() ||
                            !form.validUntil.trim()
                        }
                    >
                        Save Changes
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

